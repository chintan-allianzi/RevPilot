

# Contact Detail Page with Full Communication Hub

## Summary

Build a new **Contact Detail page** (`/contacts/:contactId`) inspired by GoHighLevel's contact view. This page will serve as a centralized hub for each contact, showing their profile, full communication history (emails sent/received), linked deals, activity timeline, and the ability to send new emails directly from the contact record.

## Current State

- **Contact Manager** (`/contacts`) is a table-only view with no drill-down
- **DealDetail** (`/pipeline/:dealId`) already has rich activity logging, email compose, task management, and appointment tracking
- Communication data already exists in `email_queue` (sent), `email_replies` (received), `deals`, `deal_activities`, `appointments`, and `linkedin_tasks`
- `ComposeEmailDialog` already supports threaded replies, Gmail API sending, and activity logging

## What We Build

### 1. Contact Detail Page (`/contacts/:contactId`)

A two-panel layout (like GoHighLevel screenshots):

**Left Panel — Contact Profile**
- Avatar, name, title, email, phone, LinkedIn
- Inline-editable fields (name, email, phone, title)
- Company info section (linked company name, domain, industry, location)
- Vertical badge, tier, email status
- Tags/status badges (opted out, contacted, replied, etc.)
- "Hide empty fields" toggle

**Right Panel — Tabbed Content Area**

- **Conversations Tab**: Unified chronological view of all emails sent (`email_queue`) and received (`email_replies`) for this contact across all campaigns. Threaded message bubbles similar to GoHighLevel. Email compose bar at the bottom to send new emails via Gmail API.

- **Activity Tab**: Timeline of all deal activities (`deal_activities`) linked to this contact's deals, plus appointments, stage changes. Color-coded entries with timestamps.

- **Deals Tab**: List of all deals linked to this contact (`deals.contact_id`). Each shows deal name, stage, value, assigned BDM, days in stage. Click navigates to DealDetail. Quick "Create Deal" button.

- **Tasks Tab**: All tasks from deals linked to this contact (`deal_tasks` via `deals.contact_id`). Shows status, due date, priority.

### 2. Navigation Integration

- Add route `/contacts/:contactId` in `App.tsx`
- Make contact names in the Contact Manager table clickable (link to detail page)
- Add breadcrumb navigation: Contacts > Contact Name
- Cross-link from DealDetail contact card to ContactDetail

### 3. Communication Execution from Contact Page

- Reuse existing `ComposeEmailDialog` for sending emails
- Pre-fill recipient from contact record
- Link sent emails to the contact and optionally to a selected deal
- Show sent/received emails in the Conversations tab with bubble UI

### 4. Deal Linkage

- Show all deals where `deals.contact_id` matches
- Display current pipeline stage, value, assigned BDM
- "Create Deal" button pre-fills contact info
- Activity from deals flows into the Activity tab

## No Database Changes Required

All data already exists in current tables:
- `saved_contacts` — contact profile
- `saved_companies` — company info
- `email_queue` — sent emails (by `contact_id`)
- `email_replies` — received emails (by `contact_id`)
- `deals` — linked deals (by `contact_id`)
- `deal_activities` — activity timeline (via deal_id)
- `deal_tasks` — tasks (via deal_id)
- `appointments` — meetings (via deal_id)
- `linkedin_tasks` — LinkedIn actions (by `contact_id`)

## Files to Create/Modify

- **New**: `src/pages/ContactDetail.tsx` — the full contact detail page
- **Modify**: `src/App.tsx` — add `/contacts/:contactId` route
- **Modify**: `src/pages/ContactManager.tsx` — make contact names clickable links
- **Modify**: `src/pages/DealDetail.tsx` — add link from contact card to ContactDetail

## Technical Notes

- Contact profile queries `saved_contacts` with join to `saved_companies` and `verticals`
- Conversations tab queries `email_queue` + `email_replies` by contact_id, merged and sorted chronologically
- Deals tab queries `deals` by contact_id with join to `lead_stages`
- Activity tab aggregates `deal_activities` from all linked deals
- Email compose reuses `ComposeEmailDialog` with `toEmail`/`toName` pre-filled
- Inline editing uses same pattern as DealDetail (click to edit, save on blur/enter)

