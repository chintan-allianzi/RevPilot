import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Save, CheckCircle, Loader2 } from "lucide-react";
import { useVerticals } from "@/contexts/VerticalsContext";
import { useAISettings } from "@/contexts/AISettingsContext";
import { useSearchParams } from "react-router-dom";
import VerticalBuilder from "@/components/VerticalBuilder";
import PhaseTarget, { SignalWeights, DEFAULT_SIGNAL_WEIGHTS, type CampaignMode } from "@/components/campaign/PhaseTarget";
import PhaseDiscover from "@/components/campaign/PhaseDiscover";
import PhaseDiscoverJobs from "@/components/campaign/PhaseDiscoverJobs";
import ContactsStep from "@/components/campaign/ContactsStep";
import MessagesStep from "@/components/campaign/MessagesStep";
import LaunchStep from "@/components/campaign/LaunchStep";
import CampaignList from "@/components/campaign/CampaignList";
import type { ContactMessages, EmailSequenceStep } from "@/components/campaign/MessagesStep";
import { CompanyIntelligence } from "@/lib/company-types";
import { VerticalConfig } from "@/lib/icp-config";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const phases = [
  { num: 1, label: "Target" },
  { num: 2, label: "Discover" },
  { num: 3, label: "Contacts" },
  { num: 4, label: "Message" },
  { num: 5, label: "Launch" },
];

type ViewMode = "loading" | "list" | "builder";

export default function CampaignBuilder() {
  const [searchParams] = useSearchParams();
  const showDebug = searchParams.get("debug") === "true";

  // View mode: list or builder
  const [viewMode, setViewMode] = useState<ViewMode>("loading");

  const [phase, setPhase] = useState(1);
  const [maxPhase, setMaxPhase] = useState(1);
  const [selectedVertical, setSelectedVertical] = useState<string | null>(null);
  const [builderOpen, setBuilderOpen] = useState(false);
  const [editingVertical, setEditingVertical] = useState<VerticalConfig | null>(null);
  const [signalWeights, setSignalWeights] = useState<SignalWeights>(DEFAULT_SIGNAL_WEIGHTS);
  const [campaignMode, setCampaignMode] = useState<CampaignMode>("standard");
  const [jobKeywords, setJobKeywords] = useState<string[]>([]);
  const [jobLocation, setJobLocation] = useState("");

  const [selectedCompanies, setSelectedCompanies] = useState<CompanyIntelligence[]>([]);
  const [selectedContacts, setSelectedContacts] = useState<any[]>([]);
  const [launchData, setLaunchData] = useState<{
    contactMessages: Map<string, ContactMessages>;
    sequence: EmailSequenceStep[];
    generateLinkedIn: boolean;
    generateLinkedInDM: boolean;
  } | null>(null);

  // Auto-save state
  const [campaignId, setCampaignId] = useState<string | null>(null);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [saving, setSaving] = useState(false);

  const { verticals, addVertical, updateVertical } = useVerticals();
  const { serviceKeys } = useAISettings();

  const selectedConfig = selectedVertical ? verticals.find((v) => v.name === selectedVertical) : null;

  // Check if campaigns exist on mount
  useEffect(() => {
    (async () => {
      const { count } = await supabase
        .from("campaigns")
        .select("id", { count: "exact", head: true });
      setViewMode(count && count > 0 ? "list" : "builder");
    })();
  }, []);

  // Track max phase
  useEffect(() => {
    if (phase > maxPhase) setMaxPhase(phase);
  }, [phase]);

  const goToPhase = (p: number) => {
    if (p <= maxPhase + 1) setPhase(p);
  };

  // Auto-save campaign
  const autoSave = useCallback(async () => {
    if (!selectedVertical || !selectedConfig) return;
    setSaving(true);
    try {
      const settings = {
        signalWeights,
        phase,
        campaignMode,
        jobKeywords: campaignMode === "job_posting" ? jobKeywords : undefined,
        jobLocation: campaignMode === "job_posting" ? jobLocation : undefined,
        companiesCount: selectedCompanies.length,
        contactsCount: selectedContacts.length,
      };

      if (campaignId) {
        await supabase.from("campaigns").update({
          settings: settings as any,
          contacts_count: selectedContacts.length,
          updated_at: new Date().toISOString(),
        }).eq("id", campaignId);
      } else {
        const { data } = await supabase.from("campaigns").insert({
          name: `Draft — ${selectedVertical}`,
          vertical_id: selectedConfig.id,
          status: "draft",
          settings: settings as any,
          contacts_count: selectedContacts.length,
        } as any).select().single();
        if (data) setCampaignId(data.id);
      }
      setLastSaved(new Date());
    } catch { /* silent */ }
    setSaving(false);
  }, [selectedVertical, selectedConfig, signalWeights, phase, selectedCompanies, selectedContacts, campaignId]);

  // Auto-save on meaningful changes
  useEffect(() => {
    if (!selectedVertical) return;
    const timer = setTimeout(autoSave, 2000);
    return () => clearTimeout(timer);
  }, [selectedVertical, selectedCompanies.length, selectedContacts.length, phase]);

  const handleSelectVertical = (name: string) => {
    setSelectedVertical(name);
    setPhase(2);
  };

  const handleSaveVertical = async (draft: any, existingId?: string) => {
    if (existingId) await updateVertical(existingId, draft);
    else await addVertical(draft);
  };

  const openCreate = () => { setEditingVertical(null); setBuilderOpen(true); };
  const openEdit = (v: VerticalConfig, e: React.MouseEvent) => { e.stopPropagation(); setEditingVertical(v); setBuilderOpen(true); };

  const handleCompaniesSelected = useCallback((companies: CompanyIntelligence[]) => {
    setSelectedCompanies(companies);
  }, []);

  const handleNewCampaign = () => {
    setCampaignId(null);
    setSelectedVertical(null);
    setPhase(1);
    setMaxPhase(1);
    setSelectedCompanies([]);
    setSelectedContacts([]);
    setLaunchData(null);
    setLastSaved(null);
    setCampaignMode("standard");
    setJobKeywords([]);
    setJobLocation("");
    setViewMode("builder");
  };

  const handleContinueCampaign = async (id: string, lastPhase: number) => {
    // Load campaign data and resume
    const { data: campaign } = await supabase
      .from("campaigns")
      .select("*, vertical:verticals(name)")
      .eq("id", id)
      .single();

    if (campaign) {
      setCampaignId(campaign.id);
      if (campaign.vertical?.name) {
        setSelectedVertical(campaign.vertical.name);
      }
      const savedPhase = (campaign.settings as any)?.phase || lastPhase || 1;
      setPhase(savedPhase);
      setMaxPhase(savedPhase);
      if ((campaign.settings as any)?.signalWeights) {
        setSignalWeights((campaign.settings as any).signalWeights);
      }
    }
    setViewMode("builder");
  };

  const progressPct = Math.round(((phase - 1) / (phases.length - 1)) * 100);

  // Summary stats
  const readyContacts = selectedContacts.filter((c: any) => {
    const score = computeContactCompleteness(c);
    return score >= 70;
  }).length;

  const estimatedDays = selectedContacts.length > 0 ? Math.ceil(selectedContacts.length / 50) : 0;

  // Loading state
  if (viewMode === "loading") {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Campaign list view
  if (viewMode === "list") {
    return (
      <CampaignList
        onNewCampaign={handleNewCampaign}
        onContinueCampaign={handleContinueCampaign}
      />
    );
  }

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Campaign Builder</h1>
          <p className="text-sm text-muted-foreground">Build and launch targeted outbound campaigns</p>
        </div>
        <div className="flex items-center gap-3">
          {lastSaved && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <CheckCircle className="h-3 w-3 text-success" />
              <span>Saved {lastSaved.toLocaleTimeString()}</span>
            </div>
          )}
          <button
            onClick={() => setViewMode("list")}
            className="text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline"
          >
            ← All Campaigns
          </button>
        </div>
      </div>

      {/* Phase Progress Bar */}
      <div className="sticky top-0 z-20 bg-background pb-4 pt-1 -mt-1">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs font-medium text-muted-foreground">Phase {phase} of {phases.length}</p>
          <p className="text-xs font-medium text-muted-foreground">{progressPct}%</p>
        </div>
        <div className="w-full h-1 bg-muted rounded-full mb-4 overflow-hidden">
          <motion.div className="h-full bg-primary rounded-full" initial={false} animate={{ width: `${progressPct}%` }} transition={{ duration: 0.3 }} />
        </div>
        <div className="flex items-center justify-between">
          {phases.map((p, i) => {
            const isCompleted = phase > p.num;
            const isCurrent = phase === p.num;
            const isClickable = p.num <= maxPhase + 1 && (p.num === 1 || selectedVertical || (campaignMode === "job_posting" && p.num === 2));
            return (
              <div key={p.num} className="flex items-center flex-1 last:flex-none">
                <button onClick={() => isClickable && goToPhase(p.num)} disabled={!isClickable} className="flex flex-col items-center gap-1.5 group">
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-200 ${isCompleted ? "bg-primary text-primary-foreground" : isCurrent ? "bg-primary text-primary-foreground ring-4 ring-primary/20" : "bg-muted text-muted-foreground border-2 border-border"} ${isClickable && !isCurrent ? "group-hover:border-primary/50 cursor-pointer" : ""}`}>
                    {isCompleted ? <Check className="h-4 w-4" /> : p.num}
                  </div>
                  <span className={`text-[10px] font-medium transition-colors ${isCurrent ? "text-foreground" : isCompleted ? "text-primary" : "text-muted-foreground"}`}>{p.label}</span>
                </button>
                {i < phases.length - 1 && (
                  <div className="flex-1 mx-1 h-0.5 mt-[-18px]">
                    <div className={`h-full rounded-full transition-colors ${phase > p.num ? "bg-primary" : "bg-border"}`} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Two-column layout */}
      <div className="flex gap-6">
        {/* Main content (60%) */}
        <div className="flex-1 min-w-0" style={{ flex: "0 0 60%" }}>
          <AnimatePresence mode="wait">
            {phase === 1 && (
              <motion.div key="phase1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <PhaseTarget verticals={verticals} selectedVertical={selectedVertical} onSelectVertical={handleSelectVertical} onCreateVertical={openCreate} onEditVertical={openEdit} signalWeights={signalWeights} onSignalWeightsChange={setSignalWeights} campaignMode={campaignMode} onCampaignModeChange={setCampaignMode} jobKeywords={jobKeywords} onJobKeywordsChange={setJobKeywords} jobLocation={jobLocation} onJobLocationChange={setJobLocation} onContinueJobPosting={() => setPhase(2)} />
              </motion.div>
            )}
            {phase === 2 && (selectedConfig || campaignMode === "job_posting") && (
              <motion.div key="phase2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                {campaignMode === "job_posting" ? (
                  <PhaseDiscoverJobs
                    jobKeywords={jobKeywords}
                    jobLocation={jobLocation}
                    onSelectCompanies={handleCompaniesSelected}
                  />
                ) : (
                  <PhaseDiscover vertical={selectedConfig!} signalWeights={signalWeights} onSelectCompanies={handleCompaniesSelected} showDebug={showDebug} />
                )}
                {selectedCompanies.length > 0 && (
                  <div className="flex justify-end mt-4">
                    <button onClick={() => setPhase(3)} className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                      Continue with {selectedCompanies.length} companies →
                    </button>
                  </div>
                )}
              </motion.div>
            )}
            {phase === 3 && (selectedConfig || campaignMode === "job_posting") && (
              <motion.div key="phase3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <ContactsStep
                  verticalName={selectedVertical || ""} verticalId={selectedConfig?.id}
                  buyerPersonas={selectedConfig?.buyerPersonas || []}
                  selectedCompanies={selectedCompanies.map((c) => ({
                    id: c.id, name: c.name, domain: c.domain, ai_tier: c.aiTier, basic_tier: c.basicTier,
                    ai_score: c.aiScore, basic_score: c.basicScore, logo_url: c.logoUrl, location: c.location, industry: c.industry,
                  }))}
                  apolloApiKey={serviceKeys.apollo || ""}
                  showDebug={showDebug}
                  onBack={() => setPhase(2)}
                  onNext={(selected) => { setSelectedContacts(selected); setPhase(4); }}
                />
              </motion.div>
            )}
            {phase === 4 && selectedConfig && (
              <motion.div key="phase4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <MessagesStep
                  verticalName={selectedVertical || ""} verticalId={selectedConfig?.id}
                  vertical={{
                    name: selectedConfig.name, description: selectedConfig.description, savings: selectedConfig.savings,
                    sellingPoints: selectedConfig.sellingPoints, usCostRange: selectedConfig.usCostRange,
                    obCostRange: selectedConfig.obCostRange, techStack: selectedConfig.techStack,
                    buyerPersonas: selectedConfig.buyerPersonas, jobTitlesToSearch: selectedConfig.jobTitlesToSearch,
                  }}
                  contacts={selectedContacts}
                  onBack={() => setPhase(3)}
                  onNext={(data) => { setLaunchData(data); setPhase(5); }}
                />
              </motion.div>
            )}
            {phase === 5 && launchData && (
              <motion.div key="phase5" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <LaunchStep
                  verticalName={selectedVertical || ""} verticalId={selectedConfig?.id}
                  contacts={selectedContacts} contactMessages={launchData.contactMessages}
                  sequence={launchData.sequence} generateLinkedIn={launchData.generateLinkedIn}
                  generateLinkedInDM={launchData.generateLinkedInDM} onBack={() => setPhase(4)}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Summary panel (40%) - sticky right column */}
        {(selectedVertical || (campaignMode === "job_posting" && phase >= 2)) && (
          <div className="hidden lg:block" style={{ flex: "0 0 36%" }}>
            <div className="sticky top-32">
              <Card>
                <CardContent className="p-5 space-y-4">
                  <h3 className="text-sm font-semibold">Campaign Summary</h3>
                  <div className="space-y-3">
                    <SummaryRow label="Mode" value={campaignMode === "job_posting" ? "Job Posting" : "Standard"} />
                    <SummaryRow label="Vertical" value={selectedVertical} />
                    {campaignMode === "job_posting" && jobKeywords.length > 0 && (
                      <SummaryRow label="Keywords" value={jobKeywords.join(", ")} />
                    )}
                    <SummaryRow label="Companies" value={selectedCompanies.length > 0 ? `${selectedCompanies.length} selected` : "—"} />
                    <SummaryRow label="Contacts" value={selectedContacts.length > 0 ? `${selectedContacts.length} selected` : "—"} />
                    <SummaryRow label="Ready to send" value={readyContacts > 0 ? `${readyContacts}` : "—"} accent={readyContacts > 0} />
                    <SummaryRow label="Est. send days" value={estimatedDays > 0 ? `~${estimatedDays} day(s)` : "—"} />

                    {/* Phase completion indicators */}
                    <div className="pt-3 border-t border-border space-y-1.5">
                      <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Phase Status</p>
                      {phases.map((p) => (
                        <div key={p.num} className="flex items-center gap-2 text-xs">
                          {phase > p.num ? (
                            <Check className="h-3 w-3 text-success" />
                          ) : phase === p.num ? (
                            <div className="h-3 w-3 rounded-full bg-primary animate-pulse" />
                          ) : (
                            <div className="h-3 w-3 rounded-full border border-border" />
                          )}
                          <span className={phase >= p.num ? "text-foreground" : "text-muted-foreground"}>{p.label}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      <VerticalBuilder open={builderOpen} onClose={() => setBuilderOpen(false)} onSave={handleSaveVertical} editingVertical={editingVertical} />
    </div>
  );
}

function SummaryRow({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-xs font-medium ${accent ? "text-success" : ""}`}>{value}</span>
    </div>
  );
}

// Exported for use in summary
export function computeContactCompleteness(contact: any): number {
  let score = 0;
  if (contact.email && contact.emailStatus === "verified") score += 40;
  else if (contact.email) score += 20;
  if (contact.linkedinUrl) score += 20;
  if (contact.phone) score += 15;
  if (contact.photoUrl) score += 5;
  return score;
}
