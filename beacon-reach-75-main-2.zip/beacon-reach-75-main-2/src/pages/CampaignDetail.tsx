import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ArrowLeft, Pause, Play, Mail, Clock, Eye, MessageSquare, XCircle, ChevronDown, Copy, Send, Pencil, X, RotateCcw, CalendarClock, CheckCircle2 } from "lucide-react";

const statusColor: Record<string, string> = {
  active: "bg-success text-success-foreground",
  paused: "bg-warning text-warning-foreground",
  completed: "bg-muted text-muted-foreground",
  draft: "bg-secondary text-secondary-foreground",
};

const stepPillStyle: Record<string, string> = {
  sent: "bg-emerald-100 text-emerald-700",
  scheduled: "bg-blue-100 text-blue-700",
  failed: "bg-red-100 text-red-700",
  replied: "bg-purple-100 text-purple-700",
  cancelled: "bg-muted text-muted-foreground",
  sending: "bg-amber-100 text-amber-700",
};

const stepHeaderStyle: Record<string, string> = {
  sent: "bg-emerald-50 border-emerald-200",
  scheduled: "bg-blue-50 border-blue-200",
  failed: "bg-red-50 border-red-200",
  replied: "bg-purple-50 border-purple-200",
  cancelled: "bg-muted/30 border-border",
  sending: "bg-amber-50 border-amber-200",
};

const stepTextStyle: Record<string, string> = {
  sent: "text-emerald-700",
  scheduled: "text-blue-700",
  failed: "text-red-700",
  replied: "text-purple-700",
  cancelled: "text-muted-foreground",
  sending: "text-amber-700",
};

export default function CampaignDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [campaign, setCampaign] = useState<any>(null);
  const [emailQueue, setEmailQueue] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [expandedContact, setExpandedContact] = useState<string | null>(null);
  const [editingStep, setEditingStep] = useState<string | null>(null);
  const [editSubject, setEditSubject] = useState("");
  const [editBody, setEditBody] = useState("");
  const [sendingStep, setSendingStep] = useState<string | null>(null);

  const [contactSearch, setContactSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  // Reschedule modal
  const [showRescheduleModal, setShowRescheduleModal] = useState(false);
  const [newStep2Day, setNewStep2Day] = useState(4);
  const [newStep3Day, setNewStep3Day] = useState(8);
  const [newStep4Day, setNewStep4Day] = useState(14);

  useEffect(() => {
    if (id) loadCampaignDetail(id);
  }, [id]);

  const loadCampaignDetail = async (campaignId: string) => {
    setLoading(true);
    const [{ data: camp }, { data: emails }] = await Promise.all([
      supabase.from("campaigns").select("*, vertical:verticals(name)").eq("id", campaignId).single(),
      supabase.from("email_queue").select("*").eq("campaign_id", campaignId).order("sequence_step", { ascending: true }),
    ]);
    setCampaign(camp);
    setEmailQueue(emails || []);
    setLoading(false);
  };

  const contactSequences = emailQueue.reduce((acc, email) => {
    if (!acc[email.contact_id]) {
      acc[email.contact_id] = { contactId: email.contact_id, toEmail: email.to_email, toName: email.to_name, steps: [] };
    }
    acc[email.contact_id].steps.push(email);
    return acc;
  }, {} as Record<string, any>);

  const filteredContacts = Object.values(contactSequences).filter((contact: any) => {
    if (contactSearch) {
      const q = contactSearch.toLowerCase();
      if (!contact.toName?.toLowerCase().includes(q) && !contact.toEmail?.toLowerCase().includes(q)) return false;
    }
    if (statusFilter === "active") return contact.steps.some((s: any) => s.status === "scheduled");
    if (statusFilter === "sent") return contact.steps.every((s: any) => s.status === "sent" || s.status === "cancelled");
    if (statusFilter === "failed") return contact.steps.some((s: any) => s.status === "failed");
    if (statusFilter === "replied") return contact.steps.some((s: any) => s.status === "replied" || s.replied_at);
    return true;
  });

  const stats = {
    total: emailQueue.length,
    sent: emailQueue.filter(e => e.status === "sent").length,
    scheduled: emailQueue.filter(e => e.status === "scheduled").length,
    failed: emailQueue.filter(e => e.status === "failed").length,
    replied: emailQueue.filter(e => e.status === "replied" || e.replied_at).length,
    opened: emailQueue.filter(e => e.opened_at).length,
  };

  /** Send an email using the edge function with email_account_id. */
  const handleSendNow = async (step: any) => {
    setSendingStep(step.id);

    const { data: optOut } = await supabase
      .from("email_optouts").select("id").eq("email", step.to_email).maybeSingle();

    if (optOut) {
      toast.error(`${step.to_email} has opted out. Cannot send.`);
      await supabase.from("email_queue").update({ status: "cancelled", error_message: "Contact opted out" }).eq("id", step.id);
      await loadCampaignDetail(id!);
      setSendingStep(null);
      return;
    }

    // Find the email account used for this campaign
    const emailAccountId = step.email_account_id;
    if (!emailAccountId) {
      // Fallback: find any active account for the user
      const { data: emailAccount } = await supabase
        .from("email_accounts").select("id").eq("user_id", user!.id).eq("is_active", true).limit(1).single();

      if (!emailAccount) {
        toast.error("No Gmail account connected. Connect one in Settings.");
        setSendingStep(null);
        return;
      }
      step.email_account_id = emailAccount.id;
    }

    try {
      const result = await supabase.functions.invoke("gmail-oauth", {
        body: {
          action: "send",
          email_account_id: step.email_account_id,
          to: step.to_email,
          subject: step.subject,
          body: step.body,
          replyToMessageId: step.reply_to_message_id,
        },
      });

      if (result.data?.success) {
        await supabase.from("email_queue").update({
          status: "sent",
          sent_at: new Date().toISOString(),
          error_message: null,
          gmail_message_id: result.data.gmail_message_id || null,
          thread_id: result.data.gmail_thread_id || null,
          updated_at: new Date().toISOString(),
        }).eq("id", step.id);
        toast.success(`Email sent to ${step.to_email}!`);
      } else {
        await supabase.from("email_queue").update({
          status: "failed", error_message: result.data?.error || "Send failed", updated_at: new Date().toISOString(),
        }).eq("id", step.id);
        toast.error(`Send failed: ${result.data?.error || "Unknown error"}`);
      }
      await loadCampaignDetail(id!);
    } catch (e: any) {
      toast.error(`Error: ${e.message}`);
    }
    setSendingStep(null);
  };

  const handleSaveEdit = async (stepId: string) => {
    await supabase.from("email_queue").update({
      subject: editSubject, body: editBody, updated_at: new Date().toISOString(),
    }).eq("id", stepId);
    setEditingStep(null);
    toast.success("Email updated");
    await loadCampaignDetail(id!);
  };

  const handleSaveAndSend = async (step: any) => {
    await supabase.from("email_queue").update({
      subject: editSubject, body: editBody, updated_at: new Date().toISOString(),
    }).eq("id", step.id);
    setEditingStep(null);
    await handleSendNow({ ...step, subject: editSubject, body: editBody });
  };

  const handleCancelStep = async (stepId: string) => {
    await supabase.from("email_queue").update({ status: "cancelled", updated_at: new Date().toISOString() }).eq("id", stepId);
    toast.success("Step cancelled");
    await loadCampaignDetail(id!);
  };

  const handleCancelAllForContact = async (contactId: string) => {
    await supabase.from("email_queue").update({ status: "cancelled", updated_at: new Date().toISOString() })
      .eq("campaign_id", id).eq("contact_id", contactId).eq("status", "scheduled");
    toast.success("All scheduled steps cancelled for this contact");
    await loadCampaignDetail(id!);
  };

  const handlePauseCampaign = async () => {
    await supabase.from("campaigns").update({ status: "paused", updated_at: new Date().toISOString() }).eq("id", id!);
    await supabase.from("email_queue").update({ status: "cancelled" }).eq("campaign_id", id!).eq("status", "scheduled");
    toast.success("Campaign paused. Scheduled emails cancelled.");
    loadCampaignDetail(id!);
  };

  const handleResumeCampaign = async () => {
    await supabase.from("campaigns").update({ status: "active", updated_at: new Date().toISOString() }).eq("id", id!);
    const { data: cancelled } = await supabase.from("email_queue").select("*").eq("campaign_id", id!).eq("status", "cancelled");
    if (cancelled && cancelled.length > 0) {
      const now = new Date();
      const dayOffsets: Record<number, number> = { 2: 3, 3: 7, 4: 13 };
      for (const email of cancelled) {
        const newDate = new Date(now);
        newDate.setDate(newDate.getDate() + (dayOffsets[email.sequence_step] || 3));
        await supabase.from("email_queue").update({ status: "scheduled", scheduled_at: newDate.toISOString(), updated_at: new Date().toISOString() }).eq("id", email.id);
      }
    }
    toast.success("Campaign resumed. Follow-up emails rescheduled.");
    loadCampaignDetail(id!);
  };

  const handleRescheduleStep = async (stepId: string, newDate: string) => {
    const existing = emailQueue.find(e => e.id === stepId);
    const existingTime = existing?.scheduled_at ? new Date(existing.scheduled_at).toTimeString().slice(0, 5) : "08:00";
    const newDateTime = `${newDate}T${existingTime}:00`;

    await supabase.from("email_queue").update({
      scheduled_at: new Date(newDateTime).toISOString(), updated_at: new Date().toISOString(),
    }).eq("id", stepId);

    toast.success("Step rescheduled");
    await loadCampaignDetail(id!);
  };

  const handleRescheduleStepTime = async (stepId: string, newTime: string) => {
    const existing = emailQueue.find(e => e.id === stepId);
    const existingDate = existing?.scheduled_at ? new Date(existing.scheduled_at).toISOString().split("T")[0] : new Date().toISOString().split("T")[0];
    const newDateTime = `${existingDate}T${newTime}:00`;

    await supabase.from("email_queue").update({
      scheduled_at: new Date(newDateTime).toISOString(), updated_at: new Date().toISOString(),
    }).eq("id", stepId);

    toast.success("Send time updated");
    await loadCampaignDetail(id!);
  };

  const handleBulkReschedule = async () => {
    const step1Emails = emailQueue.filter(e => e.sequence_step === 1 && e.status === "sent");
    const dayOffsets: Record<number, number> = { 2: newStep2Day - 1, 3: newStep3Day - 1, 4: newStep4Day - 1 };
    let updated = 0;

    for (const step1 of step1Emails) {
      const sentDate = new Date(step1.sent_at || step1.scheduled_at);
      for (const [stepNum, dayOffset] of Object.entries(dayOffsets)) {
        const newDate = new Date(sentDate);
        newDate.setDate(newDate.getDate() + dayOffset);
        newDate.setHours(8, 0, 0, 0);

        const { error } = await supabase
          .from("email_queue")
          .update({ scheduled_at: newDate.toISOString(), updated_at: new Date().toISOString() })
          .eq("campaign_id", id)
          .eq("contact_id", step1.contact_id)
          .eq("sequence_step", parseInt(stepNum))
          .eq("status", "scheduled");

        if (!error) updated++;
      }
    }

    setShowRescheduleModal(false);
    toast.success(`Rescheduled ${updated} follow-up emails`);
    await loadCampaignDetail(id!);
  };

  const handleQuickMarkReplied = async (contact: any) => {
    const step1 = contact.steps.find((s: any) => s.status === "sent");
    if (!step1) return;

    await supabase.from("email_replies").insert({
      email_queue_id: step1.id,
      campaign_id: id,
      contact_id: contact.contactId,
      from_email: contact.toEmail,
      from_name: contact.toName,
      subject: `Re: ${step1.subject}`,
      body_text: "(Logged manually from campaign detail)",
      received_at: new Date().toISOString(),
      is_read: false,
      assigned_to: user?.id,
    });

    await supabase
      .from("email_queue")
      .update({ status: "cancelled", error_message: "Contact replied" })
      .eq("campaign_id", id)
      .eq("contact_id", contact.contactId)
      .eq("status", "scheduled");

    await supabase
      .from("email_queue")
      .update({ status: "replied", replied_at: new Date().toISOString() })
      .eq("id", step1.id);

    toast.success(`${contact.toName} marked as replied. Remaining steps cancelled.`);
    loadCampaignDetail(id!);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Campaign not found</p>
        <Button onClick={() => navigate("/")} variant="outline" className="mt-4">Back to Dashboard</Button>
      </div>
    );
  }

  const verticalName = Array.isArray(campaign.vertical)
    ? campaign.vertical[0]?.name || ""
    : campaign.vertical?.name || "";

  const dayLabel = (step: number) => ({ 1: "Day 1", 2: "Day 4", 3: "Day 8", 4: "Day 14" }[step] || `Step ${step}`);

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <button onClick={() => navigate("/")} className="text-xs text-muted-foreground hover:text-foreground mb-2 inline-flex items-center gap-1">
            <ArrowLeft className="h-3 w-3" /> Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold tracking-tight">{campaign.name}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {verticalName} · Created {new Date(campaign.created_at).toLocaleDateString()}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={`${statusColor[campaign.status] || statusColor.draft} text-xs uppercase`}>
            {campaign.status}
          </Badge>
          {campaign.status === "active" && stats.scheduled > 0 && (
            <Button onClick={() => setShowRescheduleModal(true)} variant="outline" size="sm" className="gap-1">
              <CalendarClock className="h-3 w-3" /> Reschedule
            </Button>
          )}
          {campaign.status === "active" && (
            <Button onClick={handlePauseCampaign} variant="outline" size="sm" className="gap-1">
              <Pause className="h-3 w-3" /> Pause
            </Button>
          )}
          {campaign.status === "paused" && (
            <Button onClick={handleResumeCampaign} size="sm" className="gap-1">
              <Play className="h-3 w-3" /> Resume
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        {[
          { label: "Sent", value: stats.sent, icon: Mail },
          { label: "Scheduled", value: stats.scheduled, icon: Clock },
          { label: "Opened", value: stats.opened, icon: Eye },
          { label: "Replied", value: stats.replied, icon: MessageSquare },
          { label: "Failed", value: stats.failed, icon: XCircle },
        ].map(s => (
          <Card key={s.label}>
            <CardContent className="p-4 text-center">
              <s.icon className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
              <p className="text-xl font-bold">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Contact sequences */}
      <Card>
        <div className="px-6 py-4 border-b border-border bg-muted/20 flex items-center gap-4 flex-wrap">
          <CardTitle className="text-base font-semibold">Contact Sequences</CardTitle>
          <div className="flex-1" />
          <input
            type="text"
            placeholder="Search contacts..."
            value={contactSearch}
            onChange={e => setContactSearch(e.target.value)}
            className="px-3 py-1.5 border border-border rounded-lg text-xs w-48 bg-background"
          />
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 border border-border rounded-lg text-xs bg-background"
          >
            <option value="all">All statuses</option>
            <option value="active">Has scheduled</option>
            <option value="sent">All sent</option>
            <option value="failed">Has failed</option>
            <option value="replied">Has replies</option>
          </select>
          <span className="text-xs text-muted-foreground">{filteredContacts.length} contacts</span>
        </div>

        <CardContent className="p-0">
          {filteredContacts.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No contacts match your filters</p>
          ) : (
            filteredContacts.map((contact: any) => {
              const isExpanded = expandedContact === contact.contactId;

              return (
                <div key={contact.contactId} className="border-b border-border last:border-0">
                  <button
                    onClick={() => setExpandedContact(isExpanded ? null : contact.contactId)}
                    className="w-full flex items-center gap-3 px-6 py-4 hover:bg-muted/20 transition-colors text-left"
                  >
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-xs font-semibold text-primary flex-shrink-0">
                      {contact.toName?.split(" ").map((n: string) => n[0]).join("").slice(0, 2) || "?"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{contact.toName || "Unknown"}</p>
                      <p className="text-xs text-muted-foreground font-mono">{contact.toEmail}</p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {contact.steps.map((step: any) => (
                        <div
                          key={step.id}
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-medium ${stepPillStyle[step.status] || "bg-muted text-muted-foreground"}`}
                          title={`Step ${step.sequence_step}: ${step.status}`}
                        >
                          {step.sequence_step}
                        </div>
                      ))}
                    </div>
                    <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ${isExpanded ? "rotate-180" : ""}`} />
                  </button>

                  {isExpanded && (
                    <div className="px-6 pb-6 space-y-4">
                      {contact.steps.map((step: any) => {
                        const isEditing = editingStep === step.id;
                        const isSending = sendingStep === step.id;
                        const status = step.status || "scheduled";

                        return (
                          <div key={step.id} className={`rounded-xl border overflow-hidden ${stepHeaderStyle[status]?.split(" ")[1] || "border-border"}`}>
                            <div className={`px-4 py-2.5 flex items-center justify-between ${stepHeaderStyle[status]?.split(" ")[0] || "bg-muted/30"}`}>
                              <div className="flex items-center gap-3">
                                <span className="text-xs font-mono font-medium px-2 py-0.5 bg-background/70 rounded">
                                  {dayLabel(step.sequence_step)}
                                </span>
                                <span className={`text-xs font-medium ${stepTextStyle[status] || "text-muted-foreground"}`}>
                                  {status === "sent" && `Sent ${new Date(step.sent_at).toLocaleDateString()} at ${new Date(step.sent_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`}
                                  {status === "scheduled" && `Scheduled for ${new Date(step.scheduled_at).toLocaleDateString()}`}
                                  {status === "sending" && "Sending..."}
                                  {status === "failed" && "Failed to send"}
                                  {status === "replied" && `Replied ${step.replied_at ? new Date(step.replied_at).toLocaleDateString() : ""}`}
                                  {status === "cancelled" && "Cancelled"}
                                </span>
                              </div>

                              <div className="flex items-center gap-2">
                                {(status === "scheduled" || status === "failed") && !isEditing && (
                                  <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={e => {
                                    e.stopPropagation();
                                    setEditingStep(step.id);
                                    setEditSubject(step.subject);
                                    setEditBody(step.body);
                                  }}>
                                    <Pencil className="h-3 w-3" /> Edit
                                  </Button>
                                )}
                                {status === "scheduled" && !isEditing && (
                                  <Button size="sm" className="h-7 text-xs gap-1" disabled={isSending} onClick={e => {
                                    e.stopPropagation();
                                    handleSendNow(step);
                                  }}>
                                    <Send className="h-3 w-3" /> {isSending ? "Sending..." : "Send Now"}
                                  </Button>
                                )}
                                {status === "failed" && (
                                  <Button size="sm" variant="destructive" className="h-7 text-xs gap-1" disabled={isSending} onClick={e => {
                                    e.stopPropagation();
                                    handleSendNow(step);
                                  }}>
                                    <RotateCcw className="h-3 w-3" /> {isSending ? "Retrying..." : "Retry"}
                                  </Button>
                                )}
                                {status === "scheduled" && (
                                  <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground hover:text-destructive" onClick={e => {
                                    e.stopPropagation();
                                    handleCancelStep(step.id);
                                  }}>
                                    <X className="h-3 w-3" /> Cancel
                                  </Button>
                                )}
                                <Button variant="ghost" size="sm" className="h-7 text-xs text-muted-foreground" onClick={e => {
                                  e.stopPropagation();
                                  navigator.clipboard.writeText(`Subject: ${step.subject}\n\n${step.body}`);
                                  toast.success("Email copied to clipboard");
                                }}>
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>

                            <div className="px-4 py-4">
                              {isEditing ? (
                                <div className="space-y-3">
                                  <div>
                                    <label className="text-xs font-medium text-muted-foreground">Subject</label>
                                    <input value={editSubject} onChange={e => setEditSubject(e.target.value)}
                                      className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm bg-background" />
                                  </div>
                                  <div>
                                    <label className="text-xs font-medium text-muted-foreground">Body</label>
                                    <textarea value={editBody} onChange={e => setEditBody(e.target.value)} rows={8}
                                      className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm font-mono bg-background" />
                                  </div>
                                  <div className="flex gap-2">
                                    <Button size="sm" onClick={() => handleSaveEdit(step.id)}>Save Changes</Button>
                                    <Button size="sm" variant="outline" className="bg-emerald-600 text-white hover:bg-emerald-700 border-0" onClick={() => handleSaveAndSend(step)}>
                                      Save & Send Now
                                    </Button>
                                    <Button size="sm" variant="outline" onClick={() => setEditingStep(null)}>Cancel</Button>
                                  </div>
                                </div>
                              ) : (
                                <div>
                                  <p className="text-xs font-medium text-muted-foreground mb-1">Subject:</p>
                                  <p className="text-sm font-medium mb-3">{step.subject}</p>
                                  <p className="text-xs font-medium text-muted-foreground mb-1">Body:</p>
                                  <div className="text-sm whitespace-pre-wrap leading-relaxed text-foreground/80 bg-muted/20 rounded-lg p-3">
                                    {step.body}
                                  </div>

                                  {/* Reschedule controls for scheduled steps */}
                                  {status === "scheduled" && (
                                    <div className="mt-3 flex items-center gap-2 flex-wrap">
                                      <span className="text-xs text-muted-foreground">Reschedule:</span>
                                      <input
                                        type="date"
                                        defaultValue={new Date(step.scheduled_at).toISOString().split("T")[0]}
                                        onChange={e => handleRescheduleStep(step.id, e.target.value)}
                                        className="px-2 py-1 border border-border rounded text-xs bg-background"
                                      />
                                      <input
                                        type="time"
                                        defaultValue={new Date(step.scheduled_at).toTimeString().slice(0, 5)}
                                        onChange={e => handleRescheduleStepTime(step.id, e.target.value)}
                                        className="px-2 py-1 border border-border rounded text-xs bg-background"
                                      />
                                    </div>
                                  )}

                                  {status === "failed" && step.error_message && (
                                    <div className="mt-3 p-2 bg-destructive/10 border border-destructive/20 rounded-lg">
                                      <p className="text-xs text-destructive">Error: {step.error_message}</p>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      <div className="pt-2 flex items-center gap-4">
                        {contact.steps.some((s: any) => s.status === "sent") && !contact.steps.some((s: any) => s.status === "replied") && (
                          <button
                            onClick={() => handleQuickMarkReplied(contact)}
                            className="text-xs text-emerald-600 hover:underline inline-flex items-center gap-1"
                          >
                            <CheckCircle2 className="h-3 w-3" /> Mark as replied
                          </button>
                        )}
                        {contact.steps.some((s: any) => s.status === "scheduled") && (
                          <button onClick={() => handleCancelAllForContact(contact.contactId)}
                            className="text-xs text-muted-foreground hover:text-destructive transition-colors">
                            Cancel all remaining steps
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </CardContent>
      </Card>

      {/* Bulk Reschedule Modal */}
      {showRescheduleModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-xl border border-border p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-semibold">Reschedule Sequence</h3>
            <p className="text-sm text-muted-foreground">
              Adjust the timing for remaining follow-up steps. This only affects scheduled (not yet sent) emails.
            </p>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <span className="w-16 text-muted-foreground">Step 2:</span>
                <span>Send</span>
                <input
                  type="number"
                  min={2}
                  max={30}
                  value={newStep2Day}
                  onChange={e => setNewStep2Day(parseInt(e.target.value) || 4)}
                  className="w-16 px-2 py-1 border border-border rounded text-sm text-center bg-background"
                />
                <span>days after Step 1</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="w-16 text-muted-foreground">Step 3:</span>
                <span>Send</span>
                <input
                  type="number"
                  min={3}
                  max={60}
                  value={newStep3Day}
                  onChange={e => setNewStep3Day(parseInt(e.target.value) || 8)}
                  className="w-16 px-2 py-1 border border-border rounded text-sm text-center bg-background"
                />
                <span>days after Step 1</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="w-16 text-muted-foreground">Step 4:</span>
                <span>Send</span>
                <input
                  type="number"
                  min={4}
                  max={90}
                  value={newStep4Day}
                  onChange={e => setNewStep4Day(parseInt(e.target.value) || 14)}
                  className="w-16 px-2 py-1 border border-border rounded text-sm text-center bg-background"
                />
                <span>days after Step 1</span>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowRescheduleModal(false)}>
                Cancel
              </Button>
              <Button className="flex-1" onClick={handleBulkReschedule}>
                Apply New Schedule
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
