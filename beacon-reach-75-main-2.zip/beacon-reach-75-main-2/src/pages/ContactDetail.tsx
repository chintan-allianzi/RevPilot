import { useEffect, useState, useMemo } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import ComposeEmailDialog from "@/components/ComposeEmailDialog";
import {
  Mail, Phone, Linkedin, User, Building2, Globe, MapPin,
  ChevronRight, MessageSquare, Activity, Briefcase, CheckSquare,
  Send, ExternalLink, Loader2, Edit2, Check, X, Plus, DollarSign,
  Clock, Calendar,
} from "lucide-react";

export default function ContactDetail() {
  const { contactId } = useParams<{ contactId: string }>();
  const navigate = useNavigate();

  const [contact, setContact] = useState<any>(null);
  const [company, setCompany] = useState<any>(null);
  const [vertical, setVertical] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Communication
  const [emailsSent, setEmailsSent] = useState<any[]>([]);
  const [emailsReceived, setEmailsReceived] = useState<any[]>([]);

  // Deals
  const [deals, setDeals] = useState<any[]>([]);
  const [stages, setStages] = useState<any[]>([]);

  // Activities (aggregated from all deals)
  const [activities, setActivities] = useState<any[]>([]);

  // Tasks (aggregated from all deals)
  const [tasks, setTasks] = useState<any[]>([]);

  // Inline editing
  const [editField, setEditField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  // Compose
  const [composeOpen, setComposeOpen] = useState(false);
  const [composeProps, setComposeProps] = useState<any>({});

  useEffect(() => {
    if (contactId) loadContact();
  }, [contactId]);

  const loadContact = async () => {
    if (!contactId) return;
    setLoading(true);

    const { data: c, error } = await supabase
      .from("saved_contacts")
      .select("*")
      .eq("id", contactId)
      .single();

    if (error || !c) {
      toast.error("Contact not found");
      navigate("/contacts");
      return;
    }
    setContact(c);

    // Parallel loads
    const promises: Promise<any>[] = [
      supabase.from("lead_stages").select("*").order("stage_order").then(r => { setStages(r.data || []); }) as unknown as Promise<any>,
      supabase.from("email_queue").select("*").eq("contact_id", contactId).order("scheduled_at", { ascending: false }).then(r => { setEmailsSent(r.data || []); }) as unknown as Promise<any>,
      supabase.from("email_replies").select("*").eq("contact_id", contactId).order("received_at", { ascending: false }).then(r => { setEmailsReceived(r.data || []); }) as unknown as Promise<any>,
      loadDealsAndRelated(contactId),
    ];

    if (c.company_id) {
      promises.push(supabase.from("saved_companies").select("*").eq("id", c.company_id).single().then(r => { setCompany(r.data); }) as unknown as Promise<any>);
    }
    if (c.vertical_id) {
      promises.push(supabase.from("verticals").select("id, name, icon").eq("id", c.vertical_id).single().then(r => { setVertical(r.data); }) as unknown as Promise<any>);
    }

    await Promise.all(promises);
    setLoading(false);
  };

  const loadDealsAndRelated = async (cId: string) => {
    const { data: dealRows } = await supabase
      .from("deals")
      .select("*")
      .eq("contact_id", cId)
      .order("created_at", { ascending: false });

    const d = dealRows || [];
    setDeals(d);

    if (d.length > 0) {
      const dealIds = d.map(dl => dl.id);
      const [actRes, taskRes] = await Promise.all([
        supabase.from("deal_activities").select("*").in("deal_id", dealIds).order("activity_date", { ascending: false }).limit(50),
        supabase.from("deal_tasks").select("*").in("deal_id", dealIds).order("due_date"),
      ]);
      setActivities(actRes.data || []);
      setTasks(taskRes.data || []);
    } else {
      setActivities([]);
      setTasks([]);
    }
  };

  // Inline edit save
  const saveField = async (field: string) => {
    if (!contact) return;
    const updates: any = { [field]: editValue.trim() || null };
    await supabase.from("saved_contacts").update(updates).eq("id", contact.id);
    setContact((prev: any) => ({ ...prev, ...updates }));
    setEditField(null);
    toast.success("Updated");
  };

  const startEdit = (field: string, current: string) => {
    setEditField(field);
    setEditValue(current || "");
  };

  // Conversations — merge sent + received chronologically
  const conversations = useMemo(() => {
    const items: any[] = [];
    emailsSent.forEach(e => items.push({ ...e, _type: "sent", _date: e.sent_at || e.scheduled_at }));
    emailsReceived.forEach(e => items.push({ ...e, _type: "received", _date: e.received_at }));
    items.sort((a, b) => new Date(b._date).getTime() - new Date(a._date).getTime());
    return items;
  }, [emailsSent, emailsReceived]);

  const openCompose = () => {
    const lastSent = emailsSent.find(e => e.gmail_message_id && e.status === "sent");
    setComposeProps({
      toEmail: contact?.email || "",
      toName: `${contact?.first_name || ""} ${contact?.last_name || ""}`.trim(),
      subject: "",
      body: "",
      activityType: "email_sent",
      inReplyToMessageId: lastSent?.gmail_message_id || undefined,
    });
    setComposeOpen(true);
  };

  const getStageName = (stageId: string) => stages.find(s => s.id === stageId)?.stage_name || "Unknown";

  if (loading) {
    return (
      <div className="flex items-center justify-center py-32 gap-2 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" /> Loading contact...
      </div>
    );
  }

  if (!contact) return null;

  const fullName = `${contact.first_name || ""} ${contact.last_name || ""}`.trim();
  const initials = (contact.first_name?.[0] || "") + (contact.last_name?.[0] || "");
  const tier = company?.ai_tier || company?.basic_tier || null;

  const ACTIVITY_ICON: Record<string, any> = {
    email_sent: Mail,
    email_received: Mail,
    stage_change: Activity,
    note: MessageSquare,
    call: Phone,
    meeting: Calendar,
    proposal: Send,
  };

  const ACTIVITY_COLOR: Record<string, string> = {
    email_sent: "border-l-blue-500",
    email_received: "border-l-emerald-500",
    stage_change: "border-l-purple-500",
    note: "border-l-muted-foreground",
    call: "border-l-amber-500",
    meeting: "border-l-primary",
    proposal: "border-l-primary",
  };

  const EditableField = ({ field, label, icon: Icon, value }: { field: string; label: string; icon: any; value: string | null }) => (
    <div className="flex items-center gap-2 group py-1">
      <Icon className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
      {editField === field ? (
        <div className="flex items-center gap-1 flex-1">
          <Input
            value={editValue}
            onChange={e => setEditValue(e.target.value)}
            className="h-7 text-sm"
            autoFocus
            onKeyDown={e => { if (e.key === "Enter") saveField(field); if (e.key === "Escape") setEditField(null); }}
          />
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => saveField(field)}><Check className="h-3 w-3" /></Button>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditField(null)}><X className="h-3 w-3" /></Button>
        </div>
      ) : (
        <div className="flex items-center gap-1 flex-1 min-w-0">
          <span className="text-sm text-foreground truncate">{value || <span className="text-muted-foreground italic">Add {label.toLowerCase()}</span>}</span>
          <button onClick={() => startEdit(field, value || "")} className="opacity-0 group-hover:opacity-100 transition-opacity">
            <Edit2 className="h-3 w-3 text-muted-foreground" />
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1 text-sm text-muted-foreground">
        <Link to="/contacts" className="hover:text-foreground transition-colors">Contacts</Link>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="text-foreground font-medium">{fullName}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-6">
        {/* LEFT — Contact Profile */}
        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
          <Card className="border-border">
            <CardContent className="p-5 space-y-4">
              {/* Avatar + name */}
              <div className="flex items-center gap-3">
                <Avatar className="h-14 w-14">
                  {contact.photo_url ? <AvatarImage src={contact.photo_url} /> : null}
                  <AvatarFallback className="text-lg font-bold bg-primary/10 text-primary">{initials}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <h2 className="text-lg font-bold text-foreground truncate">{fullName}</h2>
                  <p className="text-sm text-muted-foreground truncate">{contact.title || "No title"}</p>
                </div>
              </div>

              {/* Badges */}
              <div className="flex flex-wrap gap-1.5">
                {contact.status && (
                  <Badge variant="secondary" className="text-[10px]">{contact.status}</Badge>
                )}
                {tier && (
                  <Badge variant="outline" className="text-[10px]">{tier}</Badge>
                )}
                {contact.email_status && (
                  <Badge variant="outline" className="text-[10px]">
                    <div className={`h-1.5 w-1.5 rounded-full mr-1 ${contact.email_status === "verified" ? "bg-emerald-500" : "bg-amber-500"}`} />
                    {contact.email_status}
                  </Badge>
                )}
                {contact.opted_out && (
                  <Badge variant="destructive" className="text-[10px]">Opted Out</Badge>
                )}
                {vertical && (
                  <Badge className="text-[10px] bg-primary/10 text-primary border-primary/20">{vertical.name}</Badge>
                )}
              </div>

              <Separator />

              {/* Editable fields */}
              <div className="space-y-1">
                <EditableField field="email" label="Email" icon={Mail} value={contact.email} />
                <EditableField field="phone" label="Phone" icon={Phone} value={contact.phone} />
                <EditableField field="title" label="Title" icon={User} value={contact.title} />
                {contact.linkedin_url ? (
                  <div className="flex items-center gap-2 py-1">
                    <Linkedin className="h-3.5 w-3.5 text-muted-foreground" />
                    <a href={contact.linkedin_url.startsWith("http") ? contact.linkedin_url : `https://${contact.linkedin_url}`} target="_blank" rel="noreferrer" className="text-sm text-primary hover:underline truncate flex items-center gap-1">
                      LinkedIn <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                ) : (
                  <EditableField field="linkedin_url" label="LinkedIn" icon={Linkedin} value={null} />
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                {contact.email && (
                  <Button size="sm" className="gap-1.5 flex-1" onClick={openCompose}>
                    <Send className="h-3.5 w-3.5" /> Email
                  </Button>
                )}
                {contact.linkedin_url && (
                  <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.open(contact.linkedin_url.startsWith("http") ? contact.linkedin_url : `https://${contact.linkedin_url}`, "_blank")}>
                    <Linkedin className="h-3.5 w-3.5" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Company Info */}
          {company && (
            <Card className="border-border">
              <CardContent className="p-5 space-y-2">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <h3 className="text-sm font-semibold text-foreground">{company.name}</h3>
                </div>
                {company.industry && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Globe className="h-3.5 w-3.5" /> {company.industry}
                  </div>
                )}
                {(company.city || company.state || company.country) && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" /> {[company.city, company.state, company.country].filter(Boolean).join(", ")}
                  </div>
                )}
                {company.domain && (
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                    <a href={`https://${company.domain}`} target="_blank" rel="noreferrer" className="text-primary hover:underline">{company.domain}</a>
                  </div>
                )}
                {company.employees && (
                  <p className="text-xs text-muted-foreground">{company.employees.toLocaleString()} employees · {company.revenue || "—"}</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Quick Stats */}
          <Card className="border-border">
            <CardContent className="p-4 grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-lg font-bold text-foreground">{deals.length}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Deals</p>
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">{conversations.length}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Emails</p>
              </div>
              <div>
                <p className="text-lg font-bold text-foreground">{activities.length}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Activities</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* RIGHT — Tabbed Content */}
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Tabs defaultValue="conversations" className="w-full">
            <TabsList className="w-full justify-start bg-muted/50">
              <TabsTrigger value="conversations" className="gap-1.5"><MessageSquare className="h-3.5 w-3.5" /> Conversations</TabsTrigger>
              <TabsTrigger value="activity" className="gap-1.5"><Activity className="h-3.5 w-3.5" /> Activity</TabsTrigger>
              <TabsTrigger value="deals" className="gap-1.5"><Briefcase className="h-3.5 w-3.5" /> Deals ({deals.length})</TabsTrigger>
              <TabsTrigger value="tasks" className="gap-1.5"><CheckSquare className="h-3.5 w-3.5" /> Tasks ({tasks.length})</TabsTrigger>
            </TabsList>

            {/* CONVERSATIONS */}
            <TabsContent value="conversations" className="space-y-3 mt-4">
              {contact.email && (
                <div className="flex justify-end">
                  <Button size="sm" className="gap-1.5" onClick={openCompose}>
                    <Plus className="h-3.5 w-3.5" /> New Email
                  </Button>
                </div>
              )}
              {conversations.length === 0 ? (
                <div className="py-16 text-center">
                  <MessageSquare className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No conversations yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {conversations.map((msg) => {
                    const isSent = msg._type === "sent";
                    return (
                      <div key={msg.id} className={`flex ${isSent ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[80%] rounded-xl p-3 ${isSent ? "bg-primary/10 border border-primary/20" : "bg-muted border border-border"}`}>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-[9px]">{isSent ? "Sent" : "Received"}</Badge>
                            <span className="text-[10px] text-muted-foreground">
                              {new Date(msg._date).toLocaleDateString()} {new Date(msg._date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </span>
                          </div>
                          <p className="text-xs font-medium text-foreground mb-1">{msg.subject || "(no subject)"}</p>
                          <p className="text-xs text-muted-foreground line-clamp-4 whitespace-pre-wrap">
                            {isSent ? msg.body : (msg.body_text || msg.body_html?.replace(/<[^>]+>/g, "") || "")}
                          </p>
                          {isSent && msg.status && (
                            <Badge variant="secondary" className="text-[9px] mt-2">{msg.status}</Badge>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            {/* ACTIVITY */}
            <TabsContent value="activity" className="space-y-2 mt-4">
              {activities.length === 0 ? (
                <div className="py-16 text-center">
                  <Activity className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No activity yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {activities.map((a) => {
                    const Icon = ACTIVITY_ICON[a.activity_type] || Activity;
                    const color = ACTIVITY_COLOR[a.activity_type] || "border-l-muted-foreground";
                    return (
                      <div key={a.id} className={`border-l-[3px] ${color} pl-3 py-2 bg-card rounded-r-lg border border-border border-l-0`}>
                        <div className="flex items-center gap-2">
                          <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                          <span className="text-sm font-medium text-foreground">{a.subject}</span>
                          <span className="text-[10px] text-muted-foreground ml-auto">
                            {new Date(a.activity_date).toLocaleDateString()}
                          </span>
                        </div>
                        {a.description && (
                          <p className="text-xs text-muted-foreground mt-1 pl-5">{a.description}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            {/* DEALS */}
            <TabsContent value="deals" className="space-y-3 mt-4">
              {deals.length === 0 ? (
                <div className="py-16 text-center">
                  <Briefcase className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No deals linked to this contact</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {deals.map((d) => {
                    const stageName = getStageName(d.stage_id);
                    const daysInStage = Math.floor((Date.now() - new Date(d.updated_at).getTime()) / 86400000);
                    return (
                      <Link key={d.id} to={`/pipeline/${d.id}`} className="block">
                        <Card className="border-border hover:border-primary/30 transition-colors cursor-pointer">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm font-semibold text-foreground">{d.deal_name}</p>
                                <div className="flex items-center gap-3 mt-1">
                                  <Badge variant="secondary" className="text-[10px]">{stageName}</Badge>
                                  {d.deal_value && (
                                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                                      <DollarSign className="h-3 w-3" />{Number(d.deal_value).toLocaleString()}
                                    </span>
                                  )}
                                  <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                    <Clock className="h-3 w-3" />{daysInStage}d in stage
                                  </span>
                                </div>
                              </div>
                              <ChevronRight className="h-4 w-4 text-muted-foreground" />
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            {/* TASKS */}
            <TabsContent value="tasks" className="space-y-2 mt-4">
              {tasks.length === 0 ? (
                <div className="py-16 text-center">
                  <CheckSquare className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No tasks for this contact's deals</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {tasks.map((t) => {
                    const overdue = t.status !== "completed" && new Date(t.due_date) < new Date();
                    return (
                      <div key={t.id} className={`flex items-center gap-3 p-3 rounded-lg border ${t.status === "completed" ? "bg-muted/30 border-border" : overdue ? "border-destructive/30 bg-destructive/5" : "border-border bg-card"}`}>
                        <div className={`h-2 w-2 rounded-full flex-shrink-0 ${t.status === "completed" ? "bg-emerald-500" : overdue ? "bg-destructive" : t.priority === "high" ? "bg-amber-500" : "bg-muted-foreground/30"}`} />
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm ${t.status === "completed" ? "line-through text-muted-foreground" : "text-foreground"}`}>{t.title}</p>
                          <p className="text-[10px] text-muted-foreground">Due {new Date(t.due_date).toLocaleDateString()} · {t.priority}</p>
                        </div>
                        <Badge variant="secondary" className="text-[9px]">{t.status}</Badge>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      {/* Compose Email Dialog */}
      {composeOpen && (
        <ComposeEmailDialog
          open={composeOpen}
          onOpenChange={setComposeOpen}
          toEmail={composeProps.toEmail}
          toName={composeProps.toName}
          subject={composeProps.subject}
          body={composeProps.body}
          activityType={composeProps.activityType}
          inReplyToMessageId={composeProps.inReplyToMessageId}
          dealId={deals[0]?.id}
          onSent={() => loadContact()}
        />
      )}
    </div>
  );
}
