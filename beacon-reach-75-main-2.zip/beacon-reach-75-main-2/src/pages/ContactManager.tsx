import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Download, MoreHorizontal, Users, Building2, Mail, Globe, ExternalLink, Loader2, Plus, Copy, Linkedin, Trash2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface ContactRow {
  id: string;
  first_name: string | null;
  last_name: string | null;
  title: string | null;
  email: string | null;
  email_status: string | null;
  phone: string | null;
  linkedin_url: string | null;
  photo_url: string | null;
  status: string | null;
  company_id: string | null;
  vertical_id: string | null;
  company: {
    id: string;
    name: string;
    domain: string | null;
    industry: string | null;
    location: string | null;
    ai_tier: string | null;
    ai_score: number | null;
    basic_tier: string | null;
    basic_score: number | null;
    is_enriched: boolean | null;
    growth_12mo: number | null;
  } | null;
  vertical: {
    id: string;
    name: string;
  } | null;
}

const STAT_ACCENT: Record<string, string> = {
  blue: "border-l-blue-500",
  green: "border-l-emerald-500",
  orange: "border-l-amber-500",
  purple: "border-l-purple-500",
};

const TIER_STYLE: Record<string, string> = {
  T1: "bg-emerald-100 text-emerald-700 border-emerald-200",
  T2: "bg-blue-100 text-blue-700 border-blue-200",
  T3: "bg-muted text-muted-foreground border-border",
};

const EMAIL_STATUS_DOT: Record<string, string> = {
  verified: "bg-emerald-500",
  guessed: "bg-amber-500",
  unverified: "bg-amber-500",
  unavailable: "bg-red-500",
};

const STATUS_STYLE: Record<string, string> = {
  new: "bg-blue-100 text-blue-700",
  contacted: "bg-purple-100 text-purple-700",
  replied: "bg-emerald-100 text-emerald-700",
  qualified: "bg-amber-100 text-amber-700",
};

export default function ContactManager() {
  const [contacts, setContacts] = useState<ContactRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [verticalFilter, setVerticalFilter] = useState("all");
  const [tierFilter, setTierFilter] = useState("all");
  const [emailFilter, setEmailFilter] = useState("all");
  const [verticals, setVerticals] = useState<{ id: string; name: string }[]>([]);
  const [companies, setCompanies] = useState<{ id: string; name: string }[]>([]);

  // Add Contact dialog
  const [addOpen, setAddOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    first_name: "", last_name: "", email: "", title: "", phone: "",
    linkedin_url: "", company_id: "", company_text: "", vertical_id: "", notes: "",
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadContacts();
    loadVerticals();
    loadCompanies();
  }, []);

  const loadContacts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("saved_contacts")
      .select(`
        *,
        company:saved_companies(
          id, name, domain, industry, location,
          ai_tier, ai_score, basic_tier, basic_score,
          is_enriched, growth_12mo
        ),
        vertical:verticals(id, name)
      `)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Failed to load contacts:", error);
      toast.error("Failed to load contacts");
    } else {
      setContacts((data || []) as ContactRow[]);
    }
    setLoading(false);
  };

  const loadVerticals = async () => {
    const { data } = await supabase.from("verticals").select("id, name");
    setVerticals(data || []);
  };

  const loadCompanies = async () => {
    const { data } = await supabase.from("saved_companies").select("id, name").order("name");
    setCompanies(data || []);
  };

  const resetForm = () => {
    setForm({ first_name: "", last_name: "", email: "", title: "", phone: "", linkedin_url: "", company_id: "", company_text: "", vertical_id: "", notes: "" });
    setFormErrors({});
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!form.first_name.trim()) errors.first_name = "First name is required";
    if (!form.last_name.trim()) errors.last_name = "Last name is required";
    if (!form.vertical_id) errors.vertical_id = "Vertical is required";
    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      errors.email = "Invalid email format";
    }
    if (form.linkedin_url.trim() && !form.linkedin_url.trim().toLowerCase().includes("linkedin.com")) {
      errors.linkedin_url = "Must be a LinkedIn URL";
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const canSave = form.first_name.trim() && form.last_name.trim() && form.vertical_id;

  const handleSaveContact = async () => {
    if (!validateForm()) return;
    setSaving(true);

    if (form.email.trim()) {
      const { data: existing } = await supabase
        .from("saved_contacts")
        .select("id")
        .eq("email", form.email.trim())
        .limit(1);
      if (existing && existing.length > 0) {
        setFormErrors((prev) => ({ ...prev, email: "A contact with this email already exists" }));
        setSaving(false);
        return;
      }
    }

    const insertData: Record<string, unknown> = {
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      vertical_id: form.vertical_id,
      status: "new",
    };
    if (form.email.trim()) {
      insertData.email = form.email.trim();
      insertData.email_status = "unverified";
    }
    if (form.title.trim()) insertData.title = form.title.trim();
    if (form.phone.trim()) insertData.phone = form.phone.trim();
    if (form.linkedin_url.trim()) insertData.linkedin_url = form.linkedin_url.trim();
    if (form.company_id) {
      insertData.company_id = form.company_id;
    }

    const { error } = await supabase.from("saved_contacts").insert(insertData as any);
    if (error) {
      toast.error("Failed to create contact");
      console.error(error);
    } else {
      toast.success("Contact created");
      setAddOpen(false);
      resetForm();
      loadContacts();
    }
    setSaving(false);
  };

  const setField = (key: string, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (formErrors[key]) setFormErrors((prev) => { const n = { ...prev }; delete n[key]; return n; });
  };

  const filtered = useMemo(() => {
    return contacts.filter((c) => {
      if (verticalFilter !== "all" && c.vertical?.id !== verticalFilter) return false;
      const tier = c.company?.ai_tier || c.company?.basic_tier || "T3";
      if (tierFilter !== "all" && tier !== tierFilter) return false;
      if (emailFilter === "verified" && c.email_status !== "verified") return false;
      if (emailFilter === "has_email" && !c.email) return false;
      if (emailFilter === "no_email" && c.email) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          c.first_name?.toLowerCase().includes(q) ||
          c.last_name?.toLowerCase().includes(q) ||
          c.title?.toLowerCase().includes(q) ||
          c.email?.toLowerCase().includes(q) ||
          c.company?.name?.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [contacts, verticalFilter, tierFilter, emailFilter, search]);

  const stats = useMemo(() => ({
    total: contacts.length,
    verified: contacts.filter((c) => c.email_status === "verified").length,
    companies: new Set(contacts.map((c) => c.company_id).filter(Boolean)).size,
    verticals: new Set(contacts.map((c) => c.vertical_id).filter(Boolean)).size,
  }), [contacts]);

  const removeContact = async (id: string) => {
    const { error } = await supabase.from("saved_contacts").delete().eq("id", id);
    if (error) {
      toast.error("Failed to remove contact");
    } else {
      setContacts((prev) => prev.filter((c) => c.id !== id));
      toast.success("Contact removed");
    }
  };

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Contact Manager</h1>
            <p className="text-sm text-muted-foreground">{contacts.length} contacts across all campaigns</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" /> Export XLSX
            </Button>
            <Button className="gap-2" onClick={() => { resetForm(); setAddOpen(true); }}>
              <Plus className="h-4 w-4" /> Add Contact
            </Button>
          </div>
        </motion.div>

        {/* Stats — Dashboard-style cards */}
        <div className="bg-card border border-border rounded-xl p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "Total Contacts", value: stats.total, icon: Users, accent: "blue" },
              { label: "Verified Emails", value: stats.verified, icon: Mail, accent: "green" },
              { label: "Companies", value: stats.companies, icon: Building2, accent: "orange" },
              { label: "Verticals", value: stats.verticals, icon: Globe, accent: "purple" },
            ].map((s) => (
              <div key={s.label} className={`border-l-[3px] ${STAT_ACCENT[s.accent]} pl-3 py-1`}>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">{s.label}</span>
                  <s.icon className="h-3.5 w-3.5 text-muted-foreground/50" />
                </div>
                <p className="text-xl font-bold text-foreground mt-0.5">{s.value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Filters — compact horizontal bar */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input placeholder="Search contacts..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-8 text-sm" />
          </div>
          <Select value={verticalFilter} onValueChange={setVerticalFilter}>
            <SelectTrigger className="w-36 h-8 text-xs rounded-full border-border">
              <SelectValue placeholder="Vertical" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Verticals</SelectItem>
              {verticals.map((v) => (
                <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={tierFilter} onValueChange={setTierFilter}>
            <SelectTrigger className="w-28 h-8 text-xs rounded-full border-border">
              <SelectValue placeholder="Tier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tiers</SelectItem>
              <SelectItem value="T1">Tier 1</SelectItem>
              <SelectItem value="T2">Tier 2</SelectItem>
              <SelectItem value="T3">Tier 3</SelectItem>
            </SelectContent>
          </Select>
          <Select value={emailFilter} onValueChange={setEmailFilter}>
            <SelectTrigger className="w-32 h-8 text-xs rounded-full border-border">
              <SelectValue placeholder="Email" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Emails</SelectItem>
              <SelectItem value="verified">Verified</SelectItem>
              <SelectItem value="has_email">Has Email</SelectItem>
              <SelectItem value="no_email">No Email</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="border border-border rounded-xl overflow-hidden bg-card">
          {loading ? (
            <div className="flex items-center justify-center py-16 gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading contacts...
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-16 text-center">
              <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                {contacts.length === 0 ? "No contacts yet. Use Campaign Builder to find decision makers." : "No contacts match your filters."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="text-xs font-medium">Contact</TableHead>
                    <TableHead className="text-xs font-medium">Company</TableHead>
                    <TableHead className="text-xs font-medium">Vertical</TableHead>
                    <TableHead className="text-xs font-medium">Growth</TableHead>
                    <TableHead className="text-xs font-medium">Tier</TableHead>
                    <TableHead className="text-xs font-medium">Email</TableHead>
                    <TableHead className="text-xs font-medium">Status</TableHead>
                    <TableHead className="text-xs font-medium w-10">LI</TableHead>
                    <TableHead className="text-xs w-8"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((c, idx) => {
                    const tier = c.company?.ai_tier || c.company?.basic_tier || "T3";
                    const score = c.company?.ai_score ?? c.company?.basic_score ?? 0;
                    const growth = Number(c.company?.growth_12mo) || 0;
                    const initials = (c.first_name?.[0] || "") + (c.last_name?.[0] || "");

                    return (
                      <TableRow key={c.id} className={`text-sm hover:bg-muted/40 transition-colors ${idx % 2 === 1 ? "bg-muted/15" : ""}`}>
                        <TableCell className="py-3">
                          <div className="flex items-center gap-2.5">
                            <Avatar className="h-8 w-8 flex-shrink-0">
                              {c.photo_url ? <AvatarImage src={c.photo_url} /> : null}
                              <AvatarFallback className="text-[10px] font-semibold bg-primary/10 text-primary">
                                {initials}
                              </AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="font-semibold text-sm text-foreground truncate">
                                <Link to={`/contacts/${c.id}`} className="hover:text-primary hover:underline transition-colors">
                                  {c.first_name} {c.last_name}
                                </Link>
                              </p>
                              <p className="text-xs text-muted-foreground truncate">{c.title || "—"}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="text-sm text-foreground">{c.company?.name || "—"}</p>
                            <p className="text-xs text-muted-foreground">{c.company?.domain || ""}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          {c.vertical ? (
                            <Badge variant="secondary" className="text-[10px]">{c.vertical.name}</Badge>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <span className="text-xs font-mono font-medium">
                            {growth > 0 ? "+" : ""}{growth}%
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge className={`text-[10px] border ${TIER_STYLE[tier] || TIER_STYLE.T3}`}>
                            {tier} · {score}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <div className={`h-1.5 w-1.5 rounded-full flex-shrink-0 ${EMAIL_STATUS_DOT[c.email_status || ""] || "bg-muted-foreground/30"}`} />
                            <span className="text-xs text-muted-foreground">{c.email_status || "none"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Badge variant="outline" className={`text-[10px] border-0 ${STATUS_STYLE[c.status || "new"] || STATUS_STYLE.new}`}>{c.status || "new"}</Badge>
                            {(c as any).opted_out && (
                              <Badge variant="destructive" className="text-[10px]">Opted out</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {c.linkedin_url ? (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <a
                                  href={c.linkedin_url.startsWith("http") ? c.linkedin_url : `https://${c.linkedin_url}`}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="h-7 w-7 rounded-md flex items-center justify-center hover:bg-muted transition-colors"
                                >
                                  <Linkedin className="h-3.5 w-3.5 text-blue-600" />
                                </a>
                              </TooltipTrigger>
                              <TooltipContent>Open LinkedIn</TooltipContent>
                            </Tooltip>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {c.email && (
                                <DropdownMenuItem onClick={() => { navigator.clipboard.writeText(c.email!); toast.success("Email copied"); }}>
                                  <Copy className="h-3.5 w-3.5 mr-2" /> Copy email
                                </DropdownMenuItem>
                              )}
                              {c.linkedin_url && (
                                <DropdownMenuItem onClick={() => window.open(c.linkedin_url!.startsWith("http") ? c.linkedin_url! : `https://${c.linkedin_url}`, "_blank")}>
                                  <Linkedin className="h-3.5 w-3.5 mr-2" /> Open LinkedIn
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem className="text-destructive" onClick={() => removeContact(c.id)}>
                                <Trash2 className="h-3.5 w-3.5 mr-2" /> Remove
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>

        {/* Add Contact Dialog */}
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Contact</DialogTitle>
              <DialogDescription>Create a new contact manually.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">First Name *</Label>
                  <Input value={form.first_name} onChange={(e) => setField("first_name", e.target.value)} placeholder="John" />
                  {formErrors.first_name && <p className="text-xs text-destructive">{formErrors.first_name}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">Last Name *</Label>
                  <Input value={form.last_name} onChange={(e) => setField("last_name", e.target.value)} placeholder="Doe" />
                  {formErrors.last_name && <p className="text-xs text-destructive">{formErrors.last_name}</p>}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Email</Label>
                <Input type="email" value={form.email} onChange={(e) => setField("email", e.target.value)} placeholder="john@example.com" />
                {formErrors.email && <p className="text-xs text-destructive">{formErrors.email}</p>}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Title / Job Title</Label>
                <Input value={form.title} onChange={(e) => setField("title", e.target.value)} placeholder="VP of Engineering" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Phone</Label>
                  <Input value={form.phone} onChange={(e) => setField("phone", e.target.value)} placeholder="+1 555-0123" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">LinkedIn URL</Label>
                  <Input value={form.linkedin_url} onChange={(e) => setField("linkedin_url", e.target.value)} placeholder="linkedin.com/in/..." />
                  {formErrors.linkedin_url && <p className="text-xs text-destructive">{formErrors.linkedin_url}</p>}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Company</Label>
                <Select value={form.company_id} onValueChange={(v) => setField("company_id", v)}>
                  <SelectTrigger className="text-sm">
                    <SelectValue placeholder="Select a company (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {companies.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Vertical *</Label>
                <Select value={form.vertical_id} onValueChange={(v) => setField("vertical_id", v)}>
                  <SelectTrigger className="text-sm">
                    <SelectValue placeholder="Select vertical" />
                  </SelectTrigger>
                  <SelectContent>
                    {verticals.map((v) => (
                      <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formErrors.vertical_id && <p className="text-xs text-destructive">{formErrors.vertical_id}</p>}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Notes</Label>
                <Textarea value={form.notes} onChange={(e) => setField("notes", e.target.value)} placeholder="Optional notes..." rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button onClick={handleSaveContact} disabled={!canSave || saving}>
                {saving ? <><Loader2 className="h-4 w-4 animate-spin mr-1" /> Saving...</> : "Save Contact"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
