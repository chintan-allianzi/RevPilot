import { toast } from "sonner";
import { motion } from "framer-motion";
import { ArrowRight, Mail, Eye, MessageSquare, Users, Building2, Linkedin, TrendingUp, AlertTriangle, Calendar, XCircle, Rocket, Trash2, Send, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import PipelineDashboard from "@/components/PipelineDashboard";

const statusColor: Record<string, string> = {
  active: "bg-success text-success-foreground",
  paused: "bg-warning text-warning-foreground",
  completed: "bg-muted text-muted-foreground",
  draft: "bg-secondary text-secondary-foreground",
};

const statusDot: Record<string, string> = {
  active: "bg-success",
  paused: "bg-warning",
  completed: "bg-muted-foreground",
  draft: "bg-border",
};

const sentimentColor: Record<string, string> = {
  positive: "bg-success/10 text-success border-success/20",
  negative: "bg-destructive/10 text-destructive border-destructive/20",
  neutral: "bg-muted text-muted-foreground border-border",
  interested: "bg-primary/10 text-primary border-primary/20",
};

interface DashboardStats {
  emailsSent: number;
  emailsScheduled: number;
  emailsOpened: number;
  emailsReplied: number;
  emailsFailed: number;
  emailsBounced: number;
  linkedInPending: number;
  linkedInCompleted: number;
  totalContacts: number;
  totalCompanies: number;
  activeCampaigns: number;
}

interface CampaignRow {
  id: string;
  name: string;
  status: string;
  vertical_name: string;
  contacts_count: number;
  linkedin_tasks_count: number;
  created_at: string;
  emails_sent: number;
  emails_scheduled: number;
  emails_replied: number;
  emails_total: number;
}

type AccentColor = "green" | "blue" | "orange" | "purple";

const accentBorder: Record<AccentColor, string> = {
  green: "border-l-4 border-l-success",
  blue: "border-l-4 border-l-primary",
  orange: "border-l-4 border-l-warning",
  purple: "border-l-4 border-l-[hsl(280,60%,50%)]",
};

const accentIconBg: Record<AccentColor, string> = {
  green: "bg-success/10 text-success",
  blue: "bg-primary/10 text-primary",
  orange: "bg-warning/10 text-warning",
  purple: "bg-[hsl(280,60%,50%)]/10 text-[hsl(280,60%,50%)]",
};

const MetricCard = ({
  icon: Icon,
  label,
  value,
  sub,
  accent = "blue",
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  accent?: AccentColor;
}) => (
  <Card className={`${accentBorder[accent]} hover:shadow-md transition-shadow duration-200`}>
    <CardContent className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest">{label}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${accentIconBg[accent]}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [campaigns, setCampaigns] = useState<CampaignRow[]>([]);
  const [recentReplies, setRecentReplies] = useState<any[]>([]);
  const [upcomingMeetings, setUpcomingMeetings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingQueue, setProcessingQueue] = useState(false);
  const [emailsDueNow, setEmailsDueNow] = useState(0);
  const [nextDueDate, setNextDueDate] = useState("");
  const [activeTab, setActiveTab] = useState("outbound");

  const handleDeleteCampaign = async (campaignId: string) => {
    await supabase.from("email_queue").delete().eq("campaign_id", campaignId);
    await supabase.from("linkedin_tasks").delete().eq("vertical_id", campaignId);
    await supabase.from("campaigns").delete().eq("id", campaignId).eq("status", "draft");
    toast.success("Draft campaign deleted");
    loadDashboardData();
  };

  const handleProcessQueue = async () => {
    setProcessingQueue(true);
    try {
      const result = await supabase.functions.invoke("apollo-proxy", {
        body: { action: "process-email-queue" },
      });
      if (result.data?.success) {
        toast.success(result.data.message || "Follow-ups processed");
        await loadDashboardData();
      } else {
        toast.error("Failed to process queue: " + (result.data?.error || "Unknown error"));
      }
    } catch (e: any) {
      toast.error("Error: " + e.message);
    }
    setProcessingQueue(false);
  };

  const checkDueEmails = async () => {
    const now = new Date().toISOString();
    const { count } = await supabase
      .from("email_queue")
      .select("id", { count: "exact", head: true })
      .eq("status", "scheduled")
      .lte("scheduled_at", now);
    setEmailsDueNow(count || 0);

    const { data: nextEmail } = await supabase
      .from("email_queue")
      .select("scheduled_at")
      .eq("status", "scheduled")
      .gt("scheduled_at", now)
      .order("scheduled_at", { ascending: true })
      .limit(1)
      .maybeSingle();

    if (nextEmail) {
      setNextDueDate(new Date(nextEmail.scheduled_at).toLocaleDateString());
    } else {
      setNextDueDate("");
    }
  };

  useEffect(() => {
    loadDashboardData();

    const timeout = setTimeout(async () => {
      const now = new Date().toISOString();
      const { count } = await supabase
        .from("email_queue")
        .select("id", { count: "exact", head: true })
        .eq("status", "scheduled")
        .lte("scheduled_at", now);

      if (count && count > 0) {
        console.log(`Auto-processing ${count} due emails...`);
        try {
          await supabase.functions.invoke("apollo-proxy", { body: { action: "process-email-queue" } });
          await loadDashboardData();
        } catch (e) {
          console.error("Auto-process failed:", e);
        }
      }
    }, 3000);

    const interval = setInterval(() => loadDashboardData(), 30000);
    return () => {
      clearTimeout(timeout);
      clearInterval(interval);
    };
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);

    const [
      { data: emailStats },
      { data: linkedInStats },
      { count: totalContacts },
      { count: totalCompanies },
      { data: campaignData },
      { data: repliesData },
    ] = await Promise.all([
      supabase.from("email_queue").select("status, opened_at, replied_at, bounced_at"),
      supabase.from("linkedin_tasks").select("status"),
      supabase.from("saved_contacts").select("id", { count: "exact", head: true }),
      supabase.from("saved_companies").select("id", { count: "exact", head: true }),
      supabase.from("campaigns")
        .select("id, name, status, contacts_count, linkedin_tasks_count, created_at, vertical:verticals(name)")
        .order("created_at", { ascending: false }),
      supabase.from("email_replies")
        .select("id, from_name, from_email, subject, sentiment, is_read, received_at, campaign_id")
        .order("received_at", { ascending: false })
        .limit(10),
    ]);

    setRecentReplies(repliesData || []);

    const { data: meetingsData } = await supabase
      .from("appointments")
      .select("id, title, meeting_type, scheduled_at, meeting_link, deal_id, status")
      .eq("status", "scheduled")
      .gte("scheduled_at", new Date().toISOString())
      .order("scheduled_at")
      .limit(5);
    setUpcomingMeetings(meetingsData || []);

    const sent = emailStats?.filter(e => e.status === "sent").length || 0;
    const scheduled = emailStats?.filter(e => e.status === "scheduled").length || 0;
    const opened = emailStats?.filter(e => e.opened_at).length || 0;
    const replied = emailStats?.filter(e => e.replied_at || e.status === "replied").length || 0;
    const failed = emailStats?.filter(e => e.status === "failed").length || 0;
    const bounced = emailStats?.filter(e => e.bounced_at).length || 0;
    const linkedInPending = linkedInStats?.filter(t => t.status === "pending").length || 0;
    const linkedInCompleted = linkedInStats?.filter(t => t.status === "completed").length || 0;

    const campaignRows: CampaignRow[] = [];
    if (campaignData) {
      const campaignIds = campaignData.map(c => c.id);
      const { data: allEmails } = campaignIds.length > 0
        ? await supabase.from("email_queue").select("campaign_id, status, replied_at").in("campaign_id", campaignIds)
        : { data: [] };

      for (const camp of campaignData) {
        const campEmails = allEmails?.filter(e => e.campaign_id === camp.id) || [];
        const verticalName = Array.isArray(camp.vertical)
          ? (camp.vertical as any)[0]?.name || ""
          : (camp.vertical as any)?.name || "";

        campaignRows.push({
          id: camp.id,
          name: camp.name,
          status: camp.status || "draft",
          vertical_name: verticalName,
          contacts_count: camp.contacts_count || 0,
          linkedin_tasks_count: camp.linkedin_tasks_count || 0,
          created_at: camp.created_at || "",
          emails_sent: campEmails.filter(e => e.status === "sent").length,
          emails_scheduled: campEmails.filter(e => e.status === "scheduled").length,
          emails_replied: campEmails.filter(e => e.replied_at || e.status === "replied").length,
          emails_total: campEmails.length,
        });
      }
    }

    const activeCampaigns = campaignRows.filter(c => c.status === "active").length;

    setStats({
      emailsSent: sent,
      emailsScheduled: scheduled,
      emailsOpened: opened,
      emailsReplied: replied,
      emailsFailed: failed,
      emailsBounced: bounced,
      linkedInPending,
      linkedInCompleted,
      totalContacts: totalContacts || 0,
      totalCompanies: totalCompanies || 0,
      activeCampaigns,
    });
    setCampaigns(campaignRows);
    setLoading(false);

    await checkDueEmails();
  };

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!loading && campaigns.length === 0 && stats?.totalContacts === 0) {
    return (
      <div className="space-y-6 max-w-7xl">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Outbound pipeline overview</p>
          </div>
        </motion.div>
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
            <Rocket className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-xl font-semibold">Welcome to Office Beacon Outbound</h2>
          <p className="text-muted-foreground mt-2 max-w-md">
            Create your first outbound campaign to start finding companies, enriching contacts, and sending personalized outreach.
          </p>
          <Button onClick={() => navigate("/campaigns/new")} className="mt-6 gradient-primary text-primary-foreground gap-2">
            Create Your First Campaign
          </Button>
        </div>
      </div>
    );
  }

  const getInitials = (name: string) => {
    const parts = name.trim().split(/\s+/);
    return parts.length >= 2 ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase() : name.slice(0, 2).toUpperCase();
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Performance overview</p>
        </div>
        <Button onClick={() => navigate("/campaigns/new")} className="gradient-primary text-primary-foreground gap-2">
          <ArrowRight className="h-4 w-4" /> New Campaign
        </Button>
      </motion.div>

      {/* Segmented control tab switcher */}
      <div className="inline-flex items-center rounded-full bg-muted p-1 gap-0.5">
        {[
          { key: "outbound", label: "Outbound" },
          { key: "pipeline", label: "Pipeline" },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`relative px-5 py-1.5 text-sm font-medium rounded-full transition-all duration-200 ${
              activeTab === tab.key
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "pipeline" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }}>
          <PipelineDashboard />
        </motion.div>
      )}

      {activeTab === "outbound" && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="space-y-6">

          {/* Follow-up queue banner */}
          {stats && stats.emailsScheduled > 0 && (
            <Card className="border-warning/30 bg-warning/5 border-l-4 border-l-warning">
              <CardContent className="p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg flex items-center justify-center bg-warning/15 flex-shrink-0">
                    <Send className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">
                      {stats.emailsScheduled} follow-up emails scheduled
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {emailsDueNow > 0
                        ? `${emailsDueNow} are due now and ready to send`
                        : nextDueDate
                          ? `Next batch due ${nextDueDate}`
                          : "All scheduled for later"}
                    </p>
                  </div>
                </div>
                {emailsDueNow > 0 && (
                  <Button
                    size="sm"
                    onClick={handleProcessQueue}
                    disabled={processingQueue}
                    className="gap-1.5 flex-shrink-0"
                  >
                    {processingQueue ? (
                      <><Loader2 className="h-3 w-3 animate-spin" /> Sending...</>
                    ) : (
                      <><Send className="h-3 w-3" /> Send Due ({emailsDueNow})</>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          )}

          {/* Outbound metrics */}
          {stats && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <MetricCard icon={Mail} label="Emails Sent" value={stats.emailsSent} sub={`${stats.emailsScheduled} scheduled`} accent="blue" />
              <MetricCard icon={Eye} label="Opened" value={stats.emailsSent > 0 ? `${stats.emailsOpened} (${Math.round((stats.emailsOpened / stats.emailsSent) * 100)}%)` : "0"} accent="green" />
              <MetricCard icon={MessageSquare} label="Replied" value={stats.emailsSent > 0 ? `${stats.emailsReplied} (${Math.round((stats.emailsReplied / stats.emailsSent) * 100)}%)` : "0"} accent="green" />
              <MetricCard icon={Linkedin} label="LinkedIn Queue" value={stats.linkedInPending} sub={`${stats.linkedInCompleted} completed`} accent="blue" />
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Campaign list */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-semibold">Campaigns</CardTitle>
                  <button onClick={() => navigate("/campaigns/new")} className="text-xs text-primary hover:underline font-medium">
                    + New Campaign
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-1">
                {campaigns.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-sm text-muted-foreground">No campaigns yet</p>
                    <Button onClick={() => navigate("/campaigns/new")} variant="outline" className="mt-3" size="sm">
                      Create Your First Campaign
                    </Button>
                  </div>
                ) : (
                  campaigns.map((campaign) => {
                    const pct = campaign.emails_total > 0 ? (campaign.emails_sent / campaign.emails_total) * 100 : 0;
                    return (
                      <button
                        key={campaign.id}
                        onClick={() => navigate(`/campaigns/${campaign.id}`)}
                        className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-muted/50 hover:shadow-sm transition-all text-left group"
                      >
                        <div className="flex items-center gap-2.5 shrink-0">
                          <span className={`w-2 h-2 rounded-full ${statusDot[campaign.status] || statusDot.draft}`} />
                          <Badge className={`${statusColor[campaign.status] || statusColor.draft} text-[10px] uppercase tracking-wider`}>
                            {campaign.status}
                          </Badge>
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{campaign.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {campaign.contacts_count} contacts · {campaign.vertical_name}
                          </p>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground shrink-0">
                          <span>{campaign.emails_replied} {campaign.emails_replied === 1 ? "reply" : "replies"}</span>
                          <div className="flex items-center gap-2">
                            <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-primary/70 to-primary transition-all"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                            <span className="text-[10px] font-medium">{campaign.emails_sent}/{campaign.emails_total}</span>
                          </div>
                          {campaign.status === "draft" && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                if (confirm(`Delete draft campaign "${campaign.name}"?`)) {
                                  handleDeleteCampaign(campaign.id);
                                }
                              }}
                              className="text-muted-foreground hover:text-destructive p-1"
                              title="Delete draft"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </button>
                    );
                  })
                )}
              </CardContent>
            </Card>

            {/* Pipeline Summary */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-semibold">Pipeline Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { label: "Total Contacts", value: stats?.totalContacts || 0, icon: Users, color: "text-primary" },
                  { label: "Companies", value: stats?.totalCompanies || 0, icon: Building2, color: "text-primary" },
                  { label: "Reply Rate", value: stats && stats.emailsSent > 0 ? `${Math.round((stats.emailsReplied / stats.emailsSent) * 100)}%` : "—", icon: TrendingUp, color: "text-success" },
                  { label: "Bounce Rate", value: stats && stats.emailsSent > 0 ? `${Math.round((stats.emailsBounced / stats.emailsSent) * 100)}%` : "—", icon: AlertTriangle, color: "text-warning" },
                  { label: "Active Campaigns", value: stats?.activeCampaigns || 0, icon: Rocket, color: "text-primary" },
                  { label: "Scheduled", value: stats?.emailsScheduled || 0, icon: Calendar, color: "text-muted-foreground" },
                  { label: "Failed", value: stats?.emailsFailed || 0, icon: XCircle, color: "text-destructive" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between py-1">
                    <div className="flex items-center gap-2.5 text-sm text-muted-foreground">
                      <item.icon className={`h-4 w-4 ${item.color}`} />
                      {item.label}
                    </div>
                    <span className="text-sm font-semibold">{item.value}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Meetings */}
          {upcomingMeetings.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-semibold">Upcoming Meetings</CardTitle>
                  <button onClick={() => navigate("/pipeline")} className="text-xs text-primary hover:underline font-medium">
                    View pipeline →
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-1">
                {upcomingMeetings.map((mtg) => {
                  const relTime = (() => {
                    const diff = new Date(mtg.scheduled_at).getTime() - Date.now();
                    const hrs = Math.floor(diff / 3600000);
                    if (hrs < 1) return "Soon";
                    if (hrs < 24) return `In ${hrs}h`;
                    return `In ${Math.floor(hrs / 24)}d`;
                  })();
                  return (
                    <div key={mtg.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/40 transition-colors">
                      <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Calendar className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{mtg.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(mtg.scheduled_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                          {mtg.meeting_type && ` · ${mtg.meeting_type.replace(/_/g, " ")}`}
                        </p>
                      </div>
                      <span className="text-[10px] font-medium text-muted-foreground flex-shrink-0">{relTime}</span>
                      {mtg.meeting_link && (
                        <a href={mtg.meeting_link} target="_blank" rel="noopener" className="text-xs text-primary hover:underline flex-shrink-0">
                          Join
                        </a>
                      )}
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          {/* Recent Replies */}
          {recentReplies.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-semibold">Recent Replies</CardTitle>
                  <button onClick={() => navigate("/inbox")} className="text-xs text-primary hover:underline font-medium">
                    View all →
                  </button>
                </div>
              </CardHeader>
              <CardContent className="space-y-1">
                {recentReplies.slice(0, 5).map((reply) => {
                  const displayName = reply.from_name || reply.from_email;
                  return (
                    <button
                      key={reply.id}
                      onClick={() => navigate("/inbox")}
                      className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/40 transition-colors text-left"
                    >
                      {/* Avatar initials */}
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <span className="text-[10px] font-semibold text-primary">
                          {getInitials(displayName)}
                        </span>
                      </div>
                      {!reply.is_read && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{displayName}</p>
                        <p className="text-xs text-muted-foreground truncate">{reply.subject}</p>
                      </div>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0">
                        {new Date(reply.received_at).toLocaleDateString()}
                      </span>
                      {reply.sentiment && (
                        <Badge
                          variant="outline"
                          className={`text-[10px] flex-shrink-0 ${sentimentColor[reply.sentiment] || ""}`}
                        >
                          {reply.sentiment}
                        </Badge>
                      )}
                    </button>
                  );
                })}
              </CardContent>
            </Card>
          )}
        </motion.div>
      )}
    </div>
  );
}
