import { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { triggerNurtureSequences, cancelSkippedNurtureEntries } from "@/lib/nurture-utils";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Mail,
  Phone,
  Linkedin,
  Calendar,
  Clock,
  User,
  Plus,
  CheckCircle2,
  Trophy,
  XCircle,
  FileText,
  MessageSquare,
  Activity,
  Send,
  ExternalLink,
  Trash2,
  MoreHorizontal,
  ChevronRight,
  Building2,
  DollarSign,
  CalendarDays,
  Timer,
  Check,
  AlertTriangle,
} from "lucide-react";
import ComposeEmailDialog from "@/components/ComposeEmailDialog";

interface LeadStage {
  id: string;
  stage_key: string;
  stage_name: string;
  stage_order: number;
  stage_type: string;
}

export default function DealDetail() {
  const { dealId } = useParams<{ dealId: string }>();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();

  const [deal, setDeal] = useState<any>(null);
  const [contact, setContact] = useState<any>(null);
  const [company, setCompany] = useState<any>(null);
  const [stages, setStages] = useState<LeadStage[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Activities
  const [activities, setActivities] = useState<any[]>([]);
  // Tasks
  const [tasks, setTasks] = useState<any[]>([]);
  const [taskFilter, setTaskFilter] = useState<"all" | "pending" | "completed" | "overdue">("all");
  // Emails
  const [emailsSent, setEmailsSent] = useState<any[]>([]);
  const [emailsReceived, setEmailsReceived] = useState<any[]>([]);
  // Stage history
  const [stageHistory, setStageHistory] = useState<any[]>([]);
  // Appointments
  const [appointments, setAppointments] = useState<any[]>([]);

  // Dialogs
  const [logActivityOpen, setLogActivityOpen] = useState(false);
  const [activityType, setActivityType] = useState("note");
  const [activitySubject, setActivitySubject] = useState("");
  const [activityDesc, setActivityDesc] = useState("");

  const [addTaskOpen, setAddTaskOpen] = useState(false);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDesc, setTaskDesc] = useState("");
  const [taskDue, setTaskDue] = useState("");
  const [taskPriority, setTaskPriority] = useState("medium");
  const [taskAssignee, setTaskAssignee] = useState("");

  const [lostReasonDialog, setLostReasonDialog] = useState(false);
  const [lostReason, setLostReason] = useState("");

  const [deleteConfirm, setDeleteConfirm] = useState(false);

  // Schedule meeting dialog
  const [scheduleMeetingOpen, setScheduleMeetingOpen] = useState(false);
  const [meetingType, setMeetingType] = useState("discovery_call");
  const [meetingDate, setMeetingDate] = useState("");
  const [meetingDuration, setMeetingDuration] = useState("30");
  const [meetingLink, setMeetingLink] = useState("");
  const [meetingDesc, setMeetingDesc] = useState("");
  const [meetingCreating, setMeetingCreating] = useState(false);

  // Post-meeting dialog
  const [completeMeetingOpen, setCompleteMeetingOpen] = useState(false);
  const [completeMeetingId, setCompleteMeetingId] = useState("");
  const [outcomeNotes, setOutcomeNotes] = useState("");
  const [qualifyChoice, setQualifyChoice] = useState<"sql" | "nurture" | "lost">("nurture");

  // Inline editing
  const [editingName, setEditingName] = useState(false);
  const [editName, setEditName] = useState("");
  const [editingValue, setEditingValue] = useState(false);
  const [editValue, setEditValue] = useState("");

  // Compose email dialog state
  const [composeOpen, setComposeOpen] = useState(false);
  const [composeProps, setComposeProps] = useState<{
    toEmail?: string;
    toName?: string;
    subject?: string;
    body?: string;
    activityType?: string;
    inReplyToMessageId?: string;
  }>({});

  // Gmail account warning
  const [gmailWarning, setGmailWarning] = useState<string | null>(null);

  useEffect(() => {
    if (dealId) loadDeal();
  }, [dealId]);

  const loadDeal = async () => {
    if (!dealId) return;
    setLoading(true);

    const [dealRes, stagesRes, profilesRes] = await Promise.all([
      supabase.from("deals").select("*").eq("id", dealId).single(),
      supabase.from("lead_stages").select("*").order("stage_order"),
      supabase.from("profiles").select("id, full_name, calendar_link, title, email_signature").eq("is_active", true),
    ]);

    if (!dealRes.data) {
      toast.error("Deal not found");
      navigate("/pipeline");
      return;
    }

    const d = dealRes.data;
    setDeal(d);
    setStages((stagesRes.data as LeadStage[]) || []);
    setProfiles(profilesRes.data || []);

    // Check Gmail connection for assigned BDM
    checkGmailConnection(d.assigned_to || user?.id);

    const promises: Promise<any>[] = [
      loadActivities(dealId),
      loadTasks(dealId),
      loadStageHistory(dealId),
      loadAppointments(dealId),
    ];

    if (d.contact_id) {
      promises.push(
        supabase.from("saved_contacts").select("*").eq("id", d.contact_id).single().then(r => { setContact(r.data); }) as unknown as Promise<any>
      );
      promises.push(loadEmails(d.contact_id, d.campaign_id));
    }
    if (d.company_id) {
      promises.push(
        supabase.from("saved_companies").select("*").eq("id", d.company_id).single().then(r => { setCompany(r.data); }) as unknown as Promise<any>
      );
    }

    await Promise.all(promises);
    setLoading(false);
  };

  const checkGmailConnection = async (userId: string | null) => {
    if (!userId) return;
    const { data } = await supabase
      .from("email_accounts")
      .select("id")
      .eq("user_id", userId)
      .eq("is_active", true)
      .limit(1)
      .maybeSingle();
    if (!data) {
      const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", userId).maybeSingle();
      const name = profile?.full_name || "the assigned BDM";
      setGmailWarning(`No Gmail account connected for ${name}. Connect one in Settings to send emails.`);
    } else {
      setGmailWarning(null);
    }
  };

  const loadActivities = async (id: string) => {
    const { data } = await supabase
      .from("deal_activities")
      .select("*")
      .eq("deal_id", id)
      .order("activity_date", { ascending: false });
    setActivities(data || []);
  };

  const loadTasks = async (id: string) => {
    const { data } = await supabase
      .from("deal_tasks")
      .select("*")
      .eq("deal_id", id)
      .order("due_date");
    setTasks(data || []);
  };

  const loadStageHistory = async (id: string) => {
    const { data } = await supabase
      .from("deal_stage_history")
      .select("*")
      .eq("deal_id", id)
      .order("changed_at", { ascending: false });
    setStageHistory(data || []);
  };

  const loadAppointments = async (id: string) => {
    const { data } = await supabase
      .from("appointments")
      .select("*")
      .eq("deal_id", id)
      .order("scheduled_at", { ascending: false });
    setAppointments(data || []);
  };

  const loadEmails = async (contactId: string, campaignId: string | null) => {
    const [sentRes, receivedRes] = await Promise.all([
      supabase.from("email_queue").select("*").eq("contact_id", contactId).order("scheduled_at", { ascending: false }),
      supabase.from("email_replies").select("*").eq("contact_id", contactId).order("received_at", { ascending: false }),
    ]);
    setEmailsSent(sentRes.data || []);
    setEmailsReceived(receivedRes.data || []);
  };

  const currentStage = stages.find((s) => s.id === deal?.stage_id);
  const assignedProfile = profiles.find((p) => p.id === deal?.assigned_to);

  // Stage change
  const changeStage = async (newStageId: string) => {
    if (!deal || deal.stage_id === newStageId) return;
    const newStage = stages.find((s) => s.id === newStageId);
    if (!newStage) return;

    if (newStage.stage_key === "closed_lost") {
      setLostReasonDialog(true);
      return;
    }

    await performStageChange(newStageId, newStage);
  };

  const performStageChange = async (newStageId: string, newStage: LeadStage, extra: { lost_reason?: string } = {}) => {
    const lastHist = stageHistory[0];
    const timeInPrev = lastHist
      ? Math.round((Date.now() - new Date(lastHist.changed_at).getTime()) / 3600000 * 10) / 10
      : null;

    const updates: any = { stage_id: newStageId, ...extra };
    if (newStage.stage_key === "closed_won") updates.won_date = new Date().toISOString().split("T")[0];

    await supabase.from("deals").update(updates).eq("id", deal.id);
    await supabase.from("deal_stage_history").insert({
      deal_id: deal.id,
      from_stage_id: deal.stage_id,
      to_stage_id: newStageId,
      changed_by: user?.id,
      time_in_previous_stage_hours: timeInPrev,
    });
    await supabase.from("deal_activities").insert({
      deal_id: deal.id,
      activity_type: "stage_change",
      subject: `Moved to ${newStage.stage_name}`,
      created_by: user?.id,
    });

    // Nurture sequences
    const isClosedLost = newStage.stage_key === "closed_lost";
    await triggerNurtureSequences(deal.id, newStageId, {
      contact_id: deal.contact_id,
      assigned_to: deal.assigned_to,
      vertical_id: deal.vertical_id,
    }, isClosedLost);

    if (!isClosedLost) {
      const fromStage = stages.find((s) => s.id === deal.stage_id);
      const toStageObj = stages.find((s) => s.id === newStageId);
      if (fromStage && toStageObj && toStageObj.stage_order > fromStage.stage_order + 1) {
        await cancelSkippedNurtureEntries(deal.id, fromStage.stage_order, toStageObj.stage_order, stages);
      }
    }

    toast.success(`Deal moved to ${newStage.stage_name}`);
    if (newStage.stage_key === "closed_won") {
      toast("🎉 Deal Won! Congratulations!", { duration: 5000 });
    }
    loadDeal();
  };

  const handleConfirmLost = async () => {
    if (!lostReason.trim()) { toast.error("Enter a reason"); return; }
    const stage = stages.find((s) => s.stage_key === "closed_lost")!;
    await performStageChange(stage.id, stage, { lost_reason: lostReason });
    setLostReasonDialog(false);
    setLostReason("");
  };

  // Inline edits
  const saveName = async () => {
    if (!editName.trim()) return;
    await supabase.from("deals").update({ deal_name: editName }).eq("id", deal.id);
    setDeal((prev: any) => ({ ...prev, deal_name: editName }));
    setEditingName(false);
  };

  const saveValue = async () => {
    const val = editValue ? parseFloat(editValue) : null;
    await supabase.from("deals").update({ deal_value: val }).eq("id", deal.id);
    setDeal((prev: any) => ({ ...prev, deal_value: val }));
    setEditingValue(false);
  };

  const updateAssignee = async (profileId: string) => {
    await supabase.from("deals").update({ assigned_to: profileId }).eq("id", deal.id);
    setDeal((prev: any) => ({ ...prev, assigned_to: profileId }));
    toast.success("Assignee updated");
  };

  const updateCloseDate = async (date: string) => {
    await supabase.from("deals").update({ expected_close_date: date || null }).eq("id", deal.id);
    setDeal((prev: any) => ({ ...prev, expected_close_date: date || null }));
  };

  // Log activity — redirect email_sent to compose dialog
  const handleLogActivity = async () => {
    if (activityType === "email_sent") {
      // Open compose dialog instead
      setLogActivityOpen(false);
      openCompose({
        subject: activitySubject,
        body: activityDesc,
      });
      setActivitySubject("");
      setActivityDesc("");
      setActivityType("note");
      return;
    }
    if (!activitySubject.trim()) { toast.error("Enter a subject"); return; }
    await supabase.from("deal_activities").insert({
      deal_id: deal.id,
      activity_type: activityType,
      subject: activitySubject,
      description: activityDesc || null,
      created_by: user?.id,
    });
    setLogActivityOpen(false);
    setActivitySubject("");
    setActivityDesc("");
    setActivityType("note");
    toast.success("Activity logged");
    loadActivities(deal.id);
  };

  // Add task
  const handleAddTask = async () => {
    if (!taskTitle.trim() || !taskDue) { toast.error("Fill required fields"); return; }
    await supabase.from("deal_tasks").insert({
      deal_id: deal.id,
      title: taskTitle,
      description: taskDesc || null,
      due_date: new Date(taskDue).toISOString(),
      priority: taskPriority,
      assigned_to: taskAssignee || user?.id,
      created_by: user?.id,
    });
    setAddTaskOpen(false);
    setTaskTitle("");
    setTaskDesc("");
    setTaskDue("");
    setTaskPriority("medium");
    toast.success("Task added");
    loadTasks(deal.id);
  };

  // Toggle task complete
  const toggleTask = async (taskId: string, currentStatus: string) => {
    const newStatus = currentStatus === "completed" ? "pending" : "completed";
    const updates: any = { status: newStatus };
    if (newStatus === "completed") updates.completed_at = new Date().toISOString();
    else updates.completed_at = null;
    await supabase.from("deal_tasks").update(updates).eq("id", taskId);
    loadTasks(deal.id);
  };

  // Delete deal
  const handleDelete = async () => {
    await supabase.from("deals").delete().eq("id", deal.id);
    toast.success("Deal deleted");
    navigate("/pipeline");
  };

  // Quick actions
  const handleMarkWon = () => {
    const stage = stages.find((s) => s.stage_key === "closed_won");
    if (stage) performStageChange(stage.id, stage);
  };
  const handleMarkLost = () => setLostReasonDialog(true);
  const handleScheduleMeeting = () => {
    setMeetingType("discovery_call");
    setMeetingDate("");
    setMeetingDuration("30");
    setMeetingLink("");
    setMeetingDesc("");
    setScheduleMeetingOpen(true);
  };

  // Open compose with deal context
  const openCompose = (overrides: Partial<typeof composeProps> = {}) => {
    const contactEmail = contact?.email || "";
    const contactName = contact ? `${contact.first_name || ""} ${contact.last_name || ""}`.trim() : "";

    // Find last sent gmail_message_id for threading
    const lastSent = emailsSent.find(e => e.gmail_message_id && e.status === "sent");

    setComposeProps({
      toEmail: contactEmail,
      toName: contactName,
      subject: "",
      body: "",
      activityType: "email_sent",
      inReplyToMessageId: lastSent?.gmail_message_id || undefined,
      ...overrides,
    });
    setComposeOpen(true);
  };

  // Send Email button handler
  const handleSendEmail = () => openCompose();

  // Send Proposal — opens compose with proposal template
  const handleSendProposal = async () => {
    const stage = stages.find((s) => s.stage_key === "proposal_sent");
    if (stage && deal.stage_id !== stage.id) {
      await performStageChange(stage.id, stage);
    }

    // Get vertical name for subject
    let verticalRole = "Staffing";
    if (deal.vertical_id) {
      const { data: vert } = await supabase.from("verticals").select("name").eq("id", deal.vertical_id).maybeSingle();
      if (vert) verticalRole = vert.name;
    }
    const companyName = company?.name || "your company";

    openCompose({
      subject: `Proposal: ${verticalRole} Staffing for ${companyName}`,
      body: `Hi ${contact?.first_name || "there"},\n\nThank you for your time discussing your ${verticalRole.toLowerCase()} staffing needs. I'm pleased to share our proposal for ${companyName}.\n\n[Pricing details here]\n\nPlease let me know if you have any questions or would like to discuss further.\n\nBest regards`,
      activityType: "proposal",
    });
  };

  // Meeting confirmation compose after appointment creation
  const handleCreateAppointment = async () => {
    if (!meetingDate) { toast.error("Select a date and time"); return; }
    setMeetingCreating(true);

    const meetingTypeLabels: Record<string, string> = {
      discovery_call: "Discovery Call", demo: "Demo", follow_up: "Follow-up",
      proposal_review: "Proposal Review", closing_call: "Closing Call", other: "Meeting",
    };
    const typeLabel = meetingTypeLabels[meetingType] || "Meeting";
    const contactName = contact ? `${contact.first_name || ""} ${contact.last_name || ""}`.trim() : "contact";

    const { error } = await supabase.from("appointments").insert({
      deal_id: deal.id,
      contact_id: deal.contact_id,
      title: `${typeLabel} with ${contactName}`,
      description: meetingDesc || null,
      meeting_type: meetingType,
      scheduled_at: new Date(meetingDate).toISOString(),
      duration_minutes: parseInt(meetingDuration),
      meeting_link: meetingLink || null,
      assigned_to: user?.id,
      created_by: user?.id,
    });

    if (error) { toast.error("Failed to schedule meeting"); setMeetingCreating(false); return; }

    await supabase.from("deal_activities").insert({
      deal_id: deal.id,
      activity_type: "meeting",
      subject: `${typeLabel} scheduled with ${contactName}`,
      description: meetingLink ? `Meeting link: ${meetingLink}` : undefined,
      created_by: user?.id,
      metadata: { meeting_type: meetingType, duration: parseInt(meetingDuration), link: meetingLink },
    });

    await supabase.from("deal_tasks").insert({
      deal_id: deal.id,
      title: `Meeting: ${typeLabel} with ${contactName}`,
      due_date: new Date(meetingDate).toISOString(),
      priority: "high",
      assigned_to: user?.id,
      created_by: user?.id,
    });

    const currentStageKey = stages.find(s => s.id === deal.stage_id)?.stage_key;
    if (currentStageKey === "mql" || currentStageKey === "sal") {
      const msStage = stages.find(s => s.stage_key === "meeting_scheduled");
      if (msStage) await performStageChange(msStage.id, msStage);
    }

    setScheduleMeetingOpen(false);
    setMeetingCreating(false);
    toast.success("Meeting scheduled!");

    // Auto-open meeting confirmation compose dialog
    const meetingDateTime = new Date(meetingDate);
    const dateStr = meetingDateTime.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });
    const timeStr = meetingDateTime.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
    const bdmProfile = profiles.find(p => p.id === (deal.assigned_to || user?.id));

    let confirmBody = `Hi ${contact?.first_name || "there"},\n\nThis is to confirm our upcoming ${typeLabel.toLowerCase()}:\n\n`;
    confirmBody += `📅 Date: ${dateStr}\n⏰ Time: ${timeStr}\n⏱️ Duration: ${meetingDuration} minutes\n`;
    if (meetingLink) confirmBody += `🔗 Meeting Link: ${meetingLink}\n`;
    if (meetingDesc) confirmBody += `\n📋 Agenda: ${meetingDesc}\n`;
    confirmBody += `\nIf you need to reschedule, feel free to use my calendar link`;
    if (bdmProfile?.calendar_link) confirmBody += `: ${bdmProfile.calendar_link}`;
    confirmBody += `.\n\nLooking forward to speaking with you!\n\nBest regards`;
    if (bdmProfile?.full_name) confirmBody += `,\n${bdmProfile.full_name}`;
    if (bdmProfile?.title) confirmBody += `\n${bdmProfile.title}`;

    openCompose({
      subject: `Meeting Confirmed: ${typeLabel} — ${dateStr} at ${timeStr}`,
      body: confirmBody,
      activityType: "email_sent",
    });

    loadDeal();
  };

  const handleCompleteMeeting = (apptId: string) => {
    setCompleteMeetingId(apptId);
    setOutcomeNotes("");
    setQualifyChoice("nurture");
    setCompleteMeetingOpen(true);
  };

  const handleSubmitMeetingOutcome = async () => {
    if (!outcomeNotes.trim()) { toast.error("Enter outcome notes"); return; }

    await supabase.from("appointments").update({
      status: "completed",
      outcome_notes: outcomeNotes,
    }).eq("id", completeMeetingId);

    await supabase.from("deal_activities").insert({
      deal_id: deal.id,
      activity_type: "meeting",
      subject: "Meeting completed",
      description: outcomeNotes,
      created_by: user?.id,
    });

    if (qualifyChoice === "sql") {
      const sqlStage = stages.find(s => s.stage_key === "sql");
      if (sqlStage) await performStageChange(sqlStage.id, sqlStage);
    } else if (qualifyChoice === "lost") {
      setCompleteMeetingOpen(false);
      setLostReasonDialog(true);
      return;
    }

    setCompleteMeetingOpen(false);
    toast.success("Meeting outcome recorded");
    loadDeal();
  };

  const handleMarkNoShow = async (apptId: string) => {
    await supabase.from("appointments").update({ status: "no_show" }).eq("id", apptId);
    await supabase.from("deal_activities").insert({
      deal_id: deal.id,
      activity_type: "meeting",
      subject: "Meeting no-show",
      created_by: user?.id,
    });
    const contactName = contact ? `${contact.first_name || ""}`.trim() : "contact";
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    await supabase.from("deal_tasks").insert({
      deal_id: deal.id,
      title: `Reschedule with ${contactName}`,
      due_date: tomorrow.toISOString(),
      priority: "high",
      assigned_to: user?.id,
      created_by: user?.id,
    });
    toast.success("Marked as no-show. Follow-up task created for tomorrow.");
    loadDeal();
  };

  // --- Helpers ---
  const activityBorderColor = (type: string) => {
    const map: Record<string, string> = {
      email_sent: "border-l-primary", email_received: "border-l-primary",
      call: "border-l-amber-400", meeting: "border-l-emerald-500",
      note: "border-l-muted-foreground/30", linkedin_message: "border-l-blue-500",
      stage_change: "border-l-violet-500", task: "border-l-emerald-500",
      proposal: "border-l-amber-500", other: "border-l-muted-foreground/30",
    };
    return map[type] || "border-l-muted-foreground/30";
  };

  const activityIcon = (type: string) => {
    const map: Record<string, any> = {
      email_sent: Send, email_received: Mail, call: Phone, meeting: Calendar,
      note: FileText, linkedin_message: Linkedin, stage_change: Activity,
      task: CheckCircle2, proposal: FileText, other: MessageSquare,
    };
    const Icon = map[type] || Activity;
    return <Icon className="h-3.5 w-3.5" />;
  };

  const relativeTime = (date: string) => {
    const diff = Date.now() - new Date(date).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
  };

  const priorityDot = (p: string) => {
    if (p === "high") return "bg-destructive";
    if (p === "low") return "bg-muted-foreground/40";
    return "bg-amber-500";
  };

  const filteredTasks = tasks.filter((t) => {
    if (taskFilter === "pending") return t.status === "pending";
    if (taskFilter === "completed") return t.status === "completed";
    if (taskFilter === "overdue") return t.status === "pending" && new Date(t.due_date) < new Date();
    return true;
  });

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val.toFixed(0)}`;
  };

  const stageColor = (stage: LeadStage | undefined) => {
    if (!stage) return "bg-muted text-muted-foreground";
    if (stage.stage_key === "closed_won") return "bg-emerald-100 text-emerald-700 border-emerald-200";
    if (stage.stage_key === "closed_lost") return "bg-destructive/10 text-destructive border-destructive/20";
    if (stage.stage_type === "opportunity") return "bg-violet-100 text-violet-700 border-violet-200";
    return "bg-primary/10 text-primary border-primary/20";
  };

  const daysInPipeline = deal ? Math.floor((Date.now() - new Date(deal.created_at).getTime()) / 86400000) : 0;
  const daysColor = daysInPipeline < 14 ? "text-emerald-600" : daysInPipeline < 30 ? "text-amber-600" : "text-destructive";

  if (loading || !deal) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  const upcomingAppts = appointments.filter(a => a.status === "scheduled");

  return (
    <TooltipProvider>
      <div className="space-y-6 max-w-6xl">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Link to="/pipeline" className="hover:text-foreground transition-colors">Pipeline</Link>
          <ChevronRight className="h-3.5 w-3.5" />
          <span className="text-foreground font-medium truncate max-w-[300px]">{deal.deal_name}</span>
        </nav>

        {/* Gmail connection warning */}
        {gmailWarning && (
          <div className="flex items-start gap-2 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
            <AlertTriangle className="h-4 w-4 flex-shrink-0 mt-0.5 text-amber-600" />
            <span>{gmailWarning}</span>
          </div>
        )}

        {/* ===== HEADER CARD ===== */}
        <Card className="shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-start justify-between gap-4">
              {/* Left: Name + meta */}
              <div className="flex-1 min-w-0 space-y-3">
                {editingName ? (
                  <div className="flex gap-2 items-center">
                    <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="text-lg font-bold max-w-md" autoFocus onKeyDown={(e) => e.key === "Enter" && saveName()} />
                    <Button size="sm" onClick={saveName}>Save</Button>
                    <Button size="sm" variant="outline" onClick={() => setEditingName(false)}>Cancel</Button>
                  </div>
                ) : (
                  <h1 className="text-2xl font-bold tracking-tight cursor-pointer hover:text-primary/80 transition-colors" onClick={() => { setEditName(deal.deal_name); setEditingName(true); }}>
                    {deal.deal_name}
                  </h1>
                )}
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Stage pill selector */}
                  <Select value={deal.stage_id} onValueChange={changeStage}>
                    <SelectTrigger className={`h-7 w-auto text-xs font-medium rounded-full border px-3 ${stageColor(currentStage)}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {stages.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.stage_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {currentStage && (
                    <Badge variant="outline" className="text-[10px] rounded-full capitalize">{currentStage.stage_type}</Badge>
                  )}
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <Button size="sm" variant="outline" onClick={handleSendEmail} className="text-xs h-8 gap-1.5">
                  <Mail className="h-3.5 w-3.5" /> Email
                </Button>
                <Button size="sm" variant="outline" onClick={handleScheduleMeeting} className="text-xs h-8 gap-1.5">
                  <Calendar className="h-3.5 w-3.5" /> Meeting
                </Button>
                <Button size="sm" variant="outline" onClick={handleSendProposal} className="text-xs h-8 gap-1.5">
                  <FileText className="h-3.5 w-3.5" /> Proposal
                </Button>
                <Button size="sm" className="text-xs h-8 gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleMarkWon}>
                  <Trophy className="h-3.5 w-3.5" /> Mark Won
                </Button>
                <Button size="sm" variant="outline" className="text-xs h-8 gap-1.5 border-destructive/40 text-destructive hover:bg-destructive/10" onClick={handleMarkLost}>
                  <XCircle className="h-3.5 w-3.5" /> Mark Lost
                </Button>
                {isAdmin && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem className="text-destructive" onClick={() => setDeleteConfirm(true)}>
                        <Trash2 className="h-3.5 w-3.5 mr-2" /> Delete Deal
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ===== TWO-COLUMN INFO CARDS ===== */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Contact Details Card */}
          <Card className="shadow-sm">
            <CardContent className="p-5 space-y-4">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Contact</p>
              {contact ? (
                <>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-11 w-11">
                      <AvatarFallback className="text-sm font-semibold bg-primary/10 text-primary">
                        {(contact.first_name?.[0] || "") + (contact.last_name?.[0] || "")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-semibold">{contact.first_name} {contact.last_name}</p>
                      {contact.title && <p className="text-xs text-muted-foreground">{contact.title}</p>}
                    </div>
                  </div>
                  <div className="space-y-2.5">
                    {contact.email && (
                      <div className="flex items-center gap-2.5 text-sm">
                        <Mail className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                        <button onClick={() => openCompose()} className="text-primary hover:underline truncate">{contact.email}</button>
                      </div>
                    )}
                    {contact.phone && (
                      <div className="flex items-center gap-2.5 text-sm">
                        <Phone className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                        <span>{contact.phone}</span>
                      </div>
                    )}
                    {contact.linkedin_url && (
                      <div className="flex items-center gap-2.5 text-sm">
                        <Linkedin className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                        <a href={contact.linkedin_url.startsWith("http") ? contact.linkedin_url : `https://${contact.linkedin_url}`} target="_blank" rel="noopener" className="text-primary hover:underline inline-flex items-center gap-1">
                          LinkedIn <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    )}
                    {company && (
                      <div className="flex items-center gap-2.5 text-sm">
                        <Building2 className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                        <span>{company.name}{company.domain ? ` · ${company.domain}` : ""}</span>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <p className="text-sm text-muted-foreground py-4">No contact linked</p>
              )}
            </CardContent>
          </Card>

          {/* Deal Details Card */}
          <Card className="shadow-sm">
            <CardContent className="p-5 space-y-4">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Deal Details</p>
              <div className="grid grid-cols-2 gap-4">
                {/* Deal Value */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <DollarSign className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-semibold uppercase tracking-wide">Value</span>
                  </div>
                  {editingValue ? (
                    <div className="flex gap-1 items-center">
                      <Input type="number" value={editValue} onChange={(e) => setEditValue(e.target.value)} className="w-28 h-7 text-sm" autoFocus onKeyDown={(e) => e.key === "Enter" && saveValue()} />
                      <Button size="sm" variant="ghost" className="h-7 px-2" onClick={saveValue}>
                        <Check className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  ) : (
                    <button onClick={() => { setEditValue(deal.deal_value?.toString() || ""); setEditingValue(true); }} className="text-sm font-semibold hover:text-primary transition-colors">
                      {deal.deal_value ? formatCurrency(deal.deal_value) : <span className="text-muted-foreground font-normal">Click to set</span>}
                    </button>
                  )}
                </div>

                {/* Assigned To */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <User className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-semibold uppercase tracking-wide">Assigned To</span>
                  </div>
                  <Select value={deal.assigned_to || ""} onValueChange={updateAssignee}>
                    <SelectTrigger className="h-7 w-auto text-xs border-0 p-0 shadow-none font-medium">
                      <div className="flex items-center gap-1.5">
                        {assignedProfile && (
                          <Avatar className="h-5 w-5">
                            <AvatarFallback className="text-[8px] bg-muted">{assignedProfile.full_name?.split(" ").map((n: string) => n[0]).join("")}</AvatarFallback>
                          </Avatar>
                        )}
                        <SelectValue placeholder="Unassigned" />
                      </div>
                    </SelectTrigger>
                    <SelectContent>
                      {profiles.map((p) => (
                        <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Close Date */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <CalendarDays className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-semibold uppercase tracking-wide">Close Date</span>
                  </div>
                  <input
                    type="date"
                    value={deal.expected_close_date || ""}
                    onChange={(e) => updateCloseDate(e.target.value)}
                    className="text-sm font-medium bg-transparent border-0 p-0 text-foreground cursor-pointer"
                  />
                </div>

                {/* Days in Pipeline */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Timer className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-semibold uppercase tracking-wide">Days in Pipeline</span>
                  </div>
                  <p className={`text-sm font-semibold ${daysColor}`}>{daysInPipeline} days</p>
                </div>
              </div>

              {/* Won/Lost callouts */}
              {deal.won_date && (
                <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  <span className="text-sm font-medium text-emerald-700">Won on {deal.won_date}</span>
                </div>
              )}
              {deal.lost_reason && (
                <div className="bg-destructive/5 border border-destructive/20 rounded-lg px-3 py-2">
                  <p className="text-sm font-medium text-destructive">Lost: {deal.lost_reason}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ===== STAGE PROGRESS BAR ===== */}
        <Card className="shadow-sm">
          <CardContent className="px-5 py-4">
            <div className="flex items-center gap-1">
              {stages.filter(s => s.stage_type !== "closed").map((s, i, arr) => {
                const isCurrent = currentStage?.id === s.id;
                const isCompleted = currentStage && s.stage_order < currentStage.stage_order;
                const isClosed = currentStage?.stage_type === "closed";
                const filled = isCompleted || (isClosed && true);
                return (
                  <div key={s.id} className="flex-1 flex flex-col items-center gap-1.5 relative">
                    {/* Connector line */}
                    {i > 0 && (
                      <div className={`absolute top-2.5 -left-1/2 w-full h-0.5 ${filled || isCurrent ? "bg-primary" : "bg-muted"}`} />
                    )}
                    {/* Dot */}
                    <div className={`relative z-10 h-5 w-5 rounded-full border-2 flex items-center justify-center transition-all ${
                      isCurrent ? "border-primary bg-primary scale-110 shadow-md shadow-primary/30" :
                      filled ? "border-primary bg-primary" :
                      "border-muted bg-background"
                    }`}>
                      {(filled && !isCurrent) && <Check className="h-3 w-3 text-primary-foreground" />}
                      {isCurrent && <div className="h-2 w-2 rounded-full bg-primary-foreground animate-pulse" />}
                    </div>
                    <span className={`text-[9px] leading-tight text-center truncate w-full ${isCurrent ? "font-semibold text-primary" : filled ? "text-foreground" : "text-muted-foreground"}`}>
                      {s.stage_name.length > 10 ? s.stage_name.slice(0, 9) + "…" : s.stage_name}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* ===== TABS ===== */}
        <Tabs defaultValue="activity" className="w-full">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="activity" className="gap-1.5">
              Activity <Badge variant="secondary" className="text-[10px] h-4 px-1.5 ml-0.5">{activities.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="tasks" className="gap-1.5">
              Tasks <Badge variant="secondary" className="text-[10px] h-4 px-1.5 ml-0.5">{tasks.filter(t => t.status === "pending").length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="emails" className="gap-1.5">
              Emails <Badge variant="secondary" className="text-[10px] h-4 px-1.5 ml-0.5">{emailsSent.length + emailsReceived.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="history">Stage History</TabsTrigger>
          </TabsList>

          {/* ---- ACTIVITY TAB ---- */}
          <TabsContent value="activity" className="space-y-5 mt-5">
            {/* Upcoming Meetings */}
            {upcomingAppts.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Upcoming Meetings</p>
                {upcomingAppts.map((appt) => {
                  const isPast = new Date(appt.scheduled_at).getTime() < Date.now() - 3600000;
                  return (
                    <div key={appt.id} className="flex items-center gap-3 bg-amber-50/60 border border-amber-200/60 rounded-lg p-3.5">
                      <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                        <Calendar className="h-4 w-4 text-amber-700" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{appt.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(appt.scheduled_at).toLocaleString()} · {appt.duration_minutes}min
                          {appt.meeting_type && ` · ${appt.meeting_type.replace(/_/g, " ")}`}
                        </p>
                      </div>
                      <div className="flex gap-1.5 flex-shrink-0">
                        {appt.meeting_link && (
                          <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => window.open(appt.meeting_link, "_blank")}>
                            <ExternalLink className="h-3 w-3 mr-1" /> Join
                          </Button>
                        )}
                        <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => handleCompleteMeeting(appt.id)}>
                          Complete
                        </Button>
                        {isPast && (
                          <Button size="sm" variant="ghost" className="text-xs h-7 text-destructive" onClick={() => handleMarkNoShow(appt.id)}>
                            No-show
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <Button size="sm" variant="outline" onClick={() => setLogActivityOpen(true)} className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Log Activity
            </Button>

            {activities.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No activities yet</p>
            ) : (
              <div className="space-y-2">
                {activities.map((a) => {
                  const creator = profiles.find((p) => p.id === a.created_by);
                  return (
                    <div key={a.id} className={`flex gap-3 items-start border border-border border-l-[3px] ${activityBorderColor(a.activity_type)} rounded-lg p-3.5 bg-card`}>
                      <div className="mt-0.5 text-muted-foreground">{activityIcon(a.activity_type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-[10px] px-1.5 h-4">{a.activity_type.replace(/_/g, " ")}</Badge>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-[10px] text-muted-foreground cursor-default">{relativeTime(a.activity_date)}</span>
                            </TooltipTrigger>
                            <TooltipContent className="text-xs">{new Date(a.activity_date).toLocaleString()}</TooltipContent>
                          </Tooltip>
                          {creator && <span className="text-[10px] text-muted-foreground">by {creator.full_name}</span>}
                        </div>
                        <p className="text-sm font-medium mt-0.5">{a.subject}</p>
                        {a.description && <p className="text-xs text-muted-foreground mt-0.5">{a.description}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* ---- TASKS TAB ---- */}
          <TabsContent value="tasks" className="space-y-4 mt-5">
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => setAddTaskOpen(true)} className="gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Add Task
              </Button>
              <div className="flex gap-1">
                {(["all", "pending", "completed", "overdue"] as const).map((f) => (
                  <button key={f} onClick={() => setTaskFilter(f)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-medium transition-colors capitalize ${taskFilter === f ? "bg-primary text-primary-foreground" : "bg-muted/50 hover:bg-muted text-muted-foreground"}`}>
                    {f}
                  </button>
                ))}
              </div>
            </div>
            {filteredTasks.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No tasks</p>
            ) : (
              <div className="space-y-1.5">
                {filteredTasks.map((t) => {
                  const overdue = t.status === "pending" && new Date(t.due_date) < new Date();
                  const assignee = profiles.find((p) => p.id === t.assigned_to);
                  return (
                    <div key={t.id} className="flex items-center gap-3 hover:bg-muted/30 rounded-lg px-3 py-2.5 transition-colors group">
                      <button onClick={() => toggleTask(t.id, t.status)} className="flex-shrink-0">
                        <CheckCircle2 className={`h-4.5 w-4.5 transition-colors ${t.status === "completed" ? "text-emerald-500" : "text-muted-foreground/30 group-hover:text-muted-foreground/60"}`} />
                      </button>
                      <div className={`h-2 w-2 rounded-full flex-shrink-0 ${priorityDot(t.priority)}`} />
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${t.status === "completed" ? "line-through text-muted-foreground" : "font-medium"}`}>{t.title}</p>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground flex-shrink-0">
                        {assignee && <span>{assignee.full_name}</span>}
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className={overdue ? "text-destructive font-semibold" : ""}>
                              {overdue ? "Overdue" : relativeTime(t.due_date)}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent className="text-xs">{new Date(t.due_date).toLocaleString()}</TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* ---- EMAILS TAB ---- */}
          <TabsContent value="emails" className="space-y-3 mt-5">
            <Button size="sm" variant="outline" onClick={handleSendEmail} className="gap-1.5">
              <Send className="h-3.5 w-3.5" /> Send Email
            </Button>
            {emailsSent.length === 0 && emailsReceived.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No email history for this contact</p>
            ) : (
              <div className="space-y-1.5">
                {[
                  ...emailsSent.map((e) => ({ ...e, _type: "sent", _date: e.scheduled_at })),
                  ...emailsReceived.map((e) => ({ ...e, _type: "received", _date: e.received_at })),
                ]
                  .sort((a, b) => new Date(b._date).getTime() - new Date(a._date).getTime())
                  .map((e, i) => (
                    <div key={e.id} className={`flex gap-3 items-start rounded-lg p-3.5 ${e._type === "sent" ? "bg-card border border-border" : "bg-primary/[0.03] border border-primary/10"}`}>
                      <div className="mt-0.5 text-muted-foreground">
                        {e._type === "sent" ? <Send className="h-3.5 w-3.5" /> : <Mail className="h-3.5 w-3.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-[10px] px-1.5 h-4">
                            {e._type === "sent" ? "Sent" : "Received"}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground">{new Date(e._date).toLocaleString()}</span>
                          {e.status && e._type === "sent" && (
                            <Badge variant="outline" className="text-[9px] px-1 h-3.5">{e.status}</Badge>
                          )}
                        </div>
                        <p className="text-sm font-medium mt-0.5 truncate">{e.subject}</p>
                        {e._type === "sent" && e.body && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{e.body.replace(/<[^>]*>/g, "").slice(0, 200)}</p>
                        )}
                        {e._type === "received" && (e.body_text || e.body_html) && (
                          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{(e.body_text || e.body_html || "").replace(/<[^>]*>/g, "").slice(0, 200)}</p>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </TabsContent>

          {/* ---- STAGE HISTORY TAB ---- */}
          <TabsContent value="history" className="space-y-4 mt-5">
            {stageHistory.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No stage changes recorded</p>
            ) : (
              <div className="border border-border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="text-left px-3 py-2.5 text-xs font-medium text-muted-foreground">From</th>
                      <th className="text-left px-3 py-2.5 text-xs font-medium text-muted-foreground">To</th>
                      <th className="text-left px-3 py-2.5 text-xs font-medium text-muted-foreground">By</th>
                      <th className="text-left px-3 py-2.5 text-xs font-medium text-muted-foreground">Date</th>
                      <th className="text-left px-3 py-2.5 text-xs font-medium text-muted-foreground">Time in Stage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {stageHistory.map((h) => {
                      const from = stages.find((s) => s.id === h.from_stage_id);
                      const to = stages.find((s) => s.id === h.to_stage_id);
                      const by = profiles.find((p) => p.id === h.changed_by);
                      return (
                        <tr key={h.id} className="hover:bg-muted/20">
                          <td className="px-3 py-2.5 text-xs">{from?.stage_name || "—"}</td>
                          <td className="px-3 py-2.5 text-xs font-medium">{to?.stage_name || "—"}</td>
                          <td className="px-3 py-2.5 text-xs">{by?.full_name || "System"}</td>
                          <td className="px-3 py-2.5 text-xs">{new Date(h.changed_at).toLocaleString()}</td>
                          <td className="px-3 py-2.5 text-xs">
                            {h.time_in_previous_stage_hours != null ? `${Math.round(h.time_in_previous_stage_hours)}h` : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* ===== ALL DIALOGS ===== */}

        {/* Compose Email Dialog */}
        <ComposeEmailDialog
          open={composeOpen}
          onOpenChange={setComposeOpen}
          sendAsUserId={deal.assigned_to || user?.id}
          toEmail={composeProps.toEmail}
          toName={composeProps.toName}
          subject={composeProps.subject}
          body={composeProps.body}
          dealId={deal.id}
          activityType={composeProps.activityType}
          inReplyToMessageId={composeProps.inReplyToMessageId}
          onSent={() => loadDeal()}
        />

        {/* Log Activity Dialog */}
        <Dialog open={logActivityOpen} onOpenChange={setLogActivityOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Log Activity</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Type</Label>
                <Select value={activityType} onValueChange={setActivityType}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["call", "meeting", "note", "email_sent", "linkedin_message", "proposal", "other"].map((t) => (
                      <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {activityType === "email_sent" && (
                  <p className="text-xs text-primary mt-1">Selecting "email sent" will open the compose dialog to send an actual email.</p>
                )}
              </div>
              <div>
                <Label>Subject *</Label>
                <Input value={activitySubject} onChange={(e) => setActivitySubject(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Description</Label>
                <textarea value={activityDesc} onChange={(e) => setActivityDesc(e.target.value)} className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm min-h-[80px] bg-background" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setLogActivityOpen(false)}>Cancel</Button>
              <Button onClick={handleLogActivity}>{activityType === "email_sent" ? "Open Compose" : "Log"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Add Task Dialog */}
        <Dialog open={addTaskOpen} onOpenChange={setAddTaskOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Add Task</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Title *</Label>
                <Input value={taskTitle} onChange={(e) => setTaskTitle(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Description</Label>
                <textarea value={taskDesc} onChange={(e) => setTaskDesc(e.target.value)} className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm min-h-[60px] bg-background" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Due Date *</Label>
                  <Input type="datetime-local" value={taskDue} onChange={(e) => setTaskDue(e.target.value)} className="mt-1" />
                </div>
                <div>
                  <Label>Priority</Label>
                  <Select value={taskPriority} onValueChange={setTaskPriority}>
                    <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Assign To</Label>
                <Select value={taskAssignee} onValueChange={setTaskAssignee}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    {profiles.map((p) => (
                      <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddTaskOpen(false)}>Cancel</Button>
              <Button onClick={handleAddTask}>Add Task</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Lost Reason Dialog */}
        <Dialog open={lostReasonDialog} onOpenChange={setLostReasonDialog}>
          <DialogContent className="max-w-sm">
            <DialogHeader><DialogTitle>Why was this deal lost?</DialogTitle></DialogHeader>
            <div className="py-2">
              <Label>Reason (required)</Label>
              <Input value={lostReason} onChange={(e) => setLostReason(e.target.value)} placeholder="e.g., Budget constraints..." className="mt-1" />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setLostReasonDialog(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleConfirmLost}>Mark Lost</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <Dialog open={deleteConfirm} onOpenChange={setDeleteConfirm}>
          <DialogContent className="max-w-sm">
            <DialogHeader><DialogTitle>Delete this deal?</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">This will permanently delete the deal and all associated activities, tasks, and stage history.</p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteConfirm(false)}>Cancel</Button>
              <Button variant="destructive" onClick={handleDelete}>Delete</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Schedule Meeting Dialog */}
        <Dialog open={scheduleMeetingOpen} onOpenChange={setScheduleMeetingOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Schedule Meeting</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Meeting Type</Label>
                <Select value={meetingType} onValueChange={setMeetingType}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="discovery_call">Discovery Call</SelectItem>
                    <SelectItem value="demo">Demo</SelectItem>
                    <SelectItem value="follow_up">Follow-up</SelectItem>
                    <SelectItem value="proposal_review">Proposal Review</SelectItem>
                    <SelectItem value="closing_call">Closing Call</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date & Time *</Label>
                <Input type="datetime-local" value={meetingDate} onChange={(e) => setMeetingDate(e.target.value)} className="mt-1" />
              </div>
              <div>
                <Label>Duration</Label>
                <Select value={meetingDuration} onValueChange={setMeetingDuration}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                    <SelectItem value="60">60 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Meeting Link</Label>
                <Input value={meetingLink} onChange={(e) => setMeetingLink(e.target.value)} placeholder="https://zoom.us/..." className="mt-1" />
              </div>
              <div>
                <Label>Description</Label>
                <textarea value={meetingDesc} onChange={(e) => setMeetingDesc(e.target.value)} className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm min-h-[60px] bg-background" placeholder="Agenda or notes..." />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setScheduleMeetingOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateAppointment} disabled={meetingCreating}>{meetingCreating ? "Scheduling…" : "Schedule"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Post-Meeting Outcome Dialog */}
        <Dialog open={completeMeetingOpen} onOpenChange={setCompleteMeetingOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>Meeting Outcome</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div>
                <Label>Outcome Notes (required)</Label>
                <textarea value={outcomeNotes} onChange={(e) => setOutcomeNotes(e.target.value)} className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm min-h-[80px] bg-background" placeholder="What was discussed? Key takeaways..." />
              </div>
              <div>
                <Label>Qualify this lead?</Label>
                <div className="flex gap-2 mt-1">
                  {([
                    { value: "sql" as const, label: "Yes — move to SQL" },
                    { value: "nurture" as const, label: "Not yet — keep nurturing" },
                    { value: "lost" as const, label: "Disqualify — mark lost" },
                  ]).map((opt) => (
                    <button key={opt.value} onClick={() => setQualifyChoice(opt.value)}
                      className={`px-3 py-1.5 rounded-lg text-xs border transition-colors ${qualifyChoice === opt.value ? "border-primary bg-primary/10 font-medium" : "border-border hover:bg-muted"}`}>
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCompleteMeetingOpen(false)}>Cancel</Button>
              <Button onClick={handleSubmitMeetingOutcome}>Save Outcome</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  );
}
