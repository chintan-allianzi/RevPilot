import { useEffect, useState, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import {
  Inbox as InboxIcon,
  RefreshCw,
  Plus,
  Mail,
  Briefcase,
  Search,
  Pencil,
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Send,
} from "lucide-react";
import ComposeEmailDialog from "@/components/ComposeEmailDialog";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useIsMobile } from "@/hooks/use-mobile";

/* ── sentiment helpers ── */
const sentimentStyles: Record<string, string> = {
  positive: "bg-success/10 text-success border-success/20",
  neutral: "bg-muted text-muted-foreground border-border",
  negative: "bg-destructive/10 text-destructive border-destructive/20",
  out_of_office: "bg-primary/10 text-primary border-primary/20",
  unsubscribe: "bg-destructive/15 text-destructive border-destructive/30",
};

const sentimentDot: Record<string, string> = {
  positive: "bg-success",
  neutral: "bg-muted-foreground",
  negative: "bg-destructive",
  out_of_office: "bg-primary",
  unsubscribe: "bg-destructive",
};

const sentimentLabel: Record<string, string> = {
  positive: "Interested",
  neutral: "Neutral",
  negative: "Not Interested",
  out_of_office: "Out of Office",
  unsubscribe: "Unsubscribed",
};

interface LeadStage {
  id: string;
  stage_key: string;
  stage_name: string;
  stage_order: number;
}

const getInitials = (name: string) => {
  const parts = name.trim().split(/\s+/);
  return parts.length >= 2
    ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
    : name.slice(0, 2).toUpperCase();
};

const relativeTime = (dateStr: string) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
};

export default function Inbox() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [replies, setReplies] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "unread" | "positive" | "negative">("all");
  const [selectedReply, setSelectedReply] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileShowDetail, setMobileShowDetail] = useState(false);
  const [manualLogOpen, setManualLogOpen] = useState(false);

  // Manual reply modal
  const [manualReplyModal, setManualReplyModal] = useState(false);
  const [manualFromEmail, setManualFromEmail] = useState("");
  const [manualCampaignId, setManualCampaignId] = useState("");
  const [manualReplyText, setManualReplyText] = useState("");
  const [manualSentiment, setManualSentiment] = useState("");
  const [campaigns, setCampaigns] = useState<any[]>([]);

  // Create deal dialog
  const [createDealOpen, setCreateDealOpen] = useState(false);
  const [dealStageId, setDealStageId] = useState("");
  const [leadStages, setLeadStages] = useState<LeadStage[]>([]);
  const [dealCreating, setDealCreating] = useState(false);

  // Track which replies have deals
  const [replyDealMap, setReplyDealMap] = useState<Record<string, { id: string; stage_name: string }>>({});

  const noteSaveTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Compose dialog state for replying via Gmail API
  const [composeOpen, setComposeOpen] = useState(false);
  const [composeToEmail, setComposeToEmail] = useState("");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeDealId, setComposeDealId] = useState<string | undefined>(undefined);
  const [composeSendAsUserId, setComposeSendAsUserId] = useState<string | undefined>(undefined);
  const [composeInReplyTo, setComposeInReplyTo] = useState<string | undefined>(undefined);

  useEffect(() => {
    loadReplies();
    loadCampaigns();
    loadLeadStages();
  }, []);

  // ── all data loading functions (unchanged logic) ──
  const loadReplies = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("email_replies")
      .select("*")
      .order("received_at", { ascending: false });
    setReplies(data || []);
    setLoading(false);
    if (data && data.length > 0) {
      loadDealMappings(data);
    }
  };

  const loadDealMappings = async (replyData: any[]) => {
    const contactIds = [...new Set(replyData.map((r) => r.contact_id).filter(Boolean))];
    if (contactIds.length === 0) return;
    const emailsWithoutContact = replyData.filter((r) => !r.contact_id).map((r) => r.from_email);
    let allContactIds = [...contactIds];
    if (emailsWithoutContact.length > 0) {
      const { data: contacts } = await supabase.from("saved_contacts").select("id, email").in("email", emailsWithoutContact);
      if (contacts) allContactIds.push(...contacts.map((c) => c.id));
    }
    if (allContactIds.length === 0) return;
    const { data: deals } = await supabase.from("deals").select("id, contact_id, stage_id").in("contact_id", allContactIds);
    if (!deals || deals.length === 0) return;
    const stageIds = [...new Set(deals.map((d) => d.stage_id))];
    const { data: stages } = await supabase.from("lead_stages").select("id, stage_name").in("id", stageIds);
    const stageMap = new Map(stages?.map((s) => [s.id, s.stage_name]) || []);
    const mapping: Record<string, { id: string; stage_name: string }> = {};
    for (const reply of replyData) {
      const deal = deals.find((d) => d.contact_id === reply.contact_id);
      if (deal) mapping[reply.id] = { id: deal.id, stage_name: stageMap.get(deal.stage_id) || "Unknown" };
    }
    setReplyDealMap(mapping);
  };

  const loadCampaigns = async () => {
    const { data } = await supabase.from("campaigns").select("id, name").order("created_at", { ascending: false });
    setCampaigns(data || []);
  };

  const loadLeadStages = async () => {
    const { data } = await supabase.from("lead_stages").select("id, stage_key, stage_name, stage_order").order("stage_order");
    setLeadStages((data as LeadStage[]) || []);
    const mql = data?.find((s: any) => s.stage_key === "mql");
    if (mql) setDealStageId(mql.id);
  };

  const filteredReplies = replies.filter((r) => {
    if (filter === "unread") return !r.is_read;
    if (filter === "positive") return r.sentiment === "positive";
    if (filter === "negative") return r.sentiment === "negative" || r.sentiment === "out_of_office";
    return true;
  }).filter((r) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      (r.from_name || "").toLowerCase().includes(q) ||
      (r.from_email || "").toLowerCase().includes(q) ||
      (r.subject || "").toLowerCase().includes(q)
    );
  });

  const unreadCount = replies.filter((r) => !r.is_read).length;

  const handleSelectReply = async (reply: any) => {
    setSelectedReply(reply);
    if (isMobile) setMobileShowDetail(true);
    if (!reply.is_read) {
      await supabase.from("email_replies").update({ is_read: true }).eq("id", reply.id);
      setReplies((prev) => prev.map((r) => (r.id === reply.id ? { ...r, is_read: true } : r)));
    }
  };

  const resolveContact = useCallback(async (reply: any) => {
    if (reply.contact_id) {
      const { data } = await supabase.from("saved_contacts").select("id, first_name, last_name, email, company_id").eq("id", reply.contact_id).maybeSingle();
      return data;
    }
    const { data } = await supabase.from("saved_contacts").select("id, first_name, last_name, email, company_id").eq("email", reply.from_email).limit(1).maybeSingle();
    return data;
  }, []);

  const resolveCompany = useCallback(async (companyId: string) => {
    const { data } = await supabase.from("saved_companies").select("id, name, vertical_id").eq("id", companyId).maybeSingle();
    return data;
  }, []);

  const checkExistingDeal = useCallback(async (contactId: string) => {
    const { data: closedStages } = await supabase.from("lead_stages").select("id").in("stage_key", ["closed_won", "closed_lost"]);
    const closedIds = closedStages?.map((s) => s.id) || [];
    const { data: deals } = await supabase.from("deals").select("id, deal_name, stage_id").eq("contact_id", contactId);
    if (!deals || deals.length === 0) return null;
    return deals.find((d) => !closedIds.includes(d.stage_id)) || null;
  }, []);

  const createDealFromReply = useCallback(async (reply: any, stageKey: string = "mql", showToast: boolean = true) => {
    const contact = await resolveContact(reply);
    if (!contact) { if (showToast) toast.error("Could not find a matching contact for this reply"); return null; }
    const existingDeal = await checkExistingDeal(contact.id);
    if (existingDeal) { if (showToast) toast.info("Deal already exists for this contact", { action: { label: "View", onClick: () => navigate(`/pipeline/${existingDeal.id}`) } }); return existingDeal; }
    const company = contact.company_id ? await resolveCompany(contact.company_id) : null;
    const stage = leadStages.find((s) => s.stage_key === stageKey);
    if (!stage) { toast.error("Could not find lead stage"); return null; }
    let verticalName = "";
    if (company?.vertical_id) {
      const { data: vert } = await supabase.from("verticals").select("name").eq("id", company.vertical_id).maybeSingle();
      verticalName = vert?.name || "";
    }
    const contactName = [contact.first_name, contact.last_name].filter(Boolean).join(" ") || reply.from_name || reply.from_email;
    const companyName = company?.name || "";
    const dealName = [contactName, companyName, verticalName].filter(Boolean).join(" — ");
    const { data: deal, error } = await supabase.from("deals").insert({ contact_id: contact.id, company_id: contact.company_id || null, campaign_id: reply.campaign_id || null, vertical_id: company?.vertical_id || null, stage_id: stage.id, deal_name: dealName, assigned_to: reply.assigned_to || user?.id || null }).select("id").single();
    if (error || !deal) { if (showToast) toast.error("Failed to create deal"); return null; }
    await supabase.from("deal_stage_history").insert({ deal_id: deal.id, from_stage_id: null, to_stage_id: stage.id, changed_by: user?.id, notes: "Auto-created from positive reply" });
    await supabase.from("deal_activities").insert({ deal_id: deal.id, activity_type: "email_received", subject: "Positive reply received", description: `Reply from ${reply.from_email}: "${(reply.subject || "").slice(0, 100)}"`, created_by: user?.id });
    setReplyDealMap((prev) => ({ ...prev, [reply.id]: { id: deal.id, stage_name: stage.stage_name } }));
    if (showToast) toast.success(`Deal created — ${contactName} moved to ${stage.stage_name}`);
    return deal;
  }, [resolveContact, resolveCompany, checkExistingDeal, leadStages, user, navigate]);

  const handleClassifyReply = async (replyId: string, sentiment: string) => {
    const is_positive = sentiment === "positive";
    await supabase.from("email_replies").update({ sentiment, is_positive }).eq("id", replyId);
    setSelectedReply((prev: any) => (prev ? { ...prev, sentiment, is_positive } : null));
    setReplies((prev) => prev.map((r) => (r.id === replyId ? { ...r, sentiment, is_positive } : r)));
    toast.success(`Reply classified as "${sentimentLabel[sentiment] || sentiment}"`);
    if (sentiment === "positive") {
      const reply = replies.find((r) => r.id === replyId) || selectedReply;
      if (reply && !replyDealMap[replyId]) await createDealFromReply(reply, "mql", true);
    }
  };

  const handleUpdateNotes = (replyId: string, notes: string) => {
    setSelectedReply((prev: any) => (prev ? { ...prev, notes } : null));
    if (noteSaveTimeout.current) clearTimeout(noteSaveTimeout.current);
    noteSaveTimeout.current = setTimeout(async () => {
      await supabase.from("email_replies").update({ notes }).eq("id", replyId);
    }, 1000);
  };

  const handleLogManualReply = async () => {
    if (!manualFromEmail) { toast.error("Enter the sender email"); return; }
    const { data: matchingEmail } = await supabase.from("email_queue").select("id, contact_id, campaign_id, subject, to_name").eq("to_email", manualFromEmail).eq("status", "sent").order("sent_at", { ascending: false }).limit(1).maybeSingle();
    const resolvedCampaignId = manualCampaignId || matchingEmail?.campaign_id || null;
    const { error } = await supabase.from("email_replies").insert({ email_queue_id: matchingEmail?.id || null, campaign_id: resolvedCampaignId, contact_id: matchingEmail?.contact_id || null, from_email: manualFromEmail, from_name: matchingEmail?.to_name || manualFromEmail.split("@")[0], subject: `Re: ${matchingEmail?.subject || "Campaign email"}`, body_text: manualReplyText, received_at: new Date().toISOString(), is_read: true, sentiment: manualSentiment || "neutral", is_positive: manualSentiment === "positive", assigned_to: user?.id });
    if (error) { toast.error("Failed to log reply"); return; }
    if (matchingEmail?.contact_id && resolvedCampaignId) {
      await supabase.from("email_queue").update({ status: "cancelled", error_message: "Contact replied — sequence paused", updated_at: new Date().toISOString() }).eq("contact_id", matchingEmail.contact_id).eq("campaign_id", resolvedCampaignId).eq("status", "scheduled");
      await supabase.from("email_queue").update({ status: "replied", replied_at: new Date().toISOString() }).eq("id", matchingEmail.id);
    }
    await supabase.from("email_queue").update({ status: "cancelled", error_message: "Contact replied in another campaign" }).eq("to_email", manualFromEmail).eq("status", "scheduled");
    setManualReplyModal(false);
    setManualFromEmail(""); setManualReplyText(""); setManualSentiment(""); setManualCampaignId("");
    toast.success("Reply logged! Sequence paused for this contact across all campaigns.");
    loadReplies();
  };

  const handleManualCreateDeal = async () => {
    if (!selectedReply || !dealStageId) return;
    setDealCreating(true);
    const stage = leadStages.find((s) => s.id === dealStageId);
    await createDealFromReply(selectedReply, stage?.stage_key || "mql", true);
    setDealCreating(false);
    setCreateDealOpen(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  /* ── filter counts ── */
  const interestedCount = replies.filter((r) => r.sentiment === "positive").length;
  const notInterestedCount = replies.filter((r) => r.sentiment === "negative" || r.sentiment === "out_of_office").length;

  const filterTabs = [
    { key: "all" as const, label: "All", count: replies.length },
    { key: "unread" as const, label: "Unread", count: unreadCount },
    { key: "positive" as const, label: "Interested", count: interestedCount },
    { key: "negative" as const, label: "Not Interested", count: notInterestedCount },
  ];

  /* ── Reply list item ── */
  const ReplyRow = ({ reply }: { reply: any }) => {
    const displayName = reply.from_name || reply.from_email;
    const isSelected = selectedReply?.id === reply.id;
    const snippet = (reply.body_text || reply.subject || "").slice(0, 80);

    return (
      <button
        onClick={() => handleSelectReply(reply)}
        className={`w-full text-left px-4 py-3 transition-all duration-150 relative ${
          isSelected ? "bg-accent" : "hover:bg-muted/40"
        }`}
      >
        {/* Unread indicator bar */}
        {!reply.is_read && (
          <div className="absolute left-0 top-2 bottom-2 w-0.5 bg-primary rounded-r" />
        )}

        <div className="flex items-start gap-3">
          {/* Avatar */}
          <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-[11px] font-semibold text-primary">
              {getInitials(displayName)}
            </span>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <span className={`text-sm truncate ${!reply.is_read ? "font-semibold" : "font-medium"}`}>
                {displayName}
              </span>
              <span className="text-[10px] text-muted-foreground flex-shrink-0 whitespace-nowrap">
                {relativeTime(reply.received_at)}
              </span>
            </div>

            <div className="flex items-center gap-1.5 mt-0.5">
              {reply.sentiment && (
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${sentimentDot[reply.sentiment] || "bg-muted-foreground"}`} />
              )}
              <p className="text-xs text-muted-foreground truncate">{reply.subject}</p>
            </div>

            <p className="text-[11px] text-muted-foreground/70 truncate mt-0.5">{snippet}</p>

            {reply.campaign_id && (
              <p className="text-[10px] text-muted-foreground/50 mt-0.5">Campaign reply</p>
            )}
          </div>
        </div>
      </button>
    );
  };

  /* ── Detail panel ── */
  const DetailPanel = () => {
    if (!selectedReply) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-12">
          <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
            <Mail className="h-8 w-8 text-muted-foreground/40" />
          </div>
          <p className="text-sm font-medium text-muted-foreground">Select a reply to view details</p>
          <p className="text-xs text-muted-foreground/60 mt-1">Choose a message from the list</p>
        </div>
      );
    }

    const displayName = selectedReply.from_name || selectedReply.from_email;

    return (
      <div className="flex flex-col h-full overflow-y-auto">
        {/* Mobile back button */}
        {isMobile && (
          <button
            onClick={() => setMobileShowDetail(false)}
            className="flex items-center gap-1.5 px-4 py-2.5 text-sm text-muted-foreground hover:text-foreground border-b border-border"
          >
            <ArrowLeft className="h-4 w-4" /> Back to list
          </button>
        )}

        {/* Header */}
        <div className="px-6 py-5 border-b border-border">
          <div className="flex items-start gap-4">
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <span className="text-sm font-semibold text-primary">{getInitials(displayName)}</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-semibold">{displayName}</h2>
                {selectedReply.sentiment && (
                  <Badge variant="outline" className={`text-xs ${sentimentStyles[selectedReply.sentiment] || ""}`}>
                    {sentimentLabel[selectedReply.sentiment] || selectedReply.sentiment}
                  </Badge>
                )}
                {replyDealMap[selectedReply.id] && (
                  <button onClick={() => navigate(`/pipeline/${replyDealMap[selectedReply.id].id}`)}>
                    <Badge variant="outline" className="text-xs bg-primary/5 text-primary border-primary/20 cursor-pointer hover:bg-primary/10">
                      <Briefcase className="h-3 w-3 mr-1" />
                      {replyDealMap[selectedReply.id].stage_name}
                    </Badge>
                  </button>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">{selectedReply.from_email}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {selectedReply.subject} · {new Date(selectedReply.received_at).toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="px-6 py-5 space-y-5 flex-1">
          {/* Email body */}
          <div className="bg-muted/30 rounded-lg p-5 border border-border/50">
            <p className="text-sm whitespace-pre-wrap leading-relaxed">
              {selectedReply.body_text || selectedReply.body_html || "No content available"}
            </p>
          </div>

          {/* Sentiment classification */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Classify</p>
            <div className="flex gap-2 flex-wrap">
              {[
                { value: "positive", label: "Interested" },
                { value: "neutral", label: "Neutral" },
                { value: "negative", label: "Not Interested" },
                { value: "out_of_office", label: "Out of Office" },
              ].map((s) => (
                <button
                  key={s.value}
                  onClick={() => handleClassifyReply(selectedReply.id, s.value)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-150 ${
                    selectedReply.sentiment === s.value
                      ? (sentimentStyles[s.value] || "") + " ring-2 ring-offset-1 ring-primary/30"
                      : "border-border hover:bg-muted"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes — inline editable card */}
          <div className="rounded-lg border border-border p-4 bg-background">
            <div className="flex items-center gap-1.5 mb-2">
              <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Notes</span>
            </div>
            <textarea
              value={selectedReply.notes || ""}
              onChange={(e) => handleUpdateNotes(selectedReply.id, e.target.value)}
              placeholder="Add your notes about this reply..."
              className="w-full text-sm min-h-[70px] bg-transparent border-none outline-none resize-none placeholder:text-muted-foreground/40"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-2.5 flex-wrap">
            {replyDealMap[selectedReply.id] ? (
              <>
                <Button
                  size="sm"
                  className="gap-1.5"
                  onClick={() => {
                    const deal = replyDealMap[selectedReply.id];
                    setComposeToEmail(selectedReply.from_email);
                    setComposeSubject(`Re: ${selectedReply.subject || ""}`);
                    setComposeDealId(deal.id);
                    setComposeSendAsUserId(selectedReply.assigned_to || user?.id);
                    setComposeInReplyTo(selectedReply.gmail_message_id || undefined);
                    setComposeOpen(true);
                  }}
                >
                  <Send className="h-3.5 w-3.5" /> Reply
                </Button>
                <a
                  href={`mailto:${selectedReply.from_email}?subject=Re: ${encodeURIComponent(selectedReply.subject || "")}`}
                  className="px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground border border-border rounded-lg inline-flex items-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="h-3 w-3" /> Open in Gmail
                </a>
              </>
            ) : (
              <a
                href={`mailto:${selectedReply.from_email}?subject=Re: ${encodeURIComponent(selectedReply.subject || "")}`}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium inline-flex items-center gap-1.5 hover:bg-primary/90 transition-colors"
              >
                <Mail className="h-3.5 w-3.5" /> Reply in Gmail
              </a>
            )}
            {selectedReply.campaign_id && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => navigate(`/campaigns/${selectedReply.campaign_id}`)}
                className="gap-1.5"
              >
                <ExternalLink className="h-3.5 w-3.5" /> View Campaign
              </Button>
            )}
            {!replyDealMap[selectedReply.id] && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCreateDealOpen(true)}
                className="gap-1.5"
              >
                <Briefcase className="h-3.5 w-3.5" /> Create Deal
              </Button>
            )}
          </div>

          {/* Manual reply log — collapsible */}
          <div className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => setManualLogOpen(!manualLogOpen)}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-muted-foreground hover:bg-muted/30 transition-colors"
            >
              <span className="flex items-center gap-1.5">
                <Plus className="h-3.5 w-3.5" /> Log a Reply Manually
              </span>
              {manualLogOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>
            <AnimatePresence>
              {manualLogOpen && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 pt-2 border-t border-border space-y-3">
                    <p className="text-xs text-muted-foreground">Record a reply you received outside the system</p>
                    <Button size="sm" variant="outline" onClick={() => setManualReplyModal(true)}>
                      Open Reply Form
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    );
  };

  /* ── Main layout ── */
  return (
    <div className="flex flex-col h-[calc(100vh-6rem)] max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Inbox</h1>
          <p className="text-sm text-muted-foreground">
            {unreadCount > 0 ? `${unreadCount} unread replies` : "All replies across campaigns"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setManualReplyModal(true)} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" /> Log Reply
          </Button>
          <Button variant="outline" size="sm" onClick={loadReplies} className="gap-1.5">
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </Button>
        </div>
      </div>

      {/* Two-panel layout */}
      <div className="flex-1 min-h-0 flex border border-border rounded-xl overflow-hidden bg-background">
        {/* Left panel — reply list */}
        {(!isMobile || !mobileShowDetail) && (
          <div className={`flex flex-col ${isMobile ? "w-full" : "w-[38%] border-r border-border"}`}>
            {/* Search */}
            <div className="p-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search replies..."
                  className="w-full pl-9 pr-3 py-2 text-sm bg-muted/40 border-none rounded-lg outline-none placeholder:text-muted-foreground/50 focus:bg-muted/60 transition-colors"
                />
              </div>
            </div>

            {/* Filter pills */}
            <div className="px-3 py-2.5 border-b border-border flex gap-1.5 overflow-x-auto">
              {filterTabs.map((f) => (
                <button
                  key={f.key}
                  onClick={() => setFilter(f.key)}
                  className={`px-3 py-1 rounded-full text-[11px] font-medium transition-all whitespace-nowrap ${
                    filter === f.key
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {f.label}
                  <span className={`ml-1 ${filter === f.key ? "text-primary-foreground/70" : "text-muted-foreground/60"}`}>
                    {f.count}
                  </span>
                </button>
              ))}
            </div>

            {/* Reply list */}
            <div className="flex-1 overflow-y-auto divide-y divide-border/50">
              {filteredReplies.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-8 text-center">
                  <InboxIcon className="h-10 w-10 text-muted-foreground/20 mb-3" />
                  <p className="text-sm text-muted-foreground">
                    {replies.length === 0
                      ? "No replies yet. They'll appear here when contacts respond."
                      : "No replies match this filter."}
                  </p>
                </div>
              ) : (
                filteredReplies.map((reply) => <ReplyRow key={reply.id} reply={reply} />)
              )}
            </div>
          </div>
        )}

        {/* Right panel — detail */}
        {(!isMobile || mobileShowDetail) && (
          <div className={`flex flex-col ${isMobile ? "w-full" : "flex-1"}`}>
            <DetailPanel />
          </div>
        )}
      </div>

      {/* Manual Reply Modal */}
      <Dialog open={manualReplyModal} onOpenChange={setManualReplyModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Log a Reply</DialogTitle>
            <DialogDescription>Record a reply you received in Gmail</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>From (email)</Label>
              <Input
                type="email"
                value={manualFromEmail}
                onChange={(e) => setManualFromEmail(e.target.value)}
                placeholder="contact@company.com"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Campaign</Label>
              <Select value={manualCampaignId} onValueChange={setManualCampaignId}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select campaign..." />
                </SelectTrigger>
                <SelectContent>
                  {campaigns.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Reply content</Label>
              <textarea
                value={manualReplyText}
                onChange={(e) => setManualReplyText(e.target.value)}
                placeholder="Paste the reply email content here..."
                className="w-full mt-1 px-3 py-2 border border-border rounded-lg text-sm min-h-[120px] bg-background"
              />
            </div>
            <div>
              <Label>Sentiment</Label>
              <div className="flex gap-2 mt-1.5">
                {["positive", "neutral", "negative", "out_of_office"].map((s) => (
                  <button
                    key={s}
                    onClick={() => setManualSentiment(s)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                      manualSentiment === s
                        ? sentimentStyles[s] + " ring-2 ring-offset-1 ring-primary/30"
                        : "border-border hover:bg-muted"
                    }`}
                  >
                    {sentimentLabel[s] || s.replace("_", " ")}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setManualReplyModal(false)}>Cancel</Button>
            <Button onClick={handleLogManualReply}>Log Reply & Pause Sequence</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Deal Dialog */}
      <Dialog open={createDealOpen} onOpenChange={setCreateDealOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create Deal</DialogTitle>
            <DialogDescription>
              Create a pipeline deal for {selectedReply?.from_name || selectedReply?.from_email}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Contact</Label>
              <Input value={selectedReply?.from_name || selectedReply?.from_email || ""} disabled className="mt-1" />
            </div>
            <div>
              <Label>Initial Stage</Label>
              <Select value={dealStageId} onValueChange={setDealStageId}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  {leadStages
                    .filter((s) => s.stage_key !== "closed_won" && s.stage_key !== "closed_lost")
                    .map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.stage_name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDealOpen(false)}>Cancel</Button>
            <Button onClick={handleManualCreateDeal} disabled={dealCreating}>
              {dealCreating ? "Creating…" : "Create Deal"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Compose Email Dialog (for replies with deals) */}
      <ComposeEmailDialog
        open={composeOpen}
        onOpenChange={setComposeOpen}
        sendAsUserId={composeSendAsUserId}
        toEmail={composeToEmail}
        subject={composeSubject}
        dealId={composeDealId}
        inReplyToMessageId={composeInReplyTo}
        onSent={() => loadReplies()}
      />
    </div>
  );
}
