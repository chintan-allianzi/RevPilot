import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Linkedin, Copy, Check, ExternalLink, SkipForward, Loader2, ChevronDown, ChevronRight, PartyPopper } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

const TIER_STYLE: Record<string, string> = {
  T1: "bg-emerald-100 text-emerald-700",
  T2: "bg-blue-100 text-blue-700",
  T3: "bg-muted text-muted-foreground",
};

const TASK_TYPE_STYLE: Record<string, { label: string; cls: string }> = {
  connection_request: { label: "Connection", cls: "bg-blue-100 text-blue-700" },
  dm: { label: "DM", cls: "bg-purple-100 text-purple-700" },
};

export default function LinkedInQueue() {
  const { user } = useAuth();
  const [pendingTasks, setPendingTasks] = useState<any[]>([]);
  const [completedTasks, setCompletedTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(true);
  const [expandedMessage, setExpandedMessage] = useState<string | null>(null);

  const loadTasks = async () => {
    if (!user?.id) return;
    setLoading(true);
    const today = new Date().toISOString().split("T")[0];

    const [pendingRes, completedRes] = await Promise.all([
      supabase
        .from("linkedin_tasks")
        .select("*")
        .eq("assigned_to", user.id)
        .eq("status", "pending")
        .lte("scheduled_date", today)
        .order("contact_tier", { ascending: true })
        .order("scheduled_date", { ascending: true }),
      supabase
        .from("linkedin_tasks")
        .select("*")
        .eq("assigned_to", user.id)
        .eq("status", "completed")
        .gte("completed_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
        .order("completed_at", { ascending: false }),
    ]);

    setPendingTasks(pendingRes.data || []);
    setCompletedTasks(completedRes.data || []);
    setLoading(false);
  };

  useEffect(() => {
    loadTasks();
  }, [user?.id]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success("Copied to clipboard");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const markDone = async (taskId: string) => {
    await supabase
      .from("linkedin_tasks")
      .update({ status: "completed", completed_at: new Date().toISOString() } as any)
      .eq("id", taskId);
    await loadTasks();
    toast.success("Task completed");
  };

  const skipTask = async (taskId: string) => {
    await supabase
      .from("linkedin_tasks")
      .update({ status: "skipped" } as any)
      .eq("id", taskId);
    await loadTasks();
  };

  const getInitials = (name: string) => {
    return name?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-6 max-w-4xl">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold tracking-tight">LinkedIn Queue</h1>
          <p className="text-sm text-muted-foreground">{pendingTasks.length} pending tasks for today</p>
        </motion.div>

        {/* Today's Tasks */}
        <div className="space-y-3">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Today's Tasks</h2>

          {pendingTasks.length === 0 ? (
            <div className="border border-dashed border-border rounded-xl bg-muted/10 py-14 text-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="mx-auto mb-4"
              >
                <div className="w-16 h-16 rounded-2xl bg-emerald-100 flex items-center justify-center mx-auto">
                  <PartyPopper className="h-8 w-8 text-emerald-600" />
                </div>
              </motion.div>
              <p className="text-base font-medium text-foreground">All caught up!</p>
              <p className="text-sm text-muted-foreground mt-1">
                {completedTasks.length > 0
                  ? `You completed ${completedTasks.length} task${completedTasks.length > 1 ? "s" : ""} today. Great work!`
                  : "No LinkedIn tasks for today. Launch a campaign to create tasks."}
              </p>
            </div>
          ) : (
            <AnimatePresence>
              {pendingTasks.map((task) => {
                const taskType = TASK_TYPE_STYLE[task.task_type] || TASK_TYPE_STYLE.connection_request;
                const tierStyle = TIER_STYLE[task.contact_tier] || TIER_STYLE.T3;
                const isExpanded = expandedMessage === task.id;
                const msgPreview = task.message?.length > 120 && !isExpanded
                  ? task.message.slice(0, 120) + "…"
                  : task.message;

                return (
                  <motion.div
                    key={task.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="bg-card border border-border rounded-xl p-4 hover:shadow-sm transition-shadow"
                  >
                    <div className="flex items-start gap-4">
                      {/* Left: Avatar + Info */}
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-xs font-bold text-primary">
                          {getInitials(task.contact_name)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-semibold text-foreground">{task.contact_name}</p>
                            <Badge className={`text-[10px] border-0 ${taskType.cls}`}>{taskType.label}</Badge>
                            {task.contact_tier && (
                              <Badge className={`text-[10px] border-0 ${tierStyle}`}>{task.contact_tier}</Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {task.contact_title} · {task.contact_company}
                          </p>

                          {/* Message preview */}
                          {task.message && (
                            <div
                              className="mt-2.5 p-3 rounded-lg bg-muted/40 border border-border/50 text-sm text-foreground cursor-pointer"
                              onClick={() => setExpandedMessage(isExpanded ? null : task.id)}
                            >
                              {msgPreview}
                              {task.message?.length > 120 && (
                                <span className="text-xs text-primary ml-1 font-medium">
                                  {isExpanded ? "Show less" : "Show more"}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Action buttons as icons */}
                      <div className="flex items-center gap-1 shrink-0">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8"
                              onClick={() => handleCopy(task.id, task.message)}
                            >
                              {copiedId === task.id ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>{copiedId === task.id ? "Copied!" : "Copy message"}</TooltipContent>
                        </Tooltip>

                        {task.contact_linkedin_url && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button size="icon" variant="ghost" className="h-8 w-8" asChild>
                                <a
                                  href={task.contact_linkedin_url.startsWith("http") ? task.contact_linkedin_url : `https://${task.contact_linkedin_url}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <ExternalLink className="h-3.5 w-3.5" />
                                </a>
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Open LinkedIn</TooltipContent>
                          </Tooltip>
                        )}

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="icon"
                              className="h-8 w-8 bg-emerald-600 hover:bg-emerald-700 text-white"
                              onClick={() => markDone(task.id)}
                            >
                              <Check className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Mark as done</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="icon"
                              variant="ghost"
                              className="h-8 w-8 text-muted-foreground"
                              onClick={() => skipTask(task.id)}
                            >
                              <SkipForward className="h-3.5 w-3.5" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Skip task</TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>

        {/* Completed Today — collapsible */}
        {completedTasks.length > 0 && (
          <div>
            <button
              onClick={() => setShowCompleted(!showCompleted)}
              className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors mb-3"
            >
              {showCompleted ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
              Completed Today ({completedTasks.length})
            </button>

            <AnimatePresence>
              {showCompleted && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2 overflow-hidden"
                >
                  {completedTasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-3 rounded-xl bg-muted/20 border border-border/50">
                      <div className="flex items-center gap-2.5">
                        <div className="h-7 w-7 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                          <Check className="h-3.5 w-3.5 text-emerald-600" />
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground line-through">{task.contact_name}</span>
                          <span className="text-xs text-muted-foreground ml-2">· {task.contact_company}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[10px] text-muted-foreground">
                        {task.task_type === "connection_request" ? "Connected" : "DM Sent"}
                      </Badge>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}
