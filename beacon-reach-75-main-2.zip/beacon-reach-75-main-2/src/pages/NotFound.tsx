import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Zap, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/30 px-4">
      <div className="text-center max-w-md">
        {/* Illustration */}
        <div className="inline-flex items-center justify-center h-20 w-20 rounded-3xl bg-primary/10 mb-6">
          <span className="text-4xl">🔍</span>
        </div>
        <h1 className="text-6xl font-extrabold text-foreground tracking-tight mb-2">404</h1>
        <h2 className="text-lg font-semibold text-foreground mb-2">Page not found</h2>
        <p className="text-sm text-muted-foreground mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Button onClick={() => navigate("/")} size="lg" className="gap-2 shadow-lg shadow-primary/20">
          <ArrowLeft className="h-4 w-4" />
          Go to Dashboard
        </Button>
        <div className="mt-12 flex items-center justify-center gap-2 text-muted-foreground/50">
          <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/10">
            <Zap className="h-3 w-3 text-primary/50" />
          </div>
          <span className="text-[11px]">Office Beacon</span>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
