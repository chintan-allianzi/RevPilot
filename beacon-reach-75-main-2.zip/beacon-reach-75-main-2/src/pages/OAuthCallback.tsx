import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function OAuthCallback() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [status, setStatus] = useState("Processing...");

  useEffect(() => {
    const url = new URL(window.location.href);
    const code = url.searchParams.get("code");
    const state = url.searchParams.get("state");
    const error = url.searchParams.get("error");

    if (error) {
      toast.error("Google sign-in was cancelled or failed: " + error);
      navigate("/settings", { replace: true });
      return;
    }

    if (!code) {
      toast.error("No authorization code received");
      navigate("/settings", { replace: true });
      return;
    }

    // Validate state
    const savedState = sessionStorage.getItem("gmail_oauth_state");
    if (state && savedState && state !== savedState) {
      toast.error("OAuth state mismatch. Please try again.");
      navigate("/settings", { replace: true });
      return;
    }
    sessionStorage.removeItem("gmail_oauth_state");

    if (!user?.id) {
      // Wait for auth to load
      return;
    }

    // Exchange code for tokens via edge function
    (async () => {
      setStatus("Connecting your Gmail account...");
      try {
        const redirectUri = window.location.origin + "/oauth/callback";
        const { data, error: invokeError } = await supabase.functions.invoke("gmail-oauth", {
          body: {
            action: "connect",
            code,
            redirect_uri: redirectUri,
            user_id: user.id,
          },
        });

        if (invokeError || !data?.success) {
          toast.error("Failed to connect Gmail: " + (data?.error || invokeError?.message || "Unknown error"));
        } else {
          toast.success(`Gmail connected: ${data.email}`);
        }
      } catch (e: any) {
        toast.error("Failed to connect Gmail: " + e.message);
      }

      navigate("/settings", { replace: true });
    })();
  }, [user?.id]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-4">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">{status}</p>
    </div>
  );
}
