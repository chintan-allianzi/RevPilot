import { useEffect, useState, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { triggerNurtureSequences, cancelSkippedNurtureEntries } from "@/lib/nurture-utils";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  DragDropContext,
  Droppable,
  Draggable,
  type DropResult,
} from "@hello-pangea/dnd";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Briefcase,
  Plus,
  ChevronDown,
  ChevronRight,
  Calendar,
  User,
  Activity,
  DollarSign,
  Clock,
  TrendingUp,
  Trophy,
  LayoutGrid,
  List,
  Download,
  Filter,
  ArrowUpDown,
  ChevronUp,
  UserPlus,
  MoveRight,
  Search,
  CheckCircle2,
  XCircle,
} from "lucide-react";

interface LeadStage {
  id: string;
  stage_key: string;
  stage_name: string;
  stage_order: number;
  stage_type: string;
}

interface Deal {
  id: string;
  deal_name: string;
  deal_value: number | null;
  stage_id: string;
  contact_id: string | null;
  company_id: string | null;
  vertical_id: string | null;
  campaign_id: string | null;
  assigned_to: string | null;
  expected_close_date: string | null;
  lost_reason: string | null;
  won_date: string | null;
  created_at: string;
  updated_at: string;
  contact_name?: string;
  company_name?: string;
  vertical_name?: string;
  assigned_name?: string;
  last_stage_change?: string;
  last_activity_date?: string;
}

interface Profile {
  id: string;
  full_name: string;
}

interface Vertical {
  id: string;
  name: string;
}

type SortKey = "deal_name" | "contact_name" | "company_name" | "vertical_name" | "stage" | "deal_value" | "assigned_name" | "days" | "expected_close_date" | "created_at" | "last_activity_date";
type SortDir = "asc" | "desc";

const STAGE_COLORS: Record<string, string> = {
  new_lead: "bg-muted text-muted-foreground",
  mql: "bg-blue-100 text-blue-800",
  sal: "bg-indigo-100 text-indigo-800",
  meeting_scheduled: "bg-purple-100 text-purple-800",
  meeting_completed: "bg-violet-100 text-violet-800",
  sql: "bg-amber-100 text-amber-800",
  proposal_sent: "bg-orange-100 text-orange-800",
  negotiation: "bg-cyan-100 text-cyan-800",
  closed_won: "bg-emerald-100 text-emerald-800",
  closed_lost: "bg-red-100 text-red-800",
};

const COLUMN_BG: Record<string, string> = {
  lead: "bg-blue-50/40 dark:bg-blue-950/10",
  opportunity: "bg-purple-50/40 dark:bg-purple-950/10",
  closed: "bg-muted/30",
};

const CARD_BORDER_LEFT: Record<string, string> = {
  lead: "border-l-blue-400",
  opportunity: "border-l-purple-400",
  closed: "border-l-muted-foreground/30",
};

const STAT_ACCENT: Record<string, string> = {
  green: "border-l-emerald-500",
  blue: "border-l-blue-500",
  orange: "border-l-amber-500",
  purple: "border-l-purple-500",
};

export default function Pipeline() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stages, setStages] = useState<LeadStage[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [verticals, setVerticals] = useState<Vertical[]>([]);
  const [loading, setLoading] = useState(true);

  // View toggle
  const [viewMode, setViewMode] = useState<"board" | "list">("board");

  // Basic filters (shared)
  const [searchQuery, setSearchQuery] = useState("");

  // Advanced filters
  const [filterStages, setFilterStages] = useState<string[]>([]);
  const [filterBdms, setFilterBdms] = useState<string[]>([]);
  const [filterVerticals, setFilterVerticals] = useState<string[]>([]);
  const [filterValueMin, setFilterValueMin] = useState("");
  const [filterValueMax, setFilterValueMax] = useState("");
  const [filterCreatedFrom, setFilterCreatedFrom] = useState("");
  const [filterCreatedTo, setFilterCreatedTo] = useState("");
  const [filterCloseFrom, setFilterCloseFrom] = useState("");
  const [filterCloseTo, setFilterCloseTo] = useState("");
  const [filterStale, setFilterStale] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Sorting (list view)
  const [sortKey, setSortKey] = useState<SortKey>("created_at");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  // Bulk selection (list view)
  const [selectedDeals, setSelectedDeals] = useState<Set<string>>(new Set());
  const [bulkActionDialog, setBulkActionDialog] = useState<"reassign" | "move" | null>(null);
  const [bulkTargetBdm, setBulkTargetBdm] = useState("");
  const [bulkTargetStage, setBulkTargetStage] = useState("");

  // Closed sections (board)
  const [showClosedWon, setShowClosedWon] = useState(false);
  const [showClosedLost, setShowClosedLost] = useState(false);

  // Lost reason dialog
  const [lostReasonDialog, setLostReasonDialog] = useState(false);
  const [pendingLostDeal, setPendingLostDeal] = useState<{ dealId: string; stageId: string } | null>(null);
  const [lostReason, setLostReason] = useState("");

  // Create deal dialog
  const [createDealOpen, setCreateDealOpen] = useState(false);
  const [newDealName, setNewDealName] = useState("");
  const [newDealValue, setNewDealValue] = useState("");
  const [newDealStage, setNewDealStage] = useState("");
  const [newDealContact, setNewDealContact] = useState("");
  const [contactSearch, setContactSearch] = useState("");
  const [contactResults, setContactResults] = useState<any[]>([]);
  const [creating, setCreating] = useState(false);

  // Stage history cache
  const [stageChangeDates, setStageChangeDates] = useState<Record<string, string>>({});
  const [activityCounts, setActivityCounts] = useState<Record<string, number>>({});
  const [lastActivityDates, setLastActivityDates] = useState<Record<string, string>>({});

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    await Promise.all([loadStages(), loadDeals(), loadProfiles(), loadVerticals()]);
    setLoading(false);
  };

  const loadStages = async () => {
    const { data } = await supabase
      .from("lead_stages")
      .select("id, stage_key, stage_name, stage_order, stage_type")
      .order("stage_order");
    setStages((data as LeadStage[]) || []);
  };

  const loadDeals = async () => {
    const { data } = await supabase.from("deals").select("*").order("created_at", { ascending: false });
    if (!data) { setDeals([]); return; }

    const contactIds = [...new Set(data.map((d) => d.contact_id).filter(Boolean))];
    const companyIds = [...new Set(data.map((d) => d.company_id).filter(Boolean))];
    const verticalIds = [...new Set(data.map((d) => d.vertical_id).filter(Boolean))];
    const assignedIds = [...new Set(data.map((d) => d.assigned_to).filter(Boolean))];
    const dealIds = data.map((d) => d.id);

    const [contactsRes, companiesRes, verticalsRes, profilesRes, historyRes, activitiesRes] = await Promise.all([
      contactIds.length > 0 ? supabase.from("saved_contacts").select("id, first_name, last_name").in("id", contactIds) : { data: [] },
      companyIds.length > 0 ? supabase.from("saved_companies").select("id, name").in("id", companyIds) : { data: [] },
      verticalIds.length > 0 ? supabase.from("verticals").select("id, name").in("id", verticalIds) : { data: [] },
      assignedIds.length > 0 ? supabase.from("profiles").select("id, full_name").in("id", assignedIds) : { data: [] },
      dealIds.length > 0 ? supabase.from("deal_stage_history").select("deal_id, changed_at").in("deal_id", dealIds).order("changed_at", { ascending: false }) : { data: [] },
      dealIds.length > 0 ? supabase.from("deal_activities").select("deal_id, activity_date").in("deal_id", dealIds).order("activity_date", { ascending: false }) : { data: [] },
    ]);

    const contactMap = new Map((contactsRes.data || []).map((c: any) => [c.id, `${c.first_name || ""} ${c.last_name || ""}`.trim()]));
    const companyMap = new Map((companiesRes.data || []).map((c: any) => [c.id, c.name]));
    const vertMap = new Map((verticalsRes.data || []).map((v: any) => [v.id, v.name]));
    const profMap = new Map((profilesRes.data || []).map((p: any) => [p.id, p.full_name]));

    const stDates: Record<string, string> = {};
    for (const h of (historyRes.data || []) as any[]) {
      if (!stDates[h.deal_id]) stDates[h.deal_id] = h.changed_at;
    }
    setStageChangeDates(stDates);

    const aCounts: Record<string, number> = {};
    const lastAct: Record<string, string> = {};
    for (const a of (activitiesRes.data || []) as any[]) {
      aCounts[a.deal_id] = (aCounts[a.deal_id] || 0) + 1;
      if (!lastAct[a.deal_id]) lastAct[a.deal_id] = a.activity_date;
    }
    setActivityCounts(aCounts);
    setLastActivityDates(lastAct);

    setDeals(data.map((d) => ({
      ...d,
      contact_name: contactMap.get(d.contact_id!) || "Unknown",
      company_name: companyMap.get(d.company_id!) || "",
      vertical_name: vertMap.get(d.vertical_id!) || "",
      assigned_name: profMap.get(d.assigned_to!) || "",
      last_activity_date: lastAct[d.id] || "",
    })));
  };

  const loadProfiles = async () => {
    const { data } = await supabase.from("profiles").select("id, full_name").eq("is_active", true);
    setProfiles((data as Profile[]) || []);
  };

  const loadVerticals = async () => {
    const { data } = await supabase.from("verticals").select("id, name").order("name");
    setVerticals((data as Vertical[]) || []);
  };

  // Advanced filtering
  const filteredDeals = useMemo(() => {
    return deals.filter((d) => {
      if (filterStages.length > 0 && !filterStages.includes(d.stage_id)) return false;
      if (filterBdms.length > 0 && (!d.assigned_to || !filterBdms.includes(d.assigned_to))) return false;
      if (filterVerticals.length > 0 && (!d.vertical_id || !filterVerticals.includes(d.vertical_id))) return false;

      if (filterValueMin && (d.deal_value || 0) < parseFloat(filterValueMin)) return false;
      if (filterValueMax && (d.deal_value || 0) > parseFloat(filterValueMax)) return false;

      if (filterCreatedFrom && d.created_at < filterCreatedFrom) return false;
      if (filterCreatedTo && d.created_at > filterCreatedTo + "T23:59:59") return false;

      if (filterCloseFrom && (!d.expected_close_date || d.expected_close_date < filterCloseFrom)) return false;
      if (filterCloseTo && (!d.expected_close_date || d.expected_close_date > filterCloseTo)) return false;

      if (filterStale) {
        const lastAct = lastActivityDates[d.id];
        if (lastAct) {
          const daysSince = Math.floor((Date.now() - new Date(lastAct).getTime()) / 86400000);
          if (daysSince < 7) return false;
        }
      }

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (
          !(d.contact_name || "").toLowerCase().includes(q) &&
          !(d.company_name || "").toLowerCase().includes(q) &&
          !(d.deal_name || "").toLowerCase().includes(q)
        ) return false;
      }
      return true;
    });
  }, [deals, filterStages, filterBdms, filterVerticals, filterValueMin, filterValueMax, filterCreatedFrom, filterCreatedTo, filterCloseFrom, filterCloseTo, filterStale, searchQuery, lastActivityDates]);

  // Sorting for list view
  const sortedDeals = useMemo(() => {
    const sorted = [...filteredDeals];
    sorted.sort((a, b) => {
      let aVal: any, bVal: any;
      switch (sortKey) {
        case "deal_name": aVal = a.deal_name; bVal = b.deal_name; break;
        case "contact_name": aVal = a.contact_name || ""; bVal = b.contact_name || ""; break;
        case "company_name": aVal = a.company_name || ""; bVal = b.company_name || ""; break;
        case "vertical_name": aVal = a.vertical_name || ""; bVal = b.vertical_name || ""; break;
        case "stage": {
          const sa = stages.find(s => s.id === a.stage_id);
          const sb = stages.find(s => s.id === b.stage_id);
          aVal = sa?.stage_order || 0; bVal = sb?.stage_order || 0; break;
        }
        case "deal_value": aVal = a.deal_value || 0; bVal = b.deal_value || 0; break;
        case "assigned_name": aVal = a.assigned_name || ""; bVal = b.assigned_name || ""; break;
        case "days": aVal = daysInStage(a.id); bVal = daysInStage(b.id); break;
        case "expected_close_date": aVal = a.expected_close_date || ""; bVal = b.expected_close_date || ""; break;
        case "created_at": aVal = a.created_at; bVal = b.created_at; break;
        case "last_activity_date": aVal = a.last_activity_date || ""; bVal = b.last_activity_date || ""; break;
        default: aVal = a.created_at; bVal = b.created_at;
      }
      if (typeof aVal === "string") {
        const cmp = aVal.localeCompare(bVal);
        return sortDir === "asc" ? cmp : -cmp;
      }
      return sortDir === "asc" ? aVal - bVal : bVal - aVal;
    });
    return sorted;
  }, [filteredDeals, sortKey, sortDir, stages]);

  const boardStages = useMemo(() => stages.filter((s) => s.stage_type !== "closed"), [stages]);
  const closedWonStage = stages.find((s) => s.stage_key === "closed_won");
  const closedLostStage = stages.find((s) => s.stage_key === "closed_lost");

  const dealsByStage = useMemo(() => {
    const map: Record<string, Deal[]> = {};
    for (const s of stages) map[s.id] = [];
    for (const d of filteredDeals) {
      if (map[d.stage_id]) map[d.stage_id].push(d);
    }
    return map;
  }, [filteredDeals, stages]);

  const daysInStage = useCallback((dealId: string) => {
    const changeDate = stageChangeDates[dealId];
    if (!changeDate) return 0;
    return Math.floor((Date.now() - new Date(changeDate).getTime()) / (1000 * 60 * 60 * 24));
  }, [stageChangeDates]);

  // Summary stats
  const activeDeals = filteredDeals.filter((d) => {
    const s = stages.find((st) => st.id === d.stage_id);
    return s && s.stage_type !== "closed";
  });
  const totalPipelineValue = activeDeals.reduce((sum, d) => sum + (d.deal_value || 0), 0);
  const wonDeals = filteredDeals.filter((d) => {
    const s = stages.find((st) => st.id === d.stage_id);
    return s?.stage_key === "closed_won";
  });
  const lostDeals = filteredDeals.filter((d) => {
    const s = stages.find((st) => st.id === d.stage_id);
    return s?.stage_key === "closed_lost";
  });
  const totalClosed = wonDeals.length + lostDeals.length;
  const conversionRate = totalClosed > 0 ? Math.round((wonDeals.length / totalClosed) * 100) : 0;
  const now = new Date();
  const thisMonth = (d: Deal) => d.won_date && new Date(d.won_date).getMonth() === now.getMonth() && new Date(d.won_date).getFullYear() === now.getFullYear();
  const dealsWonThisMonth = wonDeals.filter(thisMonth);
  const revenueWonThisMonth = dealsWonThisMonth.reduce((s, d) => s + (d.deal_value || 0), 0);
  const avgDays = activeDeals.length > 0
    ? Math.round(activeDeals.reduce((s, d) => s + Math.floor((Date.now() - new Date(d.created_at).getTime()) / 86400000), 0) / activeDeals.length)
    : 0;

  // Drag and drop (board only)
  const handleDragEnd = async (result: DropResult) => {
    if (!result.destination) return;
    const dealId = result.draggableId;
    const newStageId = result.destination.droppableId;
    const deal = deals.find((d) => d.id === dealId);
    if (!deal || deal.stage_id === newStageId) return;

    const newStage = stages.find((s) => s.id === newStageId);
    if (!newStage) return;

    if (newStage.stage_key === "closed_lost") {
      setPendingLostDeal({ dealId, stageId: newStageId });
      setLostReason("");
      setLostReasonDialog(true);
      return;
    }

    await moveDealToStage(dealId, deal.stage_id, newStageId, newStage);
  };

  const moveDealToStage = async (dealId: string, fromStageId: string, toStageId: string, toStage: LeadStage, extraUpdates: { lost_reason?: string } = {}) => {
    const lastChange = stageChangeDates[dealId];
    const timeInPrev = lastChange
      ? Math.round((Date.now() - new Date(lastChange).getTime()) / 3600000 * 10) / 10
      : null;

    const updates: { stage_id: string; won_date?: string; lost_reason?: string } = { stage_id: toStageId, ...extraUpdates };
    if (toStage.stage_key === "closed_won") updates.won_date = new Date().toISOString().split("T")[0];

    await supabase.from("deals").update(updates).eq("id", dealId);
    await supabase.from("deal_stage_history").insert({
      deal_id: dealId,
      from_stage_id: fromStageId,
      to_stage_id: toStageId,
      changed_by: user?.id,
      time_in_previous_stage_hours: timeInPrev,
    });
    await supabase.from("deal_activities").insert({
      deal_id: dealId,
      activity_type: "stage_change",
      subject: `Moved to ${toStage.stage_name}`,
      created_by: user?.id,
    });

    const deal = deals.find((d) => d.id === dealId);
    const isClosedLost = toStage.stage_key === "closed_lost";
    await triggerNurtureSequences(dealId, toStageId, {
      contact_id: deal?.contact_id || null,
      assigned_to: deal?.assigned_to || null,
      vertical_id: deal?.vertical_id || null,
    }, isClosedLost);

    if (!isClosedLost && deal) {
      const fromStage = stages.find((s) => s.id === fromStageId);
      const toStageObj = stages.find((s) => s.id === toStageId);
      if (fromStage && toStageObj && toStageObj.stage_order > fromStage.stage_order + 1) {
        await cancelSkippedNurtureEntries(dealId, fromStage.stage_order, toStageObj.stage_order, stages);
      }
    }

    toast.success(`Deal moved to ${toStage.stage_name}`);
    loadDeals();
  };

  const handleConfirmLost = async () => {
    if (!pendingLostDeal || !lostReason.trim()) {
      toast.error("Please enter a reason");
      return;
    }
    const deal = deals.find((d) => d.id === pendingLostDeal.dealId);
    if (!deal) return;
    const stage = stages.find((s) => s.id === pendingLostDeal.stageId)!;
    await moveDealToStage(deal.id, deal.stage_id, pendingLostDeal.stageId, stage, { lost_reason: lostReason });
    setLostReasonDialog(false);
    setPendingLostDeal(null);
  };

  // Create deal
  const searchContacts = async (q: string) => {
    setContactSearch(q);
    if (q.length < 2) { setContactResults([]); return; }
    const { data } = await supabase
      .from("saved_contacts")
      .select("id, first_name, last_name, email, company_id")
      .or(`first_name.ilike.%${q}%,last_name.ilike.%${q}%,email.ilike.%${q}%`)
      .limit(10);
    setContactResults(data || []);
  };

  const handleCreateDeal = async () => {
    if (!newDealName.trim() || !newDealStage || !newDealContact) {
      toast.error("Fill in required fields");
      return;
    }
    setCreating(true);
    const contact = contactResults.find((c) => c.id === newDealContact);
    let companyId = contact?.company_id || null;
    let verticalId: string | null = null;

    if (companyId) {
      const { data: comp } = await supabase.from("saved_companies").select("vertical_id").eq("id", companyId).maybeSingle();
      verticalId = comp?.vertical_id || null;
    }

    const { data: deal, error } = await supabase.from("deals").insert({
      deal_name: newDealName,
      deal_value: newDealValue ? parseFloat(newDealValue) : null,
      stage_id: newDealStage,
      contact_id: newDealContact,
      company_id: companyId,
      vertical_id: verticalId,
      assigned_to: user?.id,
    }).select("id").single();

    if (error || !deal) {
      toast.error("Failed to create deal");
      setCreating(false);
      return;
    }

    await supabase.from("deal_stage_history").insert({
      deal_id: deal.id,
      from_stage_id: null,
      to_stage_id: newDealStage,
      changed_by: user?.id,
    });

    toast.success("Deal created");
    setCreateDealOpen(false);
    setNewDealName("");
    setNewDealValue("");
    setNewDealContact("");
    setContactSearch("");
    setCreating(false);
    loadDeals();
  };

  const openCreateDealForStage = (stageId: string) => {
    setNewDealStage(stageId);
    setNewDealName("");
    setNewDealValue("");
    setNewDealContact("");
    setContactSearch("");
    setContactResults([]);
    setCreateDealOpen(true);
  };

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val.toFixed(0)}`;
  };

  // Sort handler
  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const SortHeader = ({ label, sortKeyVal, className }: { label: string; sortKeyVal: SortKey; className?: string }) => (
    <th
      className={`text-left py-2 px-2 font-medium text-muted-foreground text-xs cursor-pointer hover:text-foreground select-none ${className || ""}`}
      onClick={() => handleSort(sortKeyVal)}
    >
      <div className="flex items-center gap-1">
        {label}
        {sortKey === sortKeyVal ? (
          sortDir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
        ) : (
          <ArrowUpDown className="h-3 w-3 opacity-30" />
        )}
      </div>
    </th>
  );

  // Bulk actions
  const toggleSelectAll = () => {
    if (selectedDeals.size === sortedDeals.length) {
      setSelectedDeals(new Set());
    } else {
      setSelectedDeals(new Set(sortedDeals.map(d => d.id)));
    }
  };

  const toggleSelectDeal = (dealId: string) => {
    const next = new Set(selectedDeals);
    if (next.has(dealId)) next.delete(dealId);
    else next.add(dealId);
    setSelectedDeals(next);
  };

  const handleBulkReassign = async () => {
    if (!bulkTargetBdm) { toast.error("Select a BDM"); return; }
    for (const dealId of selectedDeals) {
      await supabase.from("deals").update({ assigned_to: bulkTargetBdm }).eq("id", dealId);
    }
    toast.success(`${selectedDeals.size} deals reassigned`);
    setSelectedDeals(new Set());
    setBulkActionDialog(null);
    setBulkTargetBdm("");
    loadDeals();
  };

  const handleBulkMove = async () => {
    if (!bulkTargetStage) { toast.error("Select a stage"); return; }
    const targetStage = stages.find(s => s.id === bulkTargetStage);
    if (!targetStage) return;

    for (const dealId of selectedDeals) {
      const deal = deals.find(d => d.id === dealId);
      if (!deal || deal.stage_id === bulkTargetStage) continue;
      await moveDealToStage(dealId, deal.stage_id, bulkTargetStage, targetStage);
    }
    toast.success(`${selectedDeals.size} deals moved`);
    setSelectedDeals(new Set());
    setBulkActionDialog(null);
    setBulkTargetStage("");
  };

  // CSV Export
  const exportCSV = () => {
    const dealsToExport = selectedDeals.size > 0
      ? sortedDeals.filter(d => selectedDeals.has(d.id))
      : sortedDeals;

    const stageMap = new Map(stages.map(s => [s.id, s.stage_name]));

    const headers = ["Deal Name", "Contact", "Company", "Vertical", "Stage", "Deal Value", "Assigned BDM", "Days in Stage", "Expected Close", "Created", "Last Activity", "Stage History"];
    const rows = dealsToExport.map(d => {
      const stageHistorySummary = stageMap.get(d.stage_id) || "";
      return [
        d.deal_name,
        d.contact_name || "",
        d.company_name || "",
        d.vertical_name || "",
        stageMap.get(d.stage_id) || "",
        d.deal_value?.toString() || "",
        d.assigned_name || "",
        daysInStage(d.id).toString(),
        d.expected_close_date || "",
        new Date(d.created_at).toLocaleDateString(),
        d.last_activity_date ? new Date(d.last_activity_date).toLocaleDateString() : "",
        stageHistorySummary,
      ];
    });

    const csvContent = [
      headers.join(","),
      ...rows.map(r => r.map(cell => `"${(cell || "").replace(/"/g, '""')}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pipeline-deals-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`Exported ${dealsToExport.length} deals`);
  };

  // Multi-select filter toggle helper
  const toggleFilter = (arr: string[], setArr: (v: string[]) => void, val: string) => {
    setArr(arr.includes(val) ? arr.filter(v => v !== val) : [...arr, val]);
  };

  const activeFilterCount = [
    filterStages.length > 0,
    filterBdms.length > 0,
    filterVerticals.length > 0,
    !!filterValueMin || !!filterValueMax,
    !!filterCreatedFrom || !!filterCreatedTo,
    !!filterCloseFrom || !!filterCloseTo,
    filterStale,
  ].filter(Boolean).length;

  const clearFilters = () => {
    setFilterStages([]);
    setFilterBdms([]);
    setFilterVerticals([]);
    setFilterValueMin("");
    setFilterValueMax("");
    setFilterCreatedFrom("");
    setFilterCreatedTo("");
    setFilterCloseFrom("");
    setFilterCloseTo("");
    setFilterStale(false);
  };

  const getDaysColor = (days: number) => {
    if (days < 7) return "text-emerald-600";
    if (days < 14) return "text-amber-600";
    return "text-destructive";
  };

  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Pipeline</h1>
          <p className="text-sm text-muted-foreground">Manage deals through your sales funnel</p>
        </div>
        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex bg-muted rounded-lg p-0.5">
            <button
              onClick={() => setViewMode("board")}
              className={`px-3 py-1.5 text-xs flex items-center gap-1.5 rounded-md transition-all ${viewMode === "board" ? "bg-background text-foreground shadow-sm font-medium" : "text-muted-foreground hover:text-foreground"}`}
            >
              <LayoutGrid className="h-3.5 w-3.5" /> Board
            </button>
            <button
              onClick={() => { setViewMode("list"); setSelectedDeals(new Set()); }}
              className={`px-3 py-1.5 text-xs flex items-center gap-1.5 rounded-md transition-all ${viewMode === "list" ? "bg-background text-foreground shadow-sm font-medium" : "text-muted-foreground hover:text-foreground"}`}
            >
              <List className="h-3.5 w-3.5" /> List
            </button>
          </div>
          <Button onClick={() => { setCreateDealOpen(true); const mql = stages.find(s => s.stage_key === 'mql'); if(mql) setNewDealStage(mql.id); }}>
            <Plus className="h-4 w-4 mr-1.5" /> Create Deal
          </Button>
        </div>
      </div>

      {/* Summary stats — single-row card */}
      <div className="bg-card border border-border rounded-xl p-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { label: "Active Deals", value: activeDeals.length, icon: Briefcase, accent: "blue" },
            { label: "Pipeline Value", value: formatCurrency(totalPipelineValue), icon: DollarSign, accent: "green" },
            { label: "Avg Days", value: avgDays, icon: Clock, accent: "orange" },
            { label: "Conversion", value: `${conversionRate}%`, icon: TrendingUp, accent: "purple" },
            { label: "Won (month)", value: dealsWonThisMonth.length, icon: Trophy, accent: "green" },
            { label: "Revenue (month)", value: formatCurrency(revenueWonThisMonth), icon: DollarSign, accent: "green" },
          ].map((stat) => (
            <div key={stat.label} className={`border-l-[3px] ${STAT_ACCENT[stat.accent]} pl-3 py-1`}>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">{stat.label}</span>
                <stat.icon className="h-3.5 w-3.5 text-muted-foreground/50" />
              </div>
              <p className="text-xl font-bold text-foreground mt-0.5">{stat.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Filters bar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Search deals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-56 h-8 text-sm pl-8"
          />
        </div>

        <Popover open={showAdvancedFilters} onOpenChange={setShowAdvancedFilters}>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
              <Filter className="h-3.5 w-3.5" />
              Filters
              {activeFilterCount > 0 && (
                <Badge className="ml-1 h-4 w-4 p-0 flex items-center justify-center text-[9px]">{activeFilterCount}</Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-96 p-4 max-h-[70vh] overflow-y-auto" align="start">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold">Advanced Filters</h4>
                {activeFilterCount > 0 && (
                  <Button variant="ghost" size="sm" className="text-xs h-6" onClick={clearFilters}>Clear all</Button>
                )}
              </div>

              <div>
                <Label className="text-xs">Stage</Label>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {stages.map(s => (
                    <button
                      key={s.id}
                      onClick={() => toggleFilter(filterStages, setFilterStages, s.id)}
                      className={`text-[10px] px-2 py-1 rounded-md border transition-colors ${
                        filterStages.includes(s.id) ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                      }`}
                    >
                      {s.stage_name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs">Assigned BDM</Label>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {profiles.map(p => (
                    <button
                      key={p.id}
                      onClick={() => toggleFilter(filterBdms, setFilterBdms, p.id)}
                      className={`text-[10px] px-2 py-1 rounded-md border transition-colors ${
                        filterBdms.includes(p.id) ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                      }`}
                    >
                      {p.full_name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs">Vertical</Label>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {verticals.map(v => (
                    <button
                      key={v.id}
                      onClick={() => toggleFilter(filterVerticals, setFilterVerticals, v.id)}
                      className={`text-[10px] px-2 py-1 rounded-md border transition-colors ${
                        filterVerticals.includes(v.id) ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"
                      }`}
                    >
                      {v.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label className="text-xs">Deal Value Range</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input type="number" placeholder="Min" value={filterValueMin} onChange={e => setFilterValueMin(e.target.value)} className="h-7 text-xs" />
                  <span className="text-xs text-muted-foreground">—</span>
                  <Input type="number" placeholder="Max" value={filterValueMax} onChange={e => setFilterValueMax(e.target.value)} className="h-7 text-xs" />
                </div>
              </div>

              <div>
                <Label className="text-xs">Created Date Range</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input type="date" value={filterCreatedFrom} onChange={e => setFilterCreatedFrom(e.target.value)} className="h-7 text-xs" />
                  <span className="text-xs text-muted-foreground">—</span>
                  <Input type="date" value={filterCreatedTo} onChange={e => setFilterCreatedTo(e.target.value)} className="h-7 text-xs" />
                </div>
              </div>

              <div>
                <Label className="text-xs">Expected Close Date Range</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input type="date" value={filterCloseFrom} onChange={e => setFilterCloseFrom(e.target.value)} className="h-7 text-xs" />
                  <span className="text-xs text-muted-foreground">—</span>
                  <Input type="date" value={filterCloseTo} onChange={e => setFilterCloseTo(e.target.value)} className="h-7 text-xs" />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox checked={filterStale} onCheckedChange={(v) => setFilterStale(!!v)} id="stale" />
                <label htmlFor="stale" className="text-xs cursor-pointer">Stale deals only (no activity in 7+ days)</label>
              </div>
            </div>
          </PopoverContent>
        </Popover>

        {viewMode === "list" && (
          <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs ml-auto" onClick={exportCSV}>
            <Download className="h-3.5 w-3.5" /> Export CSV {selectedDeals.size > 0 && `(${selectedDeals.size})`}
          </Button>
        )}
      </div>

      {/* Bulk actions bar (list view) */}
      {viewMode === "list" && selectedDeals.size > 0 && (
        <div className="flex items-center gap-3 bg-primary/5 border border-primary/20 rounded-lg px-4 py-2">
          <span className="text-sm font-medium">{selectedDeals.size} selected</span>
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => { setBulkActionDialog("reassign"); setBulkTargetBdm(""); }}>
            <UserPlus className="h-3 w-3" /> Reassign
          </Button>
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => { setBulkActionDialog("move"); setBulkTargetStage(""); }}>
            <MoveRight className="h-3 w-3" /> Move Stage
          </Button>
          <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={exportCSV}>
            <Download className="h-3 w-3" /> Export Selected
          </Button>
          <Button variant="ghost" size="sm" className="h-7 text-xs ml-auto" onClick={() => setSelectedDeals(new Set())}>
            Clear
          </Button>
        </div>
      )}

      {/* ===================== LIST VIEW ===================== */}
      {viewMode === "list" ? (
        sortedDeals.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-border rounded-xl">
            <Briefcase className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No deals match your filters.</p>
          </div>
        ) : (
          <div className="border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className="py-2 px-2 w-10">
                      <Checkbox
                        checked={selectedDeals.size === sortedDeals.length && sortedDeals.length > 0}
                        onCheckedChange={toggleSelectAll}
                      />
                    </th>
                    <SortHeader label="Deal Name" sortKeyVal="deal_name" />
                    <SortHeader label="Contact" sortKeyVal="contact_name" />
                    <SortHeader label="Company" sortKeyVal="company_name" />
                    <SortHeader label="Vertical" sortKeyVal="vertical_name" />
                    <SortHeader label="Stage" sortKeyVal="stage" />
                    <SortHeader label="Value" sortKeyVal="deal_value" />
                    <SortHeader label="BDM" sortKeyVal="assigned_name" />
                    <SortHeader label="Days" sortKeyVal="days" className="text-center" />
                    <SortHeader label="Exp. Close" sortKeyVal="expected_close_date" />
                    <SortHeader label="Created" sortKeyVal="created_at" />
                    <SortHeader label="Last Activity" sortKeyVal="last_activity_date" />
                  </tr>
                </thead>
                <tbody>
                  {sortedDeals.map((deal) => {
                    const stage = stages.find(s => s.id === deal.stage_id);
                    const stageColor = STAGE_COLORS[stage?.stage_key || ""] || "bg-muted text-muted-foreground";
                    const days = daysInStage(deal.id);
                    return (
                      <tr
                        key={deal.id}
                        className="border-b border-border hover:bg-muted/30 cursor-pointer transition-colors"
                        onClick={() => navigate(`/pipeline/${deal.id}`)}
                      >
                        <td className="py-2 px-2" onClick={e => e.stopPropagation()}>
                          <Checkbox
                            checked={selectedDeals.has(deal.id)}
                            onCheckedChange={() => toggleSelectDeal(deal.id)}
                          />
                        </td>
                        <td className="py-2 px-2 font-medium text-xs max-w-[160px] truncate">{deal.deal_name}</td>
                        <td className="py-2 px-2 text-xs max-w-[120px] truncate">{deal.contact_name}</td>
                        <td className="py-2 px-2 text-xs max-w-[120px] truncate text-muted-foreground">{deal.company_name}</td>
                        <td className="py-2 px-2 text-xs">
                          {deal.vertical_name && <Badge variant="outline" className="text-[9px]">{deal.vertical_name}</Badge>}
                        </td>
                        <td className="py-2 px-2">
                          <Badge className={`text-[9px] ${stageColor}`}>{stage?.stage_name || ""}</Badge>
                        </td>
                        <td className="py-2 px-2 text-xs font-medium">
                          {deal.deal_value ? formatCurrency(deal.deal_value) : "—"}
                        </td>
                        <td className="py-2 px-2 text-xs text-muted-foreground max-w-[100px] truncate">{deal.assigned_name}</td>
                        <td className="py-2 px-2 text-xs text-center">
                          <span className={days >= 7 ? "text-destructive font-medium" : "text-muted-foreground"}>{days}d</span>
                        </td>
                        <td className="py-2 px-2 text-xs text-muted-foreground">
                          {deal.expected_close_date ? new Date(deal.expected_close_date).toLocaleDateString() : "—"}
                        </td>
                        <td className="py-2 px-2 text-xs text-muted-foreground">
                          {new Date(deal.created_at).toLocaleDateString()}
                        </td>
                        <td className="py-2 px-2 text-xs text-muted-foreground">
                          {deal.last_activity_date ? new Date(deal.last_activity_date).toLocaleDateString() : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )
      ) : (
        /* ===================== KANBAN BOARD ===================== */
        activeDeals.length === 0 && wonDeals.length === 0 && lostDeals.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-border rounded-xl bg-muted/10">
            <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto mb-4">
              <Briefcase className="h-8 w-8 text-muted-foreground/40" />
            </div>
            <p className="text-base font-medium text-foreground mb-1">No deals in your pipeline yet</p>
            <p className="text-sm text-muted-foreground mb-5 max-w-sm mx-auto">
              Deals are automatically created when leads reply positively to your campaigns, or you can create one manually.
            </p>
            <Button onClick={() => { setCreateDealOpen(true); const mql = stages.find(s => s.stage_key === 'mql'); if(mql) setNewDealStage(mql.id); }}>
              <Plus className="h-4 w-4 mr-1.5" /> Create Deal
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <DragDropContext onDragEnd={handleDragEnd}>
              <div className="flex gap-3 overflow-x-auto pb-4" style={{ minHeight: 420 }}>
                {boardStages.map((stage) => {
                  const stageDeals = dealsByStage[stage.id] || [];
                  const stageValue = stageDeals.reduce((s, d) => s + (d.deal_value || 0), 0);
                  const colBg = COLUMN_BG[stage.stage_type] || COLUMN_BG.lead;
                  const cardBorderColor = CARD_BORDER_LEFT[stage.stage_type] || CARD_BORDER_LEFT.lead;

                  return (
                    <Droppable droppableId={stage.id} key={stage.id}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.droppableProps}
                          className={`flex-shrink-0 w-[270px] rounded-xl border transition-all ${colBg} ${
                            snapshot.isDraggingOver
                              ? "border-primary/40 ring-2 ring-primary/10 border-dashed"
                              : "border-border"
                          }`}
                        >
                          {/* Column header */}
                          <div className="px-3 py-2.5 border-b border-border/60">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-semibold text-foreground">{stage.stage_name}</span>
                                <Badge variant="secondary" className="text-[10px] px-1.5 h-4 font-medium">{stageDeals.length}</Badge>
                              </div>
                              <button
                                onClick={() => openCreateDealForStage(stage.id)}
                                className="h-5 w-5 rounded flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-background/80 transition-colors"
                              >
                                <Plus className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            {stageValue > 0 && (
                              <p className="text-[10px] text-muted-foreground mt-0.5 font-medium">{formatCurrency(stageValue)}</p>
                            )}
                          </div>

                          {/* Cards */}
                          <div className="p-2 space-y-2 min-h-[100px]">
                            {stageDeals.map((deal, idx) => {
                              const days = daysInStage(deal.id);
                              const daysColor = getDaysColor(days);
                              const actCount = activityCounts[deal.id] || 0;

                              return (
                                <Draggable draggableId={deal.id} index={idx} key={deal.id}>
                                  {(prov, snap) => (
                                    <div
                                      ref={prov.innerRef}
                                      {...prov.draggableProps}
                                      {...prov.dragHandleProps}
                                      onClick={() => navigate(`/pipeline/${deal.id}`)}
                                      className={`bg-card border rounded-lg p-3 cursor-pointer transition-all border-l-[3px] ${cardBorderColor} ${
                                        snap.isDragging
                                          ? "shadow-xl ring-2 ring-primary/20 scale-[1.02]"
                                          : "shadow-sm hover:shadow-md border-border"
                                      }`}
                                    >
                                      {/* Top: Contact + Company */}
                                      <div className="flex items-start justify-between gap-1">
                                        <div className="min-w-0">
                                          <p className="text-xs font-semibold text-foreground truncate">{deal.contact_name}</p>
                                          {deal.company_name && (
                                            <p className="text-[10px] text-muted-foreground truncate mt-0.5">{deal.company_name}</p>
                                          )}
                                        </div>
                                      </div>

                                      {/* Middle: Vertical + Value */}
                                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                                        {deal.vertical_name && (
                                          <Badge variant="outline" className="text-[9px] px-1.5 py-0 h-4">{deal.vertical_name}</Badge>
                                        )}
                                        {deal.deal_value != null && deal.deal_value > 0 && (
                                          <span className="text-[10px] font-semibold text-emerald-600">{formatCurrency(deal.deal_value)}</span>
                                        )}
                                      </div>

                                      {/* Bottom: Avatar + Days + Close date */}
                                      <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-border/40">
                                        <div className="flex items-center gap-2">
                                          {deal.assigned_name && (
                                            <div
                                              className="h-5 w-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-[8px] font-bold flex-shrink-0"
                                              title={deal.assigned_name}
                                            >
                                              {getInitials(deal.assigned_name)}
                                            </div>
                                          )}
                                          <span className={`text-[10px] font-medium ${daysColor}`}>
                                            {days}d
                                          </span>
                                          {deal.expected_close_date && (
                                            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                                              <Calendar className="h-2.5 w-2.5" />
                                              {new Date(deal.expected_close_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                            </span>
                                          )}
                                        </div>
                                        {actCount > 0 && (
                                          <div className="flex items-center gap-0.5 text-[10px] text-muted-foreground bg-muted/60 rounded px-1 py-0.5">
                                            <Activity className="h-2.5 w-2.5" />
                                            <span>{actCount}</span>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )}
                                </Draggable>
                              );
                            })}
                            {provided.placeholder}
                          </div>
                        </div>
                      )}
                    </Droppable>
                  );
                })}

                {/* Closed Won drop zone */}
                {closedWonStage && (
                  <Droppable droppableId={closedWonStage.id}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`flex-shrink-0 w-[270px] rounded-xl border transition-all ${
                          snapshot.isDraggingOver ? "bg-emerald-50 border-emerald-300 border-dashed ring-2 ring-emerald-100" : "bg-emerald-50/30 border-border"
                        }`}
                      >
                        <button
                          onClick={() => setShowClosedWon(!showClosedWon)}
                          className="w-full px-3 py-2.5 border-b border-border/60 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            {showClosedWon ? <ChevronDown className="h-3.5 w-3.5 text-emerald-700" /> : <ChevronRight className="h-3.5 w-3.5 text-emerald-700" />}
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                            <span className="text-xs font-semibold text-emerald-700">Closed Won</span>
                          </div>
                          <Badge className="bg-emerald-100 text-emerald-700 text-[10px] px-1.5 h-4 border-0">{(dealsByStage[closedWonStage.id] || []).length}</Badge>
                        </button>
                        <div className="p-2 space-y-2 min-h-[50px]">
                          {showClosedWon && (dealsByStage[closedWonStage.id] || []).map((deal, idx) => (
                            <Draggable draggableId={deal.id} index={idx} key={deal.id}>
                              {(prov) => (
                                <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                                  onClick={() => navigate(`/pipeline/${deal.id}`)}
                                  className="bg-emerald-50/80 border border-emerald-200 rounded-lg p-2.5 cursor-pointer text-xs hover:shadow-sm transition-all">
                                  <div className="flex items-center gap-1.5">
                                    <CheckCircle2 className="h-3 w-3 text-emerald-600 flex-shrink-0" />
                                    <p className="font-medium truncate text-foreground">{deal.contact_name}</p>
                                  </div>
                                  {deal.deal_value != null && <span className="text-emerald-600 text-[10px] font-semibold mt-1 block">{formatCurrency(deal.deal_value)}</span>}
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      </div>
                    )}
                  </Droppable>
                )}

                {/* Closed Lost drop zone */}
                {closedLostStage && (
                  <Droppable droppableId={closedLostStage.id}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`flex-shrink-0 w-[270px] rounded-xl border transition-all ${
                          snapshot.isDraggingOver ? "bg-red-50 border-red-300 border-dashed ring-2 ring-red-100" : "bg-red-50/30 border-border"
                        }`}
                      >
                        <button
                          onClick={() => setShowClosedLost(!showClosedLost)}
                          className="w-full px-3 py-2.5 border-b border-border/60 flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            {showClosedLost ? <ChevronDown className="h-3.5 w-3.5 text-red-700" /> : <ChevronRight className="h-3.5 w-3.5 text-red-700" />}
                            <XCircle className="h-3.5 w-3.5 text-red-500" />
                            <span className="text-xs font-semibold text-red-700">Closed Lost</span>
                          </div>
                          <Badge className="bg-red-100 text-red-700 text-[10px] px-1.5 h-4 border-0">{(dealsByStage[closedLostStage.id] || []).length}</Badge>
                        </button>
                        <div className="p-2 space-y-2 min-h-[50px]">
                          {showClosedLost && (dealsByStage[closedLostStage.id] || []).map((deal, idx) => (
                            <Draggable draggableId={deal.id} index={idx} key={deal.id}>
                              {(prov) => (
                                <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                                  onClick={() => navigate(`/pipeline/${deal.id}`)}
                                  className="bg-red-50/80 border border-red-200 rounded-lg p-2.5 cursor-pointer text-xs hover:shadow-sm transition-all">
                                  <div className="flex items-center gap-1.5">
                                    <XCircle className="h-3 w-3 text-red-500 flex-shrink-0" />
                                    <p className="font-medium truncate text-foreground">{deal.contact_name}</p>
                                  </div>
                                  {deal.lost_reason && <p className="text-[10px] text-red-600 truncate mt-1">{deal.lost_reason}</p>}
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      </div>
                    )}
                  </Droppable>
                )}
              </div>
            </DragDropContext>
          </div>
        )
      )}

      {/* Lost Reason Dialog */}
      <Dialog open={lostReasonDialog} onOpenChange={setLostReasonDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Why was this deal lost?</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <Label>Reason (required)</Label>
            <Input
              value={lostReason}
              onChange={(e) => setLostReason(e.target.value)}
              placeholder="e.g., Budget constraints, chose competitor..."
              className="mt-1"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setLostReasonDialog(false); setPendingLostDeal(null); }}>Cancel</Button>
            <Button variant="destructive" onClick={handleConfirmLost}>Mark Lost</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Deal Dialog */}
      <Dialog open={createDealOpen} onOpenChange={setCreateDealOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create Deal</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>Contact *</Label>
              <Input
                value={contactSearch}
                onChange={(e) => searchContacts(e.target.value)}
                placeholder="Search by name or email..."
                className="mt-1"
              />
              {contactResults.length > 0 && (
                <div className="border border-border rounded-lg mt-1 max-h-32 overflow-y-auto">
                  {contactResults.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        setNewDealContact(c.id);
                        setContactSearch(`${c.first_name || ""} ${c.last_name || ""} (${c.email})`);
                        setContactResults([]);
                        if (!newDealName) setNewDealName(`${c.first_name || ""} ${c.last_name || ""}`.trim());
                      }}
                      className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors"
                    >
                      {c.first_name} {c.last_name} — {c.email}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div>
              <Label>Deal Name *</Label>
              <Input value={newDealName} onChange={(e) => setNewDealName(e.target.value)} className="mt-1" placeholder="Contact — Company — Vertical" />
            </div>
            <div>
              <Label>Stage *</Label>
              <Select value={newDealStage} onValueChange={setNewDealStage}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select stage" /></SelectTrigger>
                <SelectContent>
                  {stages.filter(s => s.stage_type !== "closed").map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.stage_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Deal Value (optional)</Label>
              <Input type="number" value={newDealValue} onChange={(e) => setNewDealValue(e.target.value)} className="mt-1" placeholder="Annual contract value" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDealOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateDeal} disabled={creating}>{creating ? "Creating…" : "Create Deal"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Reassign Dialog */}
      <Dialog open={bulkActionDialog === "reassign"} onOpenChange={(o) => !o && setBulkActionDialog(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Reassign {selectedDeals.size} Deals</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <Label>Assign to BDM</Label>
            <Select value={bulkTargetBdm} onValueChange={setBulkTargetBdm}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select BDM" /></SelectTrigger>
              <SelectContent>
                {profiles.map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkActionDialog(null)}>Cancel</Button>
            <Button onClick={handleBulkReassign}>Reassign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Move Stage Dialog */}
      <Dialog open={bulkActionDialog === "move"} onOpenChange={(o) => !o && setBulkActionDialog(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Move {selectedDeals.size} Deals</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <Label>Move to stage</Label>
            <Select value={bulkTargetStage} onValueChange={setBulkTargetStage}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select stage" /></SelectTrigger>
              <SelectContent>
                {stages.map(s => (
                  <SelectItem key={s.id} value={s.id}>{s.stage_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkActionDialog(null)}>Cancel</Button>
            <Button onClick={handleBulkMove}>Move Deals</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
