import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Key, Users, Ban, Building2, Brain, Sparkles, Diamond, Eye, EyeOff, Loader2, Check, X, AlertTriangle, UserPlus, Copy, Shield, MailX, Mail, Trash2, Plus, ChevronDown, Lock, Star, Database, ArrowUp, ArrowDown, Zap, Search as SearchIcon, Globe, RefreshCw, Info, Briefcase } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useAISettings, AI_MODELS } from "@/contexts/AISettingsContext";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  validateAnthropicKey,
  validateOpenAIKey,
  validateGeminiKey,
} from "@/lib/settings-storage";
import { toast } from "sonner";
import { setAccountAsPrimary } from "@/lib/primary-inbox";
import { testProviderConnection, migrateLegacyKeys, invalidateProviderCache } from "@/lib/data-provider-service";

type AIProvider = "anthropic" | "openai" | "gemini";
type ValidationStatus = "idle" | "validating" | "valid" | "invalid" | "skipped" | "saved";

function ValidationIndicator({ status }: { status: ValidationStatus }) {
  if (status === "idle") return null;
  if (status === "validating") return <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />;
  if (status === "valid") return <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-medium"><Check className="h-3 w-3" />Valid</div>;
  if (status === "invalid") return <div className="flex items-center gap-1 text-destructive text-[10px] font-medium"><X className="h-3 w-3" />Invalid</div>;
  if (status === "skipped") return <div className="flex items-center gap-1 text-amber-600 text-[10px] font-medium"><AlertTriangle className="h-3 w-3" />Not validated</div>;
  if (status === "saved") return <div className="flex items-center gap-1 text-muted-foreground text-[10px] font-medium"><Check className="h-3 w-3" />Saved</div>;
  return null;
}

interface SectionProps {
  icon: React.ElementType;
  title: string;
  subtitle?: string;
  badge?: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
  actions?: React.ReactNode;
}

function SettingsSection({ icon: Icon, title, subtitle, badge, defaultOpen = false, children, actions }: SectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <Card className="overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full px-5 py-4 flex items-center gap-3 text-left hover:bg-muted/30 transition-colors"
      >
        <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
          <Icon className="h-4 w-4 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-foreground">{title}</span>
            {badge && <Badge variant="secondary" className="text-[10px]">{badge}</Badge>}
          </div>
          {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
        </div>
        {actions && <div onClick={e => e.stopPropagation()}>{actions}</div>}
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-1 border-t border-border">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

const CAPABILITY_LABELS: Record<string, string> = {
  company_search: "Company Search",
  company_enrichment: "Company Enrichment",
  contact_search: "Contact Search",
  contact_enrichment: "Contact Enrichment",
  email_lookup: "Email Lookup",
  webhook_enrichment: "Webhook Enrichment",
};

const PROVIDER_TOOLTIPS: Record<string, string> = {
  apollo: "Enables company search, contact search, email lookup, and enrichment directly from the campaign builder.",
  clay: "Enables webhook-based enrichment. Set up Clay tables and connect them to enrich your campaign data. Direct search is not available — Clay processes data through its table interface.",
  seamless_ai: "Enables contact search and email lookup for finding decision makers.",
  zoominfo: "Enables company and contact search, email lookup, and enrichment (requires ZoomInfo API access plan).",
  prospeo: "Prospeo provides 200M+ contacts with verified emails and mobile numbers. Supports company search, people search with 30+ filters, and bulk enrichment.",
  apify: "Apify provides web scraping and automation Actors. Get your API token from console.apify.com → Settings → Integrations.",
};

const APOLLO_MASTER_KEY_GUIDE = `How to create a Master API Key:
1. Log into app.apollo.io
2. Go to Settings → Integrations → API
3. Click 'Create API Key'
4. Enter a name (e.g., 'Office Beacon')
5. Toggle 'Set as master key' ON
6. Click 'Create API Key' and copy it
7. Paste it here and click Save`;

const HEALTH_CONFIG: Record<string, { dot: string; label: string }> = {
  healthy: { dot: "bg-emerald-500", label: "Healthy" },
  degraded: { dot: "bg-amber-500", label: "Degraded" },
  down: { dot: "bg-destructive", label: "Down" },
  unchecked: { dot: "bg-muted-foreground/30", label: "Not checked" },
};

interface ProviderRow {
  id: string;
  provider_key: string;
  provider_name: string;
  provider_type: string[];
  api_key: string | null;
  is_active: boolean;
  priority_order: number;
  health_status: string;
  last_health_check: string | null;
  config: Record<string, any> | null;
}

export default function SettingsPage() {
  const { aiProvider, setAiProvider, aiKeys, setAiKey, aiModel, setAiModel, serviceKeys, setServiceKey, persistAll } = useAISettings();
  const { user } = useAuth();

  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [validationStatus, setValidationStatus] = useState<Record<string, ValidationStatus>>({});

  // Data Providers
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [providerKeys, setProviderKeys] = useState<Record<string, string>>({});
  // apolloOAuth state removed — Apollo uses simple API key auth
  const [testingProvider, setTestingProvider] = useState<string | null>(null);
  const [checkingAll, setCheckingAll] = useState(false);

  const [teamMembers, setTeamMembers] = useState<any[]>([]);
  const [teamRoles, setTeamRoles] = useState<Record<string, string>>({});
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteForm, setInviteForm] = useState({ fullName: "", email: "", role: "bdm" as "admin" | "bdm" });
  const [inviting, setInviting] = useState(false);
  const [tempPassword, setTempPassword] = useState<string | null>(null);

  const [companyName, setCompanyName] = useState("Office Beacon");
  const [companyAddress, setCompanyAddress] = useState("1234 Business Ave, Suite 100, New York, NY 10001");
  const [companyWebsite, setCompanyWebsite] = useState("https://officebeacon.com");
  const [savingCompany, setSavingCompany] = useState(false);

  const [optOuts, setOptOuts] = useState<any[]>([]);
  const [googleAccounts, setGoogleAccounts] = useState<any[]>([]);
  const [connectingGoogle, setConnectingGoogle] = useState(false);

  useEffect(() => {
    loadTeam();
    loadCompanySettings();
    loadOptOuts();
    loadGoogleAccounts();
    loadProviders();
  }, []);

  // ======== Data Providers ========
  const loadProviders = async () => {
    const { data } = await supabase
      .from("data_providers")
      .select("*")
      .order("priority_order", { ascending: true });
    const rows = (data || []) as ProviderRow[];
    setProviders(rows);
    const keys: Record<string, string> = {};
    rows.forEach((p) => { keys[p.provider_key] = p.api_key || ""; });
    setProviderKeys(keys);


    // Migrate legacy keys on first load
    migrateLegacyKeys().then(() => {
      supabase.from("data_providers").select("*").order("priority_order", { ascending: true }).then(({ data: d2 }) => {
        if (d2) {
          const rows2 = d2 as ProviderRow[];
          setProviders(rows2);
          const keys2: Record<string, string> = {};
          rows2.forEach((p) => { keys2[p.provider_key] = p.api_key || ""; });
          setProviderKeys(keys2);


        }
      });
    });
  };

  const updateProviderKey = async (providerKey: string, apiKey: string) => {
    setProviderKeys((prev) => ({ ...prev, [providerKey]: apiKey }));
  };

  const saveProviderKey = async (providerKey: string) => {
    const key = providerKeys[providerKey] || "";
    await supabase
      .from("data_providers")
      .update({ api_key: key || null, updated_at: new Date().toISOString() } as any)
      .eq("provider_key", providerKey);
    invalidateProviderCache();
    toast.success("API key saved");
  };

  const toggleProviderActive = async (providerKey: string, active: boolean) => {
    const key = providerKeys[providerKey];
    if (active && !key) {
      toast.error("Please enter an API key first");
      return;
    }
    await supabase
      .from("data_providers")
      .update({ is_active: active, updated_at: new Date().toISOString() } as any)
      .eq("provider_key", providerKey);
    setProviders((prev) => prev.map((p) => p.provider_key === providerKey ? { ...p, is_active: active } : p));
    invalidateProviderCache();
    toast.success(`${providerKey} ${active ? "activated" : "deactivated"}`);
  };

  const handleTestProvider = async (providerKey: string) => {
    const key = providerKeys[providerKey];
    if (!key) { toast.error("Enter an API key first"); return; }
    setTestingProvider(providerKey);
    try {
      const result = await testProviderConnection(providerKey, key);
      const newStatus = result.ok ? "healthy" : "down";
      await supabase
        .from("data_providers")
        .update({ health_status: newStatus, last_health_check: new Date().toISOString(), updated_at: new Date().toISOString() } as any)
        .eq("provider_key", providerKey);
      setProviders((prev) => prev.map((p) => p.provider_key === providerKey ? { ...p, health_status: newStatus, last_health_check: new Date().toISOString() } : p));
      if (result.ok) {
        toast.success(`${providerKey} connected ✓`);
      } else {
        toast.error(`${providerKey} failed: ${result.message}`);
      }
    } catch {
      toast.error("Connection test failed");
    }
    setTestingProvider(null);
  };

  const handleCheckAll = async () => {
    setCheckingAll(true);
    const activeProviders = providers.filter((p) => p.is_active && providerKeys[p.provider_key]);
    for (const p of activeProviders) {
      await handleTestProvider(p.provider_key);
    }
    setCheckingAll(false);
  };

  const moveProvider = async (providerKey: string, direction: "up" | "down") => {
    const sorted = [...providers].sort((a, b) => a.priority_order - b.priority_order);
    const idx = sorted.findIndex((p) => p.provider_key === providerKey);
    if (direction === "up" && idx <= 0) return;
    if (direction === "down" && idx >= sorted.length - 1) return;
    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    const tempOrder = sorted[idx].priority_order;
    sorted[idx].priority_order = sorted[swapIdx].priority_order;
    sorted[swapIdx].priority_order = tempOrder;

    await Promise.all([
      supabase.from("data_providers").update({ priority_order: sorted[idx].priority_order } as any).eq("provider_key", sorted[idx].provider_key),
      supabase.from("data_providers").update({ priority_order: sorted[swapIdx].priority_order } as any).eq("provider_key", sorted[swapIdx].provider_key),
    ]);
    setProviders([...sorted].sort((a, b) => a.priority_order - b.priority_order));
    invalidateProviderCache();
  };

  // ======== Google Accounts ========
  const loadGoogleAccounts = async () => {
    if (!user?.id) return;
    const { data } = await supabase
      .from("email_accounts")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .order("connected_at", { ascending: false });
    const accounts = data || [];
    if (accounts.length === 1 && !(accounts[0] as any).is_primary) {
      await setAccountAsPrimary(accounts[0].id, user.id);
      (accounts[0] as any).is_primary = true;
    }
    setGoogleAccounts(accounts);
  };

  const handleSetPrimary = async (accountId: string, email: string) => {
    if (!user?.id) return;
    await setAccountAsPrimary(accountId, user.id);
    setGoogleAccounts(prev => prev.map(a => ({ ...a, is_primary: a.id === accountId })));
    toast.success(`Primary inbox set to ${email}`);
  };

  const handleConnectGoogle = useCallback(async () => {
    setConnectingGoogle(true);
    try {
      const { data: configData } = await supabase.functions.invoke("gmail-oauth", {
        body: { action: "get-client-id" },
      });
      const googleClientId = configData?.client_id;
      if (!googleClientId) {
        toast.error("Google OAuth not configured. Please contact your admin.");
        setConnectingGoogle(false);
        return;
      }
      const state = crypto.randomUUID();
      sessionStorage.setItem("gmail_oauth_state", state);
      const redirectUri = window.location.origin + "/oauth/callback";
      const scopes = [
        "https://www.googleapis.com/auth/gmail.send",
        "https://www.googleapis.com/auth/userinfo.email",
        "https://www.googleapis.com/auth/userinfo.profile",
      ].join(" ");
      const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
      authUrl.searchParams.set("client_id", googleClientId);
      authUrl.searchParams.set("redirect_uri", redirectUri);
      authUrl.searchParams.set("response_type", "code");
      authUrl.searchParams.set("scope", scopes);
      authUrl.searchParams.set("access_type", "offline");
      authUrl.searchParams.set("prompt", "consent");
      authUrl.searchParams.set("state", state);
      window.location.href = authUrl.toString();
    } catch (e: any) {
      toast.error("Failed to start Google sign-in: " + e.message);
      setConnectingGoogle(false);
    }
  }, []);

  const handleDisconnectGoogle = async (accountId: string) => {
    if (!user?.id) return;
    await supabase.functions.invoke("gmail-oauth", {
      body: { action: "disconnect", email_account_id: accountId, user_id: user.id },
    });
    setGoogleAccounts(prev => prev.filter(a => a.id !== accountId));
    toast.success("Google account disconnected");
  };

  // ======== Company Settings ========
  const loadCompanySettings = async () => {
    const { data } = await supabase.from("company_settings").select("*").limit(1).maybeSingle();
    if (data) {
      setCompanyName(data.company_name || "Office Beacon");
      setCompanyAddress(data.company_address || "");
      setCompanyWebsite(data.company_website || "");
    }
  };

  const saveCompanySettings = async () => {
    setSavingCompany(true);
    const { data: existing } = await supabase.from("company_settings").select("id").limit(1).maybeSingle();
    if (existing) {
      await supabase.from("company_settings").update({
        company_name: companyName,
        company_address: companyAddress,
        company_website: companyWebsite,
        updated_at: new Date().toISOString(),
      }).eq("id", existing.id);
    }
    toast.success("Company info saved");
    setSavingCompany(false);
  };

  const loadOptOuts = async () => {
    const { data } = await supabase.from("email_optouts").select("*").order("opted_out_at", { ascending: false });
    setOptOuts(data || []);
  };

  const loadTeam = async () => {
    const [profilesRes, rolesRes] = await Promise.all([
      supabase.from("profiles").select("*").order("created_at", { ascending: true }),
      supabase.from("user_roles").select("*"),
    ]);
    setTeamMembers(profilesRes.data || []);
    const roleMap: Record<string, string> = {};
    (rolesRes.data || []).forEach((r: any) => { roleMap[r.user_id] = r.role; });
    setTeamRoles(roleMap);
  };

  const handleInvite = async () => {
    if (!inviteForm.email || !inviteForm.fullName) {
      toast.error("Please fill in all fields");
      return;
    }
    setInviting(true);
    try {
      const { data, error } = await supabase.functions.invoke("invite-user", {
        body: { email: inviteForm.email, fullName: inviteForm.fullName, role: inviteForm.role },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setTempPassword(data.tempPassword);
      toast.success(`Invitation sent to ${inviteForm.email}`);
      loadTeam();
    } catch (err: any) {
      toast.error("Failed to invite: " + (err.message || "Unknown error"));
    }
    setInviting(false);
  };

  const toggleShow = (key: string) => setShowKeys((p) => ({ ...p, [key]: !p[key] }));

  const setValidation = (key: string, status: ValidationStatus) =>
    setValidationStatus((p) => ({ ...p, [key]: status }));

  const handleSaveAI = async () => {
    setSaving(true);
    setSaveSuccess(false);

    const activeKey = aiKeys[aiProvider];
    if (activeKey) {
      setValidation(aiProvider, "validating");
      let ok = false;
      if (aiProvider === "anthropic") ok = await validateAnthropicKey(activeKey, aiModel.anthropic);
      else if (aiProvider === "openai") ok = await validateOpenAIKey(activeKey);
      else if (aiProvider === "gemini") ok = await validateGeminiKey(activeKey);
      const s = ok ? "valid" : "invalid";
      setValidation(aiProvider, s);

      if (!ok) {
        toast.warning("AI key appears invalid. Settings saved anyway.");
      } else {
        toast.success("AI settings saved and validated ✓");
      }
    }

    try {
      persistAll();
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2000);
    } catch {
      toast.error("Failed to save settings");
    }
    setSaving(false);
  };

  const keyInputProps = (id: string, value: string, onChange: (v: string) => void, placeholder: string) => ({
    type: showKeys[id] ? "text" : "password" as const,
    value,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
      onChange(e.target.value);
      setValidation(id, "idle");
    },
    placeholder,
    className: "text-sm pr-20 pl-9",
  });

  const getInitials = (name: string) => name?.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) || "?";

  // Provider priority lists
  const companyProviders = providers.filter((p) => p.is_active && p.provider_type.includes("company_search")).sort((a, b) => a.priority_order - b.priority_order);
  const contactProviders = providers.filter((p) => p.is_active && p.provider_type.includes("contact_search")).sort((a, b) => a.priority_order - b.priority_order);

  return (
    <div className="space-y-4 max-w-4xl">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Data providers, AI, sender accounts, and configuration</p>
      </motion.div>

      {/* ========== Data Providers ========== */}
      <SettingsSection
        icon={Database}
        title="Data Providers"
        subtitle="Configure company and contact research providers with automatic failover"
        badge={`${providers.filter((p) => p.is_active).length} active`}
        defaultOpen={true}
        actions={
          <Button
            size="sm"
            variant="outline"
            onClick={handleCheckAll}
            disabled={checkingAll}
            className="gap-1.5 text-xs"
          >
            {checkingAll ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
            Check All
          </Button>
        }
      >
        <div className="space-y-4 mt-3">
          {/* Provider Cards */}
          {providers.map((provider, idx) => {
            const healthCfg = HEALTH_CONFIG[provider.health_status] || HEALTH_CONFIG.unchecked;
            const isTesting = testingProvider === provider.provider_key;
            return (
              <div key={provider.id} className={cn(
                "rounded-xl border p-4 transition-all",
                provider.is_active ? "border-primary/30 bg-primary/[0.02]" : "border-border bg-muted/20"
              )}>
                <div className="flex items-center gap-3 mb-3">
                  {/* Reorder arrows */}
                  <div className="flex flex-col gap-0.5">
                    <button
                      onClick={() => moveProvider(provider.provider_key, "up")}
                      disabled={idx === 0}
                      className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20"
                    >
                      <ArrowUp className="h-3 w-3" />
                    </button>
                    <button
                      onClick={() => moveProvider(provider.provider_key, "down")}
                      disabled={idx === providers.length - 1}
                      className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20"
                    >
                      <ArrowDown className="h-3 w-3" />
                    </button>
                  </div>
                  {/* Provider icon placeholder */}
                  <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold">{provider.provider_name}</span>
                      <span className="text-[10px] text-muted-foreground font-mono">#{provider.priority_order}</span>
                      {/* How to connect tooltip */}
                      {PROVIDER_TOOLTIPS[provider.provider_key] && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-[260px] text-xs">
                              {PROVIDER_TOOLTIPS[provider.provider_key]}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                      {/* Health badge */}
                      <div className="flex items-center gap-1">
                        <div className={cn("h-2 w-2 rounded-full", healthCfg.dot)} />
                        <span className="text-[10px] text-muted-foreground">{healthCfg.label}</span>
                      </div>
                    </div>
                    {/* Capability badges */}
                    <div className="flex flex-wrap gap-1 mt-1">
                      {provider.provider_type.map((cap) => (
                        <Badge key={cap} variant="secondary" className="text-[9px] px-1.5 py-0">
                          {CAPABILITY_LABELS[cap] || cap}
                        </Badge>
                      ))}
                    </div>
                    {/* Clay helper note */}
                    {provider.provider_key === "clay" && (
                      <p className="text-[10px] text-muted-foreground mt-1.5 italic">
                        Clay enrichment works through webhooks. Configure your Clay tables to receive data from campaigns for enrichment.
                      </p>
                    )}
                    {/* Prospeo helper note */}
                    {provider.provider_key === "prospeo" && (
                      <p className="text-[10px] text-muted-foreground mt-1.5 italic">
                        Get your API key from prospeo.io dashboard → API settings
                      </p>
                    )}
                    {/* Apify helper note */}
                    {provider.provider_key === "apify" && (
                      <p className="text-[10px] text-muted-foreground mt-1.5 italic">
                        Get your API token from console.apify.com → Settings → Integrations
                      </p>
                    )}
                  </div>
                  {/* Active toggle */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground">{provider.is_active ? "Active" : "Inactive"}</span>
                    <Switch
                      checked={provider.is_active}
                      onCheckedChange={(checked) => toggleProviderActive(provider.provider_key, checked)}
                    />
                  </div>
                </div>

                {/* Credentials input */}
                {provider.provider_key === "apollo" ? (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                        <Input
                          type={showKeys["apollo"] ? "text" : "password"}
                          value={providerKeys["apollo"] || ""}
                          onChange={(e) => updateProviderKey("apollo", e.target.value)}
                          placeholder="Enter Apollo Master API Key"
                          className="text-sm pl-9 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => toggleShow("apollo")}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-0.5"
                        >
                          {showKeys["apollo"] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button type="button" className="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground">
                              <Info className="h-4 w-4" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-[280px] text-xs whitespace-pre-line">
                            {APOLLO_MASTER_KEY_GUIDE}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Create a Master API Key in Apollo: Settings → Integrations → API → Create API Key → Toggle "Set as master key" to enable all endpoints including people search
                    </p>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-10 text-xs gap-1 shrink-0"
                        onClick={() => saveProviderKey("apollo")}
                      >
                        Save
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-10 text-xs gap-1 shrink-0"
                        disabled={isTesting || !providerKeys["apollo"]}
                        onClick={() => handleTestProvider("apollo")}
                      >
                        {isTesting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
                        Test
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                      <Input
                        type={showKeys[provider.provider_key] ? "text" : "password"}
                        value={providerKeys[provider.provider_key] || ""}
                        onChange={(e) => updateProviderKey(provider.provider_key, e.target.value)}
                        placeholder={`Enter ${provider.provider_name} API key`}
                        className="text-sm pl-9 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => toggleShow(provider.provider_key)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-0.5"
                      >
                        {showKeys[provider.provider_key] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-10 text-xs gap-1 shrink-0"
                      onClick={() => saveProviderKey(provider.provider_key)}
                    >
                      Save
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-10 text-xs gap-1 shrink-0"
                      disabled={isTesting || !providerKeys[provider.provider_key]}
                      onClick={() => handleTestProvider(provider.provider_key)}
                    >
                      {isTesting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
                      Test
                    </Button>
                  </div>
                )}

                {/* Apify Actor Configuration */}
                {provider.provider_key === "apify" && provider.is_active && (
                  <ApifyActorConfig
                    config={(provider.config as Record<string, any>) || {}}
                    onSave={async (config) => {
                      await supabase
                        .from("data_providers")
                        .update({ config: config as any, updated_at: new Date().toISOString() } as any)
                        .eq("provider_key", "apify");
                      setProviders(prev => prev.map(p => p.provider_key === "apify" ? { ...p, config } : p));
                      toast.success("Actor configuration saved");
                    }}
                  />
                )}
              </div>
            );
          })}

          {/* Priority Order Summary */}
          {(companyProviders.length > 0 || contactProviders.length > 0) && (
            <div className="rounded-xl border border-dashed border-border p-4 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Failover Priority</p>
              <p className="text-[11px] text-muted-foreground">If a provider fails or returns no results, the system automatically tries the next provider in the list.</p>
              {companyProviders.length > 0 && (
                <div>
                  <p className="text-[11px] font-medium mb-1">Company Research:</p>
                  <p className="text-xs text-muted-foreground">
                    {companyProviders.map((p, i) => `${i + 1}. ${p.provider_name}`).join(" → ")}
                  </p>
                </div>
              )}
              {contactProviders.length > 0 && (
                <div>
                  <p className="text-[11px] font-medium mb-1">Contact Research:</p>
                  <p className="text-xs text-muted-foreground">
                    {contactProviders.map((p, i) => `${i + 1}. ${p.provider_name}`).join(" → ")}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </SettingsSection>

      {/* ========== AI Message Generation ========== */}
      <SettingsSection icon={Brain} title="AI Message Generation" subtitle="Choose your AI provider for personalized messages">
        <div className="space-y-5 mt-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {([
              { id: "anthropic" as const, icon: Sparkles, title: "Anthropic", subtitle: "Claude Sonnet — recommended" },
              { id: "openai" as const, icon: Brain, title: "OpenAI", subtitle: "GPT-4o — versatile" },
              { id: "gemini" as const, icon: Diamond, title: "Google Gemini", subtitle: "Gemini 2.5 — fast" },
            ]).map((provider) => {
              const selected = aiProvider === provider.id;
              return (
                <button
                  key={provider.id}
                  type="button"
                  onClick={() => setAiProvider(provider.id)}
                  className={cn(
                    "relative flex items-start gap-3 rounded-xl border p-4 text-left transition-all",
                    selected ? "border-primary bg-primary/5 shadow-sm" : "border-border hover:bg-muted/40"
                  )}
                >
                  <div className={cn(
                    "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                    selected ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                  )}>
                    <provider.icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">{provider.title}</p>
                    <p className="text-[10px] text-muted-foreground">{provider.subtitle}</p>
                  </div>
                  {selected && (
                    <div className="absolute right-3 top-3 h-4 w-4 rounded-full bg-primary flex items-center justify-center">
                      <Check className="h-2.5 w-2.5 text-primary-foreground" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <Label className="text-xs font-semibold">
                  {aiProvider === "anthropic" ? "Anthropic API Key" : aiProvider === "openai" ? "OpenAI API Key" : "Google Gemini API Key"}
                </Label>
                <ValidationIndicator status={validationStatus[aiProvider] || "idle"} />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  {...keyInputProps(
                    aiProvider,
                    aiKeys[aiProvider],
                    (v) => setAiKey(aiProvider, v),
                    aiProvider === "anthropic" ? "sk-ant-..." : aiProvider === "openai" ? "sk-..." : "AIza..."
                  )}
                />
                <button
                  type="button"
                  onClick={() => toggleShow(aiProvider)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground p-0.5"
                >
                  {showKeys[aiProvider] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Model</Label>
              <Select value={aiModel[aiProvider]} onValueChange={(v) => setAiModel(aiProvider, v)}>
                <SelectTrigger className="mt-1.5 text-sm w-64"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {AI_MODELS[aiProvider].map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              size="sm"
              onClick={handleSaveAI}
              disabled={saving}
              className={cn("min-w-[140px]", saveSuccess && "bg-emerald-600 hover:bg-emerald-700")}
            >
              {saving ? (
                <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> Validating...</>
              ) : saveSuccess ? (
                <><Check className="h-3.5 w-3.5 mr-1.5" /> Saved!</>
              ) : (
                "Save Settings"
              )}
            </Button>
          </div>
        </div>
      </SettingsSection>

      {/* ========== Connected Google Accounts ========== */}
      <SettingsSection
        icon={Mail}
        title="Connected Google Accounts"
        subtitle="Connect Gmail accounts for sending campaign emails"
        badge={googleAccounts.length > 0 ? `${googleAccounts.length} connected` : undefined}
        actions={
          <Button
            size="sm"
            variant="outline"
            onClick={handleConnectGoogle}
            disabled={connectingGoogle}
            className="gap-1.5 text-xs border-border bg-background hover:bg-muted"
          >
            {connectingGoogle ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <>
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                Connect Account
              </>
            )}
          </Button>
        }
      >
        <div className="mt-3">
          <p className="text-xs text-muted-foreground mb-3">Your primary inbox is used for deal emails, meeting confirmations, and nurture sequences.</p>
          {googleAccounts.length > 0 ? (
            <div className="space-y-2">
              {googleAccounts.map((account) => (
                <div key={account.id} className={cn("flex items-center gap-3 p-3 rounded-xl border", account.is_primary ? "bg-primary/5 border-primary/30" : "bg-muted/30 border-border/50")}>
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-bold">
                    {account.display_name?.[0]?.toUpperCase() || account.email?.[0]?.toUpperCase() || "G"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-medium truncate">{account.email}</p>
                      {account.is_primary && (
                        <Badge className="text-[10px] bg-primary/15 text-primary border-primary/30 gap-0.5">
                          <Star className="h-2.5 w-2.5 fill-current" /> Primary
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {account.display_name} · Connected {new Date(account.connected_at).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{account.daily_send_limit}/day</Badge>
                  {!account.is_primary && (
                    <button
                      onClick={() => handleSetPrimary(account.id, account.email)}
                      className="text-xs text-primary hover:underline whitespace-nowrap"
                    >
                      Set as Primary
                    </button>
                  )}
                  <button
                    onClick={() => handleDisconnectGoogle(account.id)}
                    className="text-xs text-destructive hover:underline"
                  >
                    Disconnect
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <Mail className="h-8 w-8 mx-auto text-muted-foreground/30 mb-2" />
              <p className="text-sm text-muted-foreground">No Google accounts connected</p>
              <p className="text-xs text-muted-foreground mt-0.5">Connect a Gmail account to start sending campaign emails</p>
            </div>
          )}
        </div>
      </SettingsSection>

      {/* ========== Team Management ========== */}
      <SettingsSection
        icon={Users}
        title="Team Management"
        subtitle="Manage team members and their roles"
        badge={teamMembers.length > 0 ? `${teamMembers.length} members` : undefined}
        actions={
          <Button size="sm" onClick={() => { setShowInviteDialog(true); setTempPassword(null); setInviteForm({ fullName: "", email: "", role: "bdm" }); }} className="gap-1.5 text-xs">
            <UserPlus className="h-3.5 w-3.5" /> Invite
          </Button>
        }
      >
        <div className="mt-3 space-y-2">
          {teamMembers.map((member) => (
            <div key={member.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 border border-border/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-bold flex-shrink-0">
                {getInitials(member.full_name || "")}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{member.full_name}</p>
                <p className="text-xs text-muted-foreground truncate">{member.email}</p>
              </div>
              <Badge className={cn(
                "text-[10px] border-0",
                teamRoles[member.id] === "admin" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
              )}>
                {teamRoles[member.id] === "admin" ? "Admin" : "BDM"}
              </Badge>
              <div className="flex items-center gap-1.5">
                <div className={`h-2 w-2 rounded-full ${member.is_active ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                <span className="text-[10px] text-muted-foreground">{member.is_active ? "Active" : "Inactive"}</span>
              </div>
            </div>
          ))}
          {teamMembers.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">No team members found</p>
          )}
        </div>
      </SettingsSection>

      {/* ========== Company Information ========== */}
      <SettingsSection icon={Building2} title="Company Information" subtitle="Used in email footer for CAN-SPAM compliance">
        <div className="space-y-4 mt-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs font-semibold">Company Name</Label>
              <Input value={companyName} onChange={e => setCompanyName(e.target.value)} className="mt-1.5 text-sm" />
            </div>
            <div>
              <Label className="text-xs font-semibold">Company Website</Label>
              <Input value={companyWebsite} onChange={e => setCompanyWebsite(e.target.value)} className="mt-1.5 text-sm" />
            </div>
          </div>
          <div>
            <Label className="text-xs font-semibold">Physical Mailing Address</Label>
            <Input value={companyAddress} onChange={e => setCompanyAddress(e.target.value)} placeholder="123 Business Ave, Suite 100, City, State ZIP" className="mt-1.5 text-sm" />
            <p className="text-[10px] text-muted-foreground mt-1">Required by CAN-SPAM Act for cold outbound emails</p>
          </div>
          <div className="flex justify-end">
            <Button size="sm" onClick={saveCompanySettings} disabled={savingCompany}>
              {savingCompany ? <><Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> Saving...</> : "Save Company Info"}
            </Button>
          </div>
        </div>
      </SettingsSection>

      {/* ========== Exclusion Domains ========== */}
      <SettingsSection icon={Ban} title="Exclusion Domains" subtitle="Domains to exclude from outreach">
        <div className="mt-3">
          <textarea
            className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm min-h-[80px] resize-y focus:outline-none focus:ring-2 focus:ring-ring"
            defaultValue={"officebeacon.com\nob-services.com\nstaffingfirm.com"}
          />
          <div className="flex justify-end mt-3">
            <Button size="sm">Save Exclusions</Button>
          </div>
        </div>
      </SettingsSection>

      {/* ========== Opt-Out List ========== */}
      <SettingsSection
        icon={MailX}
        title="Email Opt-Outs"
        subtitle="Contacts who have unsubscribed from emails"
        badge={`${optOuts.length} contacts`}
      >
        <div className="mt-3">
          {optOuts.length > 0 ? (
            <div className="border border-border rounded-xl overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/30">
                    <TableHead className="text-xs font-medium">Email</TableHead>
                    <TableHead className="text-xs font-medium">Reason</TableHead>
                    <TableHead className="text-xs font-medium">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {optOuts.map((opt, idx) => (
                    <TableRow key={opt.id} className={idx % 2 === 1 ? "bg-muted/15" : ""}>
                      <TableCell className="text-sm font-mono">{opt.email}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{opt.reason || "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{new Date(opt.opted_out_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">No opt-outs yet</p>
          )}
        </div>
      </SettingsSection>

      {/* Invite Dialog */}
      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{tempPassword ? "User Created Successfully" : "Invite New Member"}</DialogTitle>
            <DialogDescription>
              {tempPassword ? "Share the temporary password securely." : "Send an invitation to a new team member."}
            </DialogDescription>
          </DialogHeader>

          {tempPassword ? (
            <div className="space-y-4">
              <div className="rounded-xl bg-muted/40 border border-border p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Email:</span>
                  <span className="font-medium">{inviteForm.email}</span>
                </div>
                <div className="flex justify-between text-sm items-center">
                  <span className="text-muted-foreground">Temp Password:</span>
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-background px-2 py-1 rounded border">{tempPassword}</code>
                    <button
                      onClick={() => { navigator.clipboard.writeText(tempPassword); toast.success("Copied!"); }}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
              <Button className="w-full" onClick={() => setShowInviteDialog(false)}>Done</Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label className="text-xs font-semibold">Full Name</Label>
                <Input
                  value={inviteForm.fullName}
                  onChange={(e) => setInviteForm(p => ({ ...p, fullName: e.target.value }))}
                  placeholder="John Doe"
                  className="mt-1.5 text-sm"
                />
              </div>
              <div>
                <Label className="text-xs font-semibold">Email</Label>
                <Input
                  type="email"
                  value={inviteForm.email}
                  onChange={(e) => setInviteForm(p => ({ ...p, email: e.target.value }))}
                  placeholder="john@officebeacon.com"
                  className="mt-1.5 text-sm"
                />
              </div>
              <div>
                <Label className="text-xs font-semibold">Role</Label>
                <RadioGroup
                  value={inviteForm.role}
                  onValueChange={(v) => setInviteForm(p => ({ ...p, role: v as "admin" | "bdm" }))}
                  className="mt-2 grid grid-cols-2 gap-2"
                >
                  <Label
                    htmlFor="role-bdm"
                    className={cn(
                      "flex items-center gap-2 rounded-xl border p-3 cursor-pointer transition-all",
                      inviteForm.role === "bdm" ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"
                    )}
                  >
                    <RadioGroupItem value="bdm" id="role-bdm" />
                    <div>
                      <p className="text-sm font-medium">BDM</p>
                      <p className="text-[10px] text-muted-foreground">Business Dev</p>
                    </div>
                  </Label>
                  <Label
                    htmlFor="role-admin"
                    className={cn(
                      "flex items-center gap-2 rounded-xl border p-3 cursor-pointer transition-all",
                      inviteForm.role === "admin" ? "border-primary bg-primary/5" : "border-border hover:bg-muted/40"
                    )}
                  >
                    <RadioGroupItem value="admin" id="role-admin" />
                    <div>
                      <p className="text-sm font-medium">Admin</p>
                      <p className="text-[10px] text-muted-foreground">Full access</p>
                    </div>
                  </Label>
                </RadioGroup>
              </div>
              <Button className="w-full" onClick={handleInvite} disabled={inviting}>
                {inviting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Creating...</> : "Send Invitation"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ── Apify Actor Configuration ── */
function ApifyActorConfig({ config, onSave }: { config: Record<string, any>; onSave: (config: Record<string, any>) => void }) {
  const actors: { name: string; actor_id: string }[] = config?.actors || [];
  const [newName, setNewName] = useState("");
  const [newActorId, setNewActorId] = useState("");

  const addActor = () => {
    if (!newActorId.trim()) return;
    const updated = {
      ...config,
      actors: [...actors, { name: newName.trim() || newActorId.trim(), actor_id: newActorId.trim() }],
    };
    onSave(updated);
    setNewName("");
    setNewActorId("");
  };

  const removeActor = (idx: number) => {
    const updated = { ...config, actors: actors.filter((_, i) => i !== idx) };
    onSave(updated);
  };

  return (
    <div className="mt-3 pt-3 border-t border-border space-y-3">
      <div className="flex items-center gap-2">
        <Briefcase className="h-3.5 w-3.5 text-muted-foreground" />
        <p className="text-xs font-semibold">Apify Actors</p>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="h-3 w-3 text-muted-foreground cursor-help" />
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-[260px] text-xs">
              Configure which Apify actors to use for job posting scraping. Find actors on apify.com/store (e.g. "dXtracted/indeed-scraper").
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      {actors.length > 0 && (
        <div className="space-y-1.5">
          {actors.map((actor, idx) => (
            <div key={idx} className="flex items-center gap-2 text-xs bg-muted/50 rounded-lg px-3 py-2">
              <Briefcase className="h-3 w-3 text-muted-foreground shrink-0" />
              <span className="font-medium">{actor.name}</span>
              <span className="text-muted-foreground font-mono text-[10px] truncate flex-1">{actor.actor_id}</span>
              <button onClick={() => removeActor(idx)} className="text-muted-foreground hover:text-destructive p-0.5">
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2">
        <div className="flex-1 space-y-1">
          <label className="text-[10px] font-medium text-muted-foreground">Actor Name</label>
          <Input
            value={newName}
            onChange={e => setNewName(e.target.value)}
            placeholder="e.g. Indeed Scraper"
            className="text-xs h-8"
          />
        </div>
        <div className="flex-1 space-y-1">
          <label className="text-[10px] font-medium text-muted-foreground">Actor ID</label>
          <Input
            value={newActorId}
            onChange={e => setNewActorId(e.target.value)}
            placeholder="e.g. dXtracted/indeed-scraper"
            className="text-xs h-8"
          />
        </div>
        <Button size="sm" variant="outline" className="h-8 text-xs gap-1 shrink-0" onClick={addActor} disabled={!newActorId.trim()}>
          <Plus className="h-3 w-3" />
          Add
        </Button>
      </div>
    </div>
  );
}
