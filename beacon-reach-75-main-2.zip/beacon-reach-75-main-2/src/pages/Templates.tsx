import { useState } from "react";
import { motion } from "framer-motion";
import { FileText, Mail, Linkedin, Edit2, Save, Zap, Copy, Check } from "lucide-react";
import NurtureSequenceBuilder from "@/components/NurtureSequenceBuilder";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const emailTemplates = [
  { vertical: "IT Help Desk", steps: [
    { day: 1, subject: "{{company_name}} help desk — 24/7 coverage at 65% less", preview: "Hi {{first_name}}, I noticed {{company_name}} is growing and likely handling more IT support volume..." },
    { day: 4, subject: "Re: {{email_subject}}", preview: "Quick follow-up with the numbers: US Help Desk Analyst: $55-65K + benefits..." },
    { day: 8, subject: "How one IT Director cut help desk costs 65%", preview: "One more data point — a 300-person company's IT Director couldn't keep up with L1 tickets..." },
    { day: 14, subject: "Closing the loop", preview: "Last note — if remote IT support staffing isn't a priority right now, totally understand..." },
  ]},
  { vertical: "NOC/SOC", steps: [
    { day: 1, subject: "{{company_name}} operations — 24/7 coverage at 65-75% less", preview: "I noticed {{company_name}} is scaling its operations. Staffing a 24/7 operations center..." },
    { day: 4, subject: "Re: {{email_subject}}", preview: "The 24/7 math that gets security and network leaders interested..." },
    { day: 8, subject: "How one CISO built 24/7 SOC for under $120K/yr", preview: "A CISO at a 400-person SaaS company needed 24/7 SOC monitoring..." },
    { day: 14, subject: "Closing the loop", preview: "Last note — if building a remote NOC or SOC team isn't a priority right now..." },
  ]},
];

const DEFAULT_TIMING_KEY = "ob-default-sequence-timing";

function loadDefaultTiming(): { step2: number; step3: number; step4: number } {
  try {
    const stored = localStorage.getItem(DEFAULT_TIMING_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}
  return { step2: 4, step3: 8, step4: 14 };
}

function saveDefaultTiming(timing: { step2: number; step3: number; step4: number }) {
  localStorage.setItem(DEFAULT_TIMING_KEY, JSON.stringify(timing));
}

/** Render text with {{variables}} highlighted as colored pills */
function VariableText({ text }: { text: string }) {
  const parts = text.split(/({{[^}]+}})/g);
  return (
    <span>
      {parts.map((part, i) =>
        part.startsWith("{{") ? (
          <span key={i} className="inline-flex items-center px-1.5 py-0.5 mx-0.5 rounded bg-blue-100 text-blue-700 text-[10px] font-mono font-medium align-baseline">
            {part}
          </span>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </span>
  );
}

export default function Templates() {
  const [activeTab, setActiveTab] = useState("email");
  const [activeVertical, setActiveVertical] = useState("IT Help Desk");
  const [defaultTiming, setDefaultTiming] = useState(loadDefaultTiming);
  const [systemPromptCopied, setSystemPromptCopied] = useState(false);

  const handleSaveTiming = () => {
    saveDefaultTiming(defaultTiming);
    toast.success("Default sequence timing saved");
  };

  const timingDots = [
    { label: "Step 1", day: 1, editable: false },
    { label: "Step 2", day: defaultTiming.step2, editable: true, key: "step2" as const },
    { label: "Step 3", day: defaultTiming.step3, editable: true, key: "step3" as const },
    { label: "Step 4", day: defaultTiming.step4, editable: true, key: "step4" as const },
  ];

  const tabs = [
    { id: "email", label: "Email Sequences", icon: Mail },
    { id: "linkedin", label: "LinkedIn Messages", icon: Linkedin },
    { id: "nurture", label: "Nurture Sequences", icon: Zap },
    { id: "system", label: "System Prompt", icon: FileText },
  ];

  const defaultSystemPrompt = `You are an outbound sales copywriter for Office Beacon (officebeacon.com), a remote staffing company.

OFFICE BEACON CONTEXT:
- Provides dedicated remote IT staff from India, Philippines, South Africa, Mexico
- SOC 2 compliant, ITIL trained
- IT Help Desk: $12-20K vs US $55-65K (65-70% savings)
- NOC L1: $12-20K vs US $50-65K (65-75% savings)
- SOC L1: $14-22K vs US $55-75K (65-75% savings)

RULES:
- Always mention Office Beacon by name
- Reference the company's specific growth or hiring signal
- Include relevant cost savings percentage
- Be consultative, not pushy`;

  const handleCopySystemPrompt = () => {
    const el = document.querySelector("#system-prompt-textarea") as HTMLTextAreaElement | null;
    navigator.clipboard.writeText(el?.value || defaultSystemPrompt);
    setSystemPromptCopied(true);
    toast.success("Copied to clipboard");
    setTimeout(() => setSystemPromptCopied(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold tracking-tight">Templates</h1>
        <p className="text-sm text-muted-foreground">Email sequences and LinkedIn message templates</p>
      </motion.div>

      {/* Pill-style tab switcher */}
      <div className="flex bg-muted rounded-lg p-0.5 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-1.5 text-xs flex items-center gap-1.5 rounded-md transition-all ${
              activeTab === tab.id
                ? "bg-background text-foreground shadow-sm font-medium"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon className="h-3.5 w-3.5" /> {tab.label}
          </button>
        ))}
      </div>

      {/* ========== EMAIL SEQUENCES ========== */}
      {activeTab === "email" && (
        <div className="space-y-6">
          {/* Timeline Timing Editor */}
          <Card className="border border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold">Default Sequence Timing</h3>
                  <p className="text-xs text-muted-foreground">Set day delays for new campaigns. Adjustable per campaign.</p>
                </div>
                <Button size="sm" className="gap-1.5" onClick={handleSaveTiming}>
                  <Save className="h-3 w-3" /> Save
                </Button>
              </div>

              {/* Visual timeline */}
              <div className="relative px-4 py-6">
                {/* Horizontal line */}
                <div className="absolute top-1/2 left-8 right-8 h-0.5 bg-border -translate-y-1/2" />

                <div className="flex justify-between relative">
                  {timingDots.map((dot, i) => (
                    <div key={i} className="flex flex-col items-center gap-2 relative z-10">
                      {/* Dot */}
                      <div className={`h-4 w-4 rounded-full border-2 ${
                        i === 0 ? "bg-primary border-primary" : "bg-background border-primary"
                      }`} />

                      {/* Day input or label */}
                      {dot.editable && dot.key ? (
                        <div className="flex flex-col items-center">
                          <span className="text-[10px] text-muted-foreground font-medium mb-1">{dot.label}</span>
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-muted-foreground">Day</span>
                            <input
                              type="number"
                              min={2}
                              max={90}
                              value={dot.day}
                              onChange={e => setDefaultTiming(prev => ({ ...prev, [dot.key!]: parseInt(e.target.value) || dot.day }))}
                              className="w-10 px-1 py-0.5 text-xs border border-border rounded text-center bg-background font-medium"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <span className="text-[10px] text-muted-foreground font-medium">{dot.label}</span>
                          <span className="text-xs font-medium text-foreground">Day {dot.day}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Vertical selector */}
          <div className="flex gap-2">
            {emailTemplates.map((t) => (
              <Button key={t.vertical} variant={activeVertical === t.vertical ? "default" : "outline"} size="sm" onClick={() => setActiveVertical(t.vertical)}>
                {t.vertical}
              </Button>
            ))}
          </div>

          {/* Email mockup cards */}
          {emailTemplates.filter((t) => t.vertical === activeVertical).map((template) => (
            <div key={template.vertical} className="space-y-4">
              {template.steps.map((step, i) => (
                <Card key={i} className="overflow-hidden">
                  {/* Mock email header */}
                  <div className="bg-muted/40 border-b border-border px-4 py-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className="text-[10px] font-mono bg-primary/10 text-primary border-0">Day {step.day}</Badge>
                        <span className="text-xs font-medium text-muted-foreground">Step {i + 1} of {template.steps.length}</span>
                      </div>
                      <Button variant="ghost" size="sm" className="gap-1.5 text-xs text-muted-foreground h-7">
                        <Edit2 className="h-3 w-3" /> Edit
                      </Button>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex gap-2">
                        <span className="text-muted-foreground w-12">From:</span>
                        <span className="text-foreground">sender@officebeacon.com</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-muted-foreground w-12">To:</span>
                        <span className="text-foreground">
                          <VariableText text="{{first_name}} {{last_name}}" />
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-muted-foreground w-12">Subject:</span>
                        <span className="text-foreground font-medium">
                          <VariableText text={step.subject} />
                        </span>
                      </div>
                    </div>
                  </div>
                  {/* Body */}
                  <CardContent className="p-4">
                    <p className="text-sm text-foreground leading-relaxed">
                      <VariableText text={step.preview} />
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* ========== LINKEDIN MESSAGES ========== */}
      {activeTab === "linkedin" && (
        <div className="space-y-4">
          {[
            { title: "Connection Request Template", maxChars: 300, defaultValue: "Hi {{first_name}} — I'm with Office Beacon. We help {{industry}} companies build dedicated 24/7 {{vertical}} teams at 65-75% less than US staffing. Would love to connect." },
            { title: "Follow-up DM Template", maxChars: 500, defaultValue: "Thanks for connecting, {{first_name}}! I wanted to share a quick case study on how a {{industry}} company saved 65% on their {{vertical}} team with Office Beacon. Worth a 10-minute call?" },
          ].map((tmpl) => (
            <Card key={tmpl.title} className="overflow-hidden">
              {/* LinkedIn-styled header */}
              <div className="bg-blue-50/60 dark:bg-blue-950/20 border-b border-blue-100 dark:border-blue-900/30 px-4 py-3 flex items-center gap-2">
                <div className="h-6 w-6 rounded bg-blue-600 flex items-center justify-center">
                  <Linkedin className="h-3.5 w-3.5 text-white" />
                </div>
                <span className="text-sm font-semibold text-foreground">{tmpl.title}</span>
              </div>
              <CardContent className="p-4 bg-muted/10">
                <Textarea defaultValue={tmpl.defaultValue} rows={3} className="text-sm bg-background" />
                <p className="text-xs text-muted-foreground mt-2">
                  Max {tmpl.maxChars} characters. Variables:{" "}
                  <VariableText text="{{first_name}}, {{company}}, {{industry}}, {{vertical}}" />
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ========== NURTURE SEQUENCES ========== */}
      {activeTab === "nurture" && (
        <NurtureSequenceBuilder />
      )}

      {/* ========== SYSTEM PROMPT ========== */}
      {activeTab === "system" && (
        <Card className="overflow-hidden">
          <div className="bg-muted/40 border-b border-border px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-semibold">AI System Prompt</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="gap-1.5 text-xs h-7" onClick={handleCopySystemPrompt}>
                {systemPromptCopied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                {systemPromptCopied ? "Copied" : "Copy"}
              </Button>
              <Button size="sm" className="h-7 text-xs">Save Prompt</Button>
            </div>
          </div>
          <CardContent className="p-0">
            <Textarea
              id="system-prompt-textarea"
              rows={16}
              className="text-sm font-mono border-0 rounded-none focus-visible:ring-0 focus-visible:ring-offset-0 bg-card resize-y min-h-[300px]"
              defaultValue={defaultSystemPrompt}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
