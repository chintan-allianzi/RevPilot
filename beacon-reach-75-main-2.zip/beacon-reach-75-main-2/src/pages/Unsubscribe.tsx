import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Zap, CheckCircle2, AlertTriangle, Loader2, MailX } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Unsubscribe() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState<"loading" | "success" | "error" | "confirm">("loading");
  const [email, setEmail] = useState("");

  useEffect(() => {
    const emailParam = searchParams.get("email");
    const token = searchParams.get("token");
    const auto = searchParams.get("auto");

    if (!emailParam || !token) {
      setStatus("error");
      return;
    }

    setEmail(emailParam);

    if (auto === "1") {
      handleUnsubscribe(emailParam, token);
    } else {
      setStatus("confirm");
    }
  }, [searchParams]);

  const handleUnsubscribe = async (emailAddr?: string, token?: string) => {
    const e = emailAddr || email;
    const t = token || searchParams.get("token");

    try {
      const result = await supabase.functions.invoke("apollo-proxy", {
        body: {
          action: "unsubscribe",
          email: e,
          token: t,
          campaignId: searchParams.get("campaign") || null,
        },
      });

      if (result.data?.success) {
        setStatus("success");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 login-bg relative">
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: 'radial-gradient(circle at 1px 1px, hsl(var(--foreground)) 1px, transparent 0)',
        backgroundSize: '24px 24px',
      }} />

      <div className="w-full max-w-md relative z-10">
        {/* Branding */}
        <div className="text-center mb-6">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary shadow-lg shadow-primary/20 mb-4">
            <Zap className="h-6 w-6 text-primary-foreground" />
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Office Beacon</h1>
          <p className="text-[10px] font-semibold tracking-[0.25em] uppercase text-primary">Outbound</p>
        </div>

        {/* Card */}
        <div className="bg-card rounded-2xl border border-border shadow-xl shadow-black/5 p-8 text-center space-y-5">
          {status === "loading" && (
            <div className="py-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <p className="text-sm text-muted-foreground mt-3">Processing…</p>
            </div>
          )}

          {status === "confirm" && (
            <>
              <div className="mx-auto w-14 h-14 rounded-2xl bg-amber-50 flex items-center justify-center">
                <MailX className="h-7 w-7 text-amber-600" />
              </div>
              <h2 className="text-xl font-semibold text-foreground">Unsubscribe</h2>
              <p className="text-sm text-muted-foreground">
                Are you sure you want to unsubscribe <strong className="text-foreground">{email}</strong> from our emails?
              </p>
              <p className="text-xs text-muted-foreground">
                You will no longer receive outreach emails from Office Beacon.
              </p>
              <div className="flex gap-3 justify-center pt-2">
                <Button variant="outline" onClick={() => window.close()} className="px-5">
                  Cancel
                </Button>
                <Button variant="destructive" onClick={() => handleUnsubscribe()} className="px-5">
                  Yes, Unsubscribe Me
                </Button>
              </div>
            </>
          )}

          {status === "success" && (
            <>
              <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-50 flex items-center justify-center">
                <CheckCircle2 className="h-7 w-7 text-emerald-600" />
              </div>
              <h2 className="text-xl font-semibold text-foreground">You've been unsubscribed</h2>
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">{email}</strong> has been removed from our mailing list.
              </p>
              <p className="text-xs text-muted-foreground">
                You won't receive any more emails from us. If this was a mistake, please contact us.
              </p>
            </>
          )}

          {status === "error" && (
            <>
              <div className="mx-auto w-14 h-14 rounded-2xl bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="h-7 w-7 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold text-foreground">Something went wrong</h2>
              <p className="text-sm text-muted-foreground">
                We couldn't process your unsubscribe request. The link may be invalid or expired.
              </p>
              <p className="text-xs text-muted-foreground">
                Please contact <strong>support@officebeacon.com</strong> to be removed from our list.
              </p>
            </>
          )}
        </div>

        <p className="text-center text-[11px] text-muted-foreground/60 mt-8">
          Office Beacon © {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
